/*
 * Firebase Cloud Functions الإدارية.
 * تُنشر عبر Firebase CLI، ولا تُنفذ داخل المتصفح مطلقاً.
 */
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getDatabase } = require("firebase-admin/database");

initializeApp();

const ADMIN_UID = "n4KBfNzDe3hkkA4FyzfUw9uPycF3";

function requireAdmin(request) {
  if (!request.auth || request.auth.uid !== ADMIN_UID) {
    throw new HttpsError("permission-denied", "Admin access required");
  }
}

function profileFrom(data) {
  const role = data.role === "staff" ? "staff" : "accountant";
  return {
    name: String(data.name || "").trim(),
    email: String(data.email || "").trim().toLowerCase(),
    phone: String(data.phone || "").trim(),
    role,
    status: "active",
    subscriptionEnd: new Date(data.subscriptionEnd).toISOString(),
    createdAt: Date.now(),
  };
}

exports.adminCreateUser = onCall(async (request) => {
  requireAdmin(request);
  const data = request.data || {};
  if (!data.email || !data.password || String(data.password).length < 6) {
    throw new HttpsError("invalid-argument", "Valid email and password are required");
  }
  const created = await getAuth().createUser({
    email: String(data.email).trim().toLowerCase(),
    password: String(data.password),
    displayName: String(data.name || "").trim(),
    disabled: false,
  });
  const profile = profileFrom(data);
  await getDatabase().ref(`users/${created.uid}`).set({
    profile,
    customers: {}, cutting: {}, treasury: {}, accounts: {}, entries: {}, debts: {},
    reports: {}, settings: {}, notifications: {}, suppliers: {}, invoices: {},
  });
  return { uid: created.uid };
});

exports.adminUpdateUser = onCall(async (request) => {
  requireAdmin(request);
  const { uid, ...data } = request.data || {};
  if (!uid || uid === ADMIN_UID) throw new HttpsError("invalid-argument", "Invalid uid");
  await getAuth().updateUser(uid, {
    email: data.email ? String(data.email).trim().toLowerCase() : undefined,
    displayName: data.name ? String(data.name).trim() : undefined,
  });
  await getDatabase().ref(`users/${uid}/profile`).update({
    name: String(data.name || "").trim(), email: String(data.email || "").trim().toLowerCase(),
    phone: String(data.phone || "").trim(), role: data.role === "staff" ? "staff" : "accountant",
    subscriptionEnd: new Date(data.subscriptionEnd).toISOString(),
  });
  return { ok: true };
});

exports.adminSetPassword = onCall(async (request) => {
  requireAdmin(request);
  const { uid, password } = request.data || {};
  if (!uid || uid === ADMIN_UID || !password || String(password).length < 6) {
    throw new HttpsError("invalid-argument", "Invalid uid or password");
  }
  await getAuth().updateUser(uid, { password: String(password) });
  return { ok: true };
});

exports.adminDeleteUser = onCall(async (request) => {
  requireAdmin(request);
  const { uid } = request.data || {};
  if (!uid || uid === ADMIN_UID) throw new HttpsError("invalid-argument", "Invalid uid");
  await Promise.all([
    getAuth().deleteUser(uid),
    getDatabase().ref(`users/${uid}`).remove(),
  ]);
  return { ok: true };
});
