import { useEffect, useMemo, useState } from "react";
import { httpsCallable } from "firebase/functions";
import { onValue, ref, remove, update } from "firebase/database";
import { sendPasswordResetEmail } from "firebase/auth";
import { Ban, CalendarPlus, Copy, Eye, FileCode, KeyRound, Plus, Search, ShieldCheck, Trash2, UserCheck } from "lucide-react";
import { auth, db, functions } from "../lib/firebase";
import { createTenantUser, readableCreateUserError } from "../lib/adminUsers";
import type { AdminUserSummary, UserProfile } from "../types/firebase";
import { DATE, NUM } from "../utils/format";

const subDaysLeft = (subscriptionEnd: string) =>
  Math.max(0, Math.ceil((new Date(subscriptionEnd).getTime() - Date.now()) / 86400000));

function SubBadge({ subscriptionEnd }: { subscriptionEnd: string }) {
  if (!subscriptionEnd) return <span className="text-[var(--faint)]">—</span>;
  const days = subDaysLeft(subscriptionEnd);
  if (days === 0) return <span className="chip chip-red">منتهي</span>;
  if (days <= 7) return <span className="chip chip-red font-black">⚠️ {NUM(days)} يوم</span>;
  if (days <= 30) return <span className="chip chip-gold">{NUM(days)} يوم</span>;
  return <span className="chip chip-green">{NUM(days)} يوم</span>;
}
import { Chip, ConfirmDialog, Glass, L, Modal, SectionHead, inputCls, useApp } from "./ui";

  type AdminAction = "create" | "update" | "delete" | "password" | "import" | "extend";

  const rulesJsonText = `{
  "rules": {
    ".read": false,
    ".write": false,
    "admins": {
      "$adminUid": {
        ".read": "auth != null && (auth.uid === 'n4KBfNzDe3hkkA4FyzfUw9uPycF3' || root.child('admins').child(auth.uid).exists() || (auth.token.email != null && auth.token.email.matches(/.*admin.*/i)))",
        ".write": false
      }
    },
    "users": {
      ".read": "auth != null && (auth.uid === 'n4KBfNzDe3hkkA4FyzfUw9uPycF3' || root.child('admins').child(auth.uid).exists() || (auth.token.email != null && auth.token.email.matches(/.*admin.*/i)))",
      ".write": "auth != null && (auth.uid === 'n4KBfNzDe3hkkA4FyzfUw9uPycF3' || root.child('admins').child(auth.uid).exists() || (auth.token.email != null && auth.token.email.matches(/.*admin.*/i)))",
      "$uid": {
        ".read": "auth != null && (auth.uid === $uid || auth.uid === 'n4KBfNzDe3hkkA4FyzfUw9uPycF3' || root.child('admins').child(auth.uid).exists() || (auth.token.email != null && auth.token.email.matches(/.*admin.*/i)))",
        ".write": "auth != null && (auth.uid === $uid || auth.uid === 'n4KBfNzDe3hkkA4FyzfUw9uPycF3' || root.child('admins').child(auth.uid).exists() || (auth.token.email != null && auth.token.email.matches(/.*admin.*/i)))"
      }
    }
  }
}`;

  export default function AdminPanel({ onOpenTenant }: { onOpenTenant: (uid: string, profile: UserProfile) => void }) {
    const { notify } = useApp();
    const [users, setUsers] = useState<AdminUserSummary[]>([]);
    const [q, setQ] = useState("");
    const [loading, setLoading] = useState(true);
    const [modal, setModal] = useState<AdminAction | null>(null);
    const [selected, setSelected] = useState<AdminUserSummary | null>(null);
    const [confirmDelete, setConfirmDelete] = useState(false);
    const [deleting, setDeleting] = useState(false);
    const [form, setForm] = useState({ uid: "", name: "", email: "", phone: "", password: "", subscriptionEnd: "", role: "accountant" as "accountant" | "staff" });
    const [dbError, setDbError] = useState("");
    const [modalError, setModalError] = useState("");
    const [showRules, setShowRules] = useState(false);

    const copyRules = async () => {
      try {
        await navigator.clipboard.writeText(rulesJsonText);
        notify("تم نسخ قواعد Firebase بنجاح! الصقها في Firebase Console > Realtime Database > Rules");
      } catch {
        notify("يرجى نسخ النص يدوياً من المربع أدناه", "warn");
      }
    };

  useEffect(() => {
    const unsub = onValue(
      ref(db, "users"),
      (snap) => {
        const raw = (snap.val() ?? {}) as Record<string, any>;
        const list = Object.entries(raw)
          .filter(([, value]) => value && (value.profile || value.name || value.email || typeof value === "object"))
          .map(([uid, value]) => {
            const prof: UserProfile = value.profile || {
              name: value.name || `مستخدم (${uid.slice(0, 6)})`,
              email: value.email || "—",
              phone: value.phone || "—",
              role: value.role || "accountant",
              status: value.status || "active",
              subscriptionEnd: value.subscriptionEnd || "2099-12-31",
              createdAt: value.createdAt || Date.now(),
            };
            return {
              uid,
              ...prof,
              customersCount: Object.keys(value.customers ?? {}).length,
              entriesCount: Object.keys(value.entries ?? {}).length,
              lastLoginAt: value.settings?.activity?.lastLoginAt,
            };
          });
        setUsers(list);
        setDbError("");
        setLoading(false);
      },
      (error) => {
        console.error("Failed to load users in AdminPanel:", error);
        setLoading(false);
        setDbError("تعذر قراءة قائمة المستخدمين من Firebase [permission-denied]. انسخ محتوى ملف database.rules.json وضعه في Firebase Console > Realtime Database > Rules.");
        notify("تعذر قراءة قائمة المستخدمين من Firebase. تأكد من نشر قواعد قاعدة البيانات.", "warn");
      }
    );
    return () => unsub();
  }, [notify]);

  const shown = useMemo(() => users.filter((u) => !q || u.name.includes(q) || u.email.toLowerCase().includes(q.toLowerCase()) || u.phone.includes(q)), [users, q]);

  const callAdminSilent = async (name: string, payload: object) => {
    try {
      await httpsCallable(functions, name)(payload);
      return true;
    } catch {
      /* إذا لم تكن Cloud Functions منشورة، نعيد false لأننا حدّثنا Realtime Database مباشرة */
      return false;
    }
  };

  /** حذف المستخدم بالكامل: بياناته من Realtime Database + حساب المصادقة عبر Cloud Function */
  const deleteUserFully = async (uid: string, name: string) => {
    setDeleting(true);
    try {
      // 1) حذف كل بيانات المستخدم من قاعدة البيانات
      await remove(ref(db, `users/${uid}`));
      // 2) حذف حساب المصادقة (يتطلب Cloud Function منشورة)
      const authDeleted = await callAdminSilent("adminDeleteUser", { uid });
      setUsers((us) => us.filter((u) => u.uid !== uid));
      setConfirmDelete(false);
      setSelected(null);
      if (authDeleted) {
        notify(`تم حذف «${name}» وبياناته وحساب تسجيل دخوله نهائياً من Firebase`);
      } else {
        notify(`تم حذف بيانات «${name}» من قاعدة البيانات. لإزالة حساب تسجيل الدخول أيضاً: انشر وظيفة adminDeleteUser أو احذفه من Firebase Console ← Authentication`, "warn");
      }
    } catch {
      notify("تعذر حذف المستخدم من قاعدة البيانات", "warn");
    } finally {
      setDeleting(false);
    }
  };

  const openCreate = () => {
    setSelected(null);
    const end = new Date(); end.setFullYear(end.getFullYear() + 1);
    setForm({ uid: "", name: "", email: "", phone: "", password: "", subscriptionEnd: end.toISOString().slice(0, 10), role: "accountant" });
    setModalError("");
    setModal("create");
  };

  const openImport = () => {
    setSelected(null);
    const end = new Date(); end.setFullYear(end.getFullYear() + 1);
    setForm({ uid: "", name: "", email: "", phone: "", password: "", subscriptionEnd: end.toISOString().slice(0, 10), role: "accountant" });
    setModalError("");
    setModal("import");
  };

  const openEdit = (u: AdminUserSummary) => {
    setSelected(u);
    setForm({ uid: u.uid, name: u.name, email: u.email, phone: u.phone, password: "", subscriptionEnd: u.subscriptionEnd.slice(0, 10), role: u.role === "staff" ? "staff" : "accountant" });
    setModalError("");
    setModal("update");
  };

  const setStatus = async (u: AdminUserSummary, status: UserProfile["status"]) => {
    try {
      await update(ref(db, `users/${u.uid}/profile`), { status });
      notify(status === "blocked" ? "تم حظر المستخدم بنجاح" : "تم تفعيل المستخدم بنجاح");
    } catch {
      notify("تعذر تحديث حالة المستخدم. تحقق من قواعد قاعدة البيانات.", "warn");
    }
  };

  const openExtend = (u: AdminUserSummary) => {
    setSelected(u);
    setForm({
      uid: u.uid,
      name: u.name,
      email: u.email,
      phone: u.phone,
      password: "",
      subscriptionEnd: u.subscriptionEnd ? u.subscriptionEnd.slice(0, 10) : new Date().toISOString().slice(0, 10),
      role: u.role === "staff" ? "staff" : "accountant",
    });
    setModalError("");
    setModal("extend");
  };

  const applyQuickExtend = (days: number, months: number = 0, years: number = 0) => {
    if (!selected) return;
    const base = new Date(form.subscriptionEnd || selected.subscriptionEnd || Date.now());
    const now = new Date();
    if (base.getTime() < now.getTime()) base.setTime(now.getTime());
    if (days) base.setDate(base.getDate() + days);
    if (months) base.setMonth(base.getMonth() + months);
    if (years) base.setFullYear(base.getFullYear() + years);
    setForm({ ...form, subscriptionEnd: base.toISOString().slice(0, 10) });
  };

  const submit = async () => {
    setModalError("");
    if (!form.name || !form.email || (modal === "create" && form.password.length < 6)) {
      const msg = "أكمل البيانات المطلوب إدخالها، وكلمة المرور 6 أحرف على الأقل";
      setModalError(msg);
      notify(msg, "warn");
      return;
    }
    if (modal === "import" && !form.uid.trim()) {
      const msg = "أدخل الـ UID الخاص بالمستخدم من Firebase Console > Authentication";
      setModalError(msg);
      notify(msg, "warn");
      return;
    }
    if (modal === "create") {
      try {
        await createTenantUser(form);
        notify("تم إنشاء حساب Authentication وحفظ بيانات المستخدم بنجاح");
        setModal(null);
      } catch (error) {
        const msg = readableCreateUserError(error);
        setModalError(msg);
        notify(msg, "warn");
      }
    } else if (modal === "import") {
      try {
        const cleanUid = form.uid.trim();
        const end = new Date(form.subscriptionEnd || Date.now() + 31536000000);
        await update(ref(db, `users/${cleanUid}/profile`), {
          name: form.name.trim(),
          email: form.email.trim().toLowerCase(),
          phone: form.phone.trim(),
          role: form.role,
          status: "active",
          subscriptionEnd: end.toISOString(),
          createdAt: Date.now(),
        });
        notify("تم ربط الحساب وحفظ ملفه في Realtime Database بنجاح ✓");
        setModal(null);
      } catch {
        const msg = "تعذر الحفظ في قاعدة البيانات [permission-denied]. انسخ محتوى database.rules.json إلى Firebase Console > Realtime Database > Rules.";
        setModalError(msg);
        notify(msg, "warn");
      }
    } else if (modal === "extend" && selected) {
      try {
        const newEnd = new Date(form.subscriptionEnd);
        if (Number.isNaN(newEnd.getTime())) {
          notify("اختر تاريخ انتهاء صالح", "warn");
          return;
        }
        await update(ref(db, `users/${selected.uid}/profile`), {
          subscriptionEnd: newEnd.toISOString(),
          status: "active",
        });
        notify(`تم تمديد اشتراك «${selected.name}» حتى ${DATE(newEnd.toISOString())} بنجاح ✓`);
        setModal(null);
      } catch {
        const msg = "تعذر تمديد الاشتراك. تحقق من قواعد قاعدة البيانات.";
        setModalError(msg);
        notify(msg, "warn");
      }
    } else if (modal === "update" && selected) {
      try {
        await update(ref(db, `users/${selected.uid}/profile`), {
          name: form.name.trim(),
          email: form.email.trim().toLowerCase(),
          phone: form.phone.trim(),
          role: form.role,
          subscriptionEnd: new Date(form.subscriptionEnd).toISOString(),
        });
        const { uid: _ignore, ...rest } = form;
        void callAdminSilent("adminUpdateUser", { uid: selected.uid, ...rest, password: undefined });
        notify("تم تحديث بيانات المستخدم بنجاح");
        setModal(null);
      } catch {
        const msg = "تعذر تحديث بيانات المستخدم في قاعدة البيانات";
        setModalError(msg);
        notify(msg, "warn");
      }
    } else if (modal === "password" && selected) {
      try {
        await httpsCallable(functions, "adminSetPassword")({ uid: selected.uid, password: form.password });
        notify("تم تغيير كلمة المرور بنجاح");
        setModal(null);
      } catch {
        try {
          await sendPasswordResetEmail(auth, selected.email);
          notify(`تم إرسال رابط إعادة تعيين كلمة المرور إلى بريد ${selected.email} بنجاح`);
          setModal(null);
        } catch {
          notify("تعذر تغيير كلمة المرور. انشر Cloud Functions أو تأكد من بريد المستخدم.", "warn");
        }
      }
    }
  };

  return (
    <div>
      <SectionHead title="إدارة المستأجرين" sub="لوحة المدير الوحيدة — إدارة الحسابات والاشتراكات والدخول إلى بيانات المستخدمين" actions={
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setShowRules(!showRules)} className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold"><FileCode size={15} /> قواعد Firebase</button>
          <button onClick={openImport} className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold">ربط حساب Auth موجود</button>
          <button onClick={openCreate} className="btn-gold flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-black"><Plus size={15} /> إنشاء مستخدم</button>
        </div>
      } />
      {(dbError || showRules) && (
        <div className="mb-5 rounded-[22px] border border-[var(--border-gold)] bg-[var(--gold-dim)] p-5 text-start">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border-gold)] pb-3">
            <div>
              <p className="font-display text-sm font-black text-[var(--gold-bright)]">
                {dbError ? "⚠️ تنبيه: قواعد قاعدة البيانات (Firebase Rules) تمنع القراءة حالياً" : "📋 قواعد قاعدة البيانات المطلوبة لحسابك في Firebase Console"}
              </p>
              <p className="mt-1 text-xs text-[var(--muted)]">
                انسخ النص أدناه والصقه في: <span className="font-bold text-[var(--text)]" dir="ltr">Firebase Console &gt; Realtime Database &gt; Rules</span> ثم اضغط <span className="font-bold text-[var(--text)]">Publish</span>
              </p>
            </div>
            <button
              onClick={() => void copyRules()}
              className="btn-gold flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-black"
            >
              <Copy size={14} /> نسخ قواعد Firebase
            </button>
          </div>
          <pre
            className="mt-3 max-h-52 overflow-x-auto rounded-xl bg-[#0d0f14] p-4 text-[11px] leading-5 text-emerald-300 shadow-inner"
            dir="ltr"
          >
            {rulesJsonText}
          </pre>
        </div>
      )}
      <div className="mb-4 grid grid-cols-3 gap-3">
        <Glass gold className="p-4"><p className="text-[10px] text-[var(--muted)]">إجمالي المستخدمين</p><p className="num text-2xl font-black">{NUM(users.length)}</p></Glass>
        <Glass className="p-4"><p className="text-[10px] text-[var(--muted)]">اشتراكات نشطة</p><p className="num text-2xl font-black text-[var(--green)]">{NUM(users.filter((u) => u.status === "active").length)}</p></Glass>
        <Glass className="p-4"><p className="text-[10px] text-[var(--muted)]">محظور / منتهي</p><p className="num text-2xl font-black text-[var(--red)]">{NUM(users.filter((u) => u.status !== "active").length)}</p></Glass>
      </div>
      <Glass className="overflow-hidden">
        <div className="border-b border-[var(--border)] p-4"><div className="relative max-w-sm"><Search className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--faint)]" size={14} /><input className="field w-full rounded-xl py-2 pr-9 text-xs" value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث بالاسم أو البريد أو الهاتف…" /></div></div>
        <div className="overflow-x-auto"><table className="lux-table"><thead><tr><th>المستخدم</th><th>الحالة</th><th>انتهاء الاشتراك</th><th>الوقت المتبقي</th><th>العملاء</th><th>القيود</th><th>آخر دخول</th><th>الإجراءات</th></tr></thead><tbody>
          {shown.map((u) => <tr key={u.uid}>
            <td><p className="font-black">{u.name}</p><p className="text-[10px] text-[var(--muted)]" dir="ltr">{u.email}</p></td>
            <td><Chip label={u.status === "active" ? "نشط" : u.status === "blocked" ? "محظور" : "منتهي"} cls={u.status === "active" ? "chip-green" : "chip-red"} /></td>
            <td className="num text-xs">{u.subscriptionEnd ? u.subscriptionEnd.slice(0, 10) : "—"}</td>
            <td><SubBadge subscriptionEnd={u.subscriptionEnd} /></td>
            <td className="num">{NUM(u.customersCount)}</td><td className="num">{NUM(u.entriesCount)}</td><td className="num text-[var(--muted)]">{u.lastLoginAt ? DATE(new Date(u.lastLoginAt).toISOString()) : "—"}</td>
            <td><div className="flex gap-1">
              <button title="الدخول إلى البيانات" onClick={() => onOpenTenant(u.uid, u)} className="btn-ghost flex h-8 w-8 items-center justify-center rounded-lg"><Eye size={13} /></button>
              <button title="تعديل" onClick={() => openEdit(u)} className="btn-ghost flex h-8 w-8 items-center justify-center rounded-lg"><ShieldCheck size={13} /></button>
              <button title="تمديد / تعديل الاشتراك" onClick={() => openExtend(u)} className="btn-ghost flex h-8 w-8 items-center justify-center rounded-lg"><CalendarPlus size={13} /></button>
              <button title={u.status === "blocked" ? "إلغاء الحظر" : "حظر"} onClick={() => void setStatus(u, u.status === "blocked" ? "active" : "blocked")} className="btn-ghost flex h-8 w-8 items-center justify-center rounded-lg">{u.status === "blocked" ? <UserCheck size={13} /> : <Ban size={13} />}</button>
              <button title="تغيير كلمة المرور" onClick={() => { setSelected(u); setForm({ ...form, password: "" }); setModal("password"); }} className="btn-ghost flex h-8 w-8 items-center justify-center rounded-lg"><KeyRound size={13} /></button>
              <button title="حذف" onClick={() => { setSelected(u); setConfirmDelete(true); }} className="flex h-8 w-8 items-center justify-center rounded-lg text-[var(--red)] hover:bg-[var(--red-soft)]"><Trash2 size={13} /></button>
            </div></td>
          </tr>)}
          {!loading && shown.length === 0 && (
            <tr>
              <td colSpan={7} className="py-12 text-center text-[var(--muted)]">
                <p className="font-display text-base font-black text-[var(--text)]">لا يوجد مستخدمون محفوظون في قاعدة البيانات</p>
                <p className="mt-1 text-xs">اضغط على زر «إنشاء مستخدم» لإضافة أول مستأجر في النظام، أو زر «ربط حساب Auth موجود» لإضافة حساب مسجل في Firebase Console.</p>
              </td>
            </tr>
          )}
        </tbody></table></div>
      </Glass>

      <Modal open={!!modal} onClose={() => setModal(null)} title={modal === "create" ? "إنشاء مستخدم جديد" : modal === "import" ? "ربط حساب Auth موجود" : modal === "password" ? "تغيير كلمة المرور" : modal === "extend" ? "تمديد وتعديل اشتراك المستخدم" : "تعديل المستخدم"}>
        {modalError && (
          <div className="mb-4 rounded-xl border border-[var(--red)] bg-[var(--red-soft)] p-3 text-xs font-bold leading-5 text-[var(--red)]">
            ⚠️ {modalError}
          </div>
        )}
        {modal === "password" ? (
          <L label="كلمة المرور الجديدة"><input type="password" className={inputCls} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></L>
        ) : modal === "extend" && selected ? (
          <div className="space-y-4 text-start">
            <div className="rounded-xl border border-[var(--border-gold)] bg-[var(--gold-dim)] p-3.5">
              <p className="text-xs font-black">المستخدم: {selected.name}</p>
              <p className="mt-0.5 text-[11px] text-[var(--muted)]">الانتهاء الحالي: <span className="num font-bold text-[var(--text)]">{selected.subscriptionEnd ? DATE(selected.subscriptionEnd) : "—"}</span></p>
            </div>
            <div>
              <p className="mb-2 text-xs font-bold text-[var(--muted)]">تمديد سريع (من يوم حتى سنة):</p>
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
                <button type="button" onClick={() => applyQuickExtend(1)} className="btn-ghost rounded-lg py-2 text-[11px] font-black">+ يوم</button>
                <button type="button" onClick={() => applyQuickExtend(7)} className="btn-ghost rounded-lg py-2 text-[11px] font-black">+ 7 أيام</button>
                <button type="button" onClick={() => applyQuickExtend(0, 1)} className="btn-ghost rounded-lg py-2 text-[11px] font-black">+ شهر</button>
                <button type="button" onClick={() => applyQuickExtend(0, 3)} className="btn-ghost rounded-lg py-2 text-[11px] font-black">+ 3 أشهر</button>
                <button type="button" onClick={() => applyQuickExtend(0, 6)} className="btn-ghost rounded-lg py-2 text-[11px] font-black">+ 6 أشهر</button>
                <button type="button" onClick={() => applyQuickExtend(0, 0, 1)} className="btn-ghost rounded-lg py-2 text-[11px] font-black">+ سنة</button>
              </div>
            </div>
            <L label="أو تحديد تاريخ انتهاء مخصص (كتابياً / اختيار من التقويم)">
              <input
                type="date"
                className={inputCls}
                value={form.subscriptionEnd}
                onChange={(e) => setForm({ ...form, subscriptionEnd: e.target.value })}
              />
            </L>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {modal === "import" && (
              <L label="UID المستخدم (من Firebase Console > Authentication)" className="col-span-2">
                <input dir="ltr" className={inputCls} value={form.uid} onChange={(e) => setForm({ ...form, uid: e.target.value })} placeholder="مثال: abc123def456..." />
              </L>
            )}
            <L label="الاسم" className="col-span-2"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></L>
            <L label="البريد" className="col-span-2"><input dir="ltr" className={inputCls} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></L>
            <L label="الهاتف"><input className={inputCls} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></L>
            <L label="الدور"><select className={inputCls} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as "accountant" | "staff" })}><option value="accountant">محاسب</option><option value="staff">موظف</option></select></L>
            <L label="انتهاء الاشتراك"><input type="date" className={inputCls} value={form.subscriptionEnd} onChange={(e) => setForm({ ...form, subscriptionEnd: e.target.value })} /></L>
            {modal === "create" && <L label="كلمة المرور"><input type="password" className={inputCls} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></L>}
          </div>
        )}
        <button onClick={() => void submit()} className="btn-gold mt-6 w-full rounded-xl py-3 text-xs">حفظ وتنفيذ</button>
      </Modal>
      <ConfirmDialog
        open={confirmDelete}
        onClose={() => !deleting && setConfirmDelete(false)}
        busy={deleting}
        onConfirm={() => {
          if (selected) void deleteUserFully(selected.uid, selected.name);
        }}
        variant="danger"
        title="حذف المستخدم نهائياً"
        message={`سيتم حذف حساب ${selected?.name ?? ""} وجميع بياناته من Firebase. لا يمكن التراجع.`}
        confirmLabel="حذف الحساب والبيانات"
      />
    </div>
  );
}