import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, Download, FileSpreadsheet, FileText, Loader2, Printer, TriangleAlert, X } from "lucide-react";
import { downloadExcel } from "../utils/excel";
import { buildSimpleReportHtml, downloadPdfFromHtml } from "../utils/pdf";
import type { TeamUser } from "../data/mock";

/* ============ السياق العام ============ */
export type NotifyKind = "success" | "info" | "warn";
interface AppCtx {
  notify: (msg: string, kind?: NotifyKind) => void;
  user: TeamUser | null;
  tenantUid?: string;
}
const Ctx = createContext<AppCtx>({ notify: () => {}, user: null });
export const AppProvider = Ctx.Provider;
export const useApp = () => useContext(Ctx);

/* ============ عناصر أساسية ============ */
export function Glass({ children, gold, className = "" }: { children: ReactNode; gold?: boolean; className?: string }) {
  return <div className={`rounded-[20px] ${gold ? "glass-gold" : "glass"} ${className}`}>{children}</div>;
}

export function SectionHead({ title, sub, actions }: { title: string; sub?: string; actions?: ReactNode }) {
  return (
    <div className="no-print mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="font-display text-2xl font-extrabold md:text-3xl">{title}</h1>
        {sub && <p className="mt-1 text-sm text-[var(--muted)]">{sub}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Chip({ label, cls }: { label: string; cls: string }) {
  return <span className={`chip ${cls}`}>{label}</span>;
}

export function Delta({ value }: { value: number }) {
  const up = value >= 0;
  return (
    <span className={`chip ${up ? "chip-green" : "chip-red"}`}>
      {up ? "▲" : "▼"} {Math.abs(value)}٪
    </span>
  );
}

/* ============ حقول النماذج ============ */
export function L({ label, children, className = "" }: { label: string; children: ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1.5 block text-xs font-bold text-[var(--muted)]">{label}</span>
      {children}
    </label>
  );
}
export const inputCls = "field w-full rounded-xl px-3.5 py-2.5 text-sm";

/**
 * معالج التنقل بلوحة المفاتيح في النماذج:
 * - عند الضغط على "التالي" (Next / Enter): ينقل التركيز للحقل التالي في النموذج.
 * - عند الضغط على "الذهاب" (Go / Done / Enter في الحقل الأخير): ينفذ عملية الحفظ (onGo).
 */
export function handleNextOrGo(
  e: React.KeyboardEvent<HTMLElement>,
  onGo?: () => void
) {
  if (e.key !== "Enter") return;
  if (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.currentTarget.tagName.toLowerCase() === "textarea" && !e.ctrlKey) return;

  e.preventDefault();
  const container = e.currentTarget.closest(
    "div[role='dialog'], form, .glass, .modal-content, [data-form='true']"
  );
  if (!container) {
    if (onGo) onGo();
    return;
  }

  const focusables = Array.from(
    container.querySelectorAll<HTMLElement>(
      "input:not([disabled]):not([type='hidden']):not([readonly]), select:not([disabled]):not([readonly]), textarea:not([disabled]):not([readonly]), button[data-field='true']:not([disabled])"
    )
  ).filter(
    (el) =>
      el.offsetParent !== null &&
      !el.getAttribute("disabled") &&
      el.tabIndex !== -1
  );

  const isGoHint =
    e.currentTarget.getAttribute("enterkeyhint") === "go" ||
    e.currentTarget.getAttribute("enterkeyhint") === "done";
  const index = focusables.indexOf(e.currentTarget as HTMLElement);

  if (!isGoHint && index !== -1 && index < focusables.length - 1) {
    focusables[index + 1].focus();
  } else {
    if (onGo) onGo();
  }
}

/* ============ المودال ============ */
export function Modal({
  open, onClose, title, children, wide, onSubmit,
}: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean; onSubmit?: () => void }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/55 p-4 backdrop-blur-sm md:p-10"
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            initial={{ opacity: 0, y: 26, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            className={`glass relative my-auto w-full ${wide ? "max-w-3xl" : "max-w-lg"} rounded-[22px] p-6`}
            onKeyDown={onSubmit ? (e) => handleNextOrGo(e, onSubmit) : undefined}
          >
            <div className="mb-5 flex items-center justify-between">
              <h3 className="font-display text-xl font-extrabold">{title}</h3>
              <button onClick={onClose} className="btn-ghost flex h-8 w-8 items-center justify-center rounded-full" aria-label="إغلاق">
                <X size={15} />
              </button>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ============ نافذة تأكيد موحدة للعمليات الحساسة ============ */
export function ConfirmDialog({
  open,
  title,
  message,
  detail,
  confirmLabel = "تأكيد العملية",
  variant = "gold",
  busy = false,
  onConfirm,
  onClose,
}: {
  open: boolean;
  title: string;
  message: string;
  detail?: string;
  confirmLabel?: string;
  variant?: "gold" | "danger";
  busy?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  const danger = variant === "danger";
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            initial={{ opacity: 0, y: 22, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.96 }}
            transition={{ type: "spring", stiffness: 420, damping: 31 }}
            className="glass w-full max-w-md rounded-[22px] p-6 text-center"
          >
            <span className={`mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border ${danger ? "border-[var(--red)] bg-[var(--red-soft)] text-[var(--red)]" : "border-[var(--border-gold)] bg-[var(--gold-dim)] text-[var(--gold-bright)]"}`}>
              {danger ? <TriangleAlert size={24} /> : <CheckCircle2 size={24} />}
            </span>
            <h3 className="mt-4 font-display text-xl font-extrabold">{title}</h3>
            <p className="mt-2 text-sm font-bold leading-6 text-[var(--muted)]">{message}</p>
            {detail && (
              <p className={`num mt-3 rounded-xl border px-4 py-3 text-sm font-black ${danger ? "border-[var(--red)] bg-[var(--red-soft)] text-[var(--red)]" : "border-[var(--border-gold)] bg-[var(--gold-dim)] text-[var(--gold-bright)]"}`}>
                {detail}
              </p>
            )}
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button onClick={onClose} disabled={busy} className="btn-ghost rounded-xl px-4 py-2.5 text-xs font-bold disabled:opacity-50">إلغاء</button>
              <button
                onClick={onConfirm}
                disabled={busy}
                className={`flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-black transition-all active:scale-95 disabled:opacity-60 ${danger ? "bg-[var(--red)] text-white shadow-[0_8px_22px_var(--red-soft)] hover:brightness-110" : "btn-gold"}`}
              >
                {busy && (
                  <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" />
                )}
                {busy ? "جارٍ التنفيذ…" : confirmLabel}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ============ شريط التصدير والطباعة ============ */
export function ExportBar({ name, rows, extra }: { name: string; rows?: (string | number)[][]; extra?: ReactNode }) {
  const { notify } = useApp();
  const [previewOpen, setPreviewOpen] = useState(false);
  const hasRows = !!rows && rows.length > 0;

  return (
    <div className="no-print flex flex-wrap items-center gap-2">
      {extra}
      <button
        className="btn-ghost flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold"
        onClick={() => window.print()}
      >
        <Printer size={14} /> طباعة
      </button>
      {rows && (
        <button
          className="btn-ghost flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold"
          onClick={() => {
            try {
              downloadExcel(rows, name);
              notify("تم تنزيل ملف Excel (.xlsx) بنجاح");
            } catch {
              notify("تعذر إنشاء ملف Excel", "warn");
            }
          }}
        >
          <FileSpreadsheet size={14} className="text-[var(--green)]" /> Excel
        </button>
      )}
      <button
        className="btn-ghost flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold"
        onClick={() => (hasRows ? setPreviewOpen(true) : notify("لا توجد بيانات لتصديرها إلى PDF", "warn"))}
      >
        <FileText size={14} className="text-[var(--red)]" /> PDF
      </button>
      {hasRows && rows && (
        <PdfPreviewModal
          open={previewOpen}
          onClose={() => setPreviewOpen(false)}
          html={buildSimpleReportHtml(name, "نظام الرفاه المحاسبي", rows)}
          filename={name}
          title={name}
        />
      )}
    </div>
  );
}

/* ============ نافذة معاينة PDF قبل التنزيل ============ */
export function PdfPreviewModal({
  open, onClose, html, filename, title,
}: { open: boolean; onClose: () => void; html: string; filename: string; title: string }) {
  const { notify } = useApp();
  const [busy, setBusy] = useState(false);
  const frameRef = useRef<HTMLIFrameElement>(null);
  const [frameH, setFrameH] = useState(1123);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const fitHeight = () => {
    try {
      const doc = frameRef.current?.contentWindow?.document;
      if (doc?.body) setFrameH(Math.max(doc.body.scrollHeight + 4, 640));
    } catch { /* تجاهل */ }
  };

  const doDownload = async () => {
    setBusy(true);
    notify("جارٍ تجهيز ملف PDF…");
    try {
      await downloadPdfFromHtml(html, filename);
      notify("تم تنزيل ملف PDF بنجاح");
    } catch (err) {
      if (err instanceof Error && err.message === "fallback-opened") {
        notify("فُتح التقرير في نافذة جديدة — احفظه كـ PDF");
      } else {
        notify("تعذر إنشاء ملف PDF", "warn");
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-black/75 p-3 backdrop-blur-sm md:p-6"
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            initial={{ opacity: 0, y: 28, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 380, damping: 30 }}
            className="glass flex h-[88vh] w-full max-w-4xl flex-col overflow-hidden rounded-[22px]"
          >
            {/* شريط الأدوات */}
            <div className="flex flex-wrap items-center gap-3 border-b border-[var(--border)] px-4 py-3 md:px-5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--red-soft)] text-[var(--red)]">
                <FileText size={16} />
              </span>
              <div className="min-w-0">
                <p className="truncate text-sm font-black">{title}</p>
                <p className="num text-[10px] font-bold text-[var(--muted)]">معاينة قبل التنزيل · {filename}.pdf</p>
              </div>
              <div className="ms-auto flex items-center gap-2">
                <button
                  onClick={() => frameRef.current?.contentWindow?.print()}
                  className="btn-ghost flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold"
                >
                  <Printer size={14} /> طباعة
                </button>
                <button
                  onClick={() => void doDownload()}
                  disabled={busy}
                  className="btn-gold flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-black disabled:opacity-60"
                >
                  {busy ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
                  {busy ? "جارٍ التجهيز…" : "تنزيل PDF"}
                </button>
                <button onClick={onClose} className="btn-ghost flex h-8 w-8 items-center justify-center rounded-full" aria-label="إغلاق">
                  <X size={15} />
                </button>
              </div>
            </div>

            {/* مسرح الورقة */}
            <div
              className="relative flex-1 overflow-auto p-4 md:p-8"
              style={{
                background:
                  "radial-gradient(rgba(255,255,255,0.055) 1px, transparent 1px) 0 0 / 22px 22px, linear-gradient(180deg, rgba(8,10,16,0.55), rgba(8,10,16,0.25))",
              }}
            >
              <div className="mx-auto w-full max-w-[794px] overflow-hidden rounded-[6px] bg-white shadow-[0_30px_80px_rgba(0,0,0,0.55)] ring-1 ring-black/25">
                <iframe
                  ref={frameRef}
                  srcDoc={html}
                  title={title}
                  onLoad={fitHeight}
                  className="block w-full border-0 bg-white"
                  style={{ height: frameH }}
                />
              </div>
              <p className="mt-4 text-center text-[10px] font-bold text-[var(--faint)]">
                مقاس A4 · ما تراه هنا هو ما سيُنزَّل بالضبط
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ============ حالة فارغة ============ */
export function EmptyState({ icon, text }: { icon: ReactNode; text: string }) {
  return (
    <div className="flex flex-col items-center gap-3 py-14 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-dashed border-[var(--border-gold)] text-[var(--gold)]">
        {icon}
      </div>
      <p className="text-sm text-[var(--muted)]">{text}</p>
    </div>
  );
}

/* ============ شعار التطبيق (مربع متدرج بنفسجي→أزرق مع رمز أبيض) ============ */
export function BrandLogo({ className = "" }: { className?: string }) {
  const id = "brand-grad";
  return (
    <svg viewBox="0 0 100 100" className={className} aria-label="شعار التطبيق" role="img">
      <defs>
        <linearGradient id={id} x1="0.15" y1="0" x2="0.85" y2="1">
          <stop offset="0" stopColor="#8f7bf7" />
          <stop offset="0.45" stopColor="#5b86f6" />
          <stop offset="1" stopColor="#2e8cf6" />
        </linearGradient>
        <linearGradient id={`${id}-hl`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.28" />
          <stop offset="0.5" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect x="4" y="4" width="92" height="92" rx="26" fill={`url(#${id})`} />
      <rect x="4" y="4" width="92" height="92" rx="26" fill={`url(#${id}-hl)`} />
      {/* الرمز الأبيض: خطافان منحنيان */}
      <path
        d="M31 41 C45 32.5 60 31.5 65.5 35.5 C68.5 38 68.5 47 67.2 62.5"
        fill="none"
        stroke="#ffffff"
        strokeWidth="9.5"
        strokeLinecap="round"
      />
      <path
        d="M33.5 60 C40.5 55.8 46.5 55 49.5 57 C51.5 58.5 51.5 63 50.2 67.5"
        fill="none"
        stroke="#ffffff"
        strokeWidth="7"
        strokeLinecap="round"
      />
    </svg>
  );
}

/* ============ رسم شرارة مصغر ============ */
export function Spark({ points, color = "var(--gold)" }: { points: number[]; color?: string }) {
  const max = Math.max(...points, 1);
  return (
    <svg viewBox="0 0 64 22" className="h-6 w-16" aria-hidden="true">
      {points.map((p, i) => {
        const h = 4 + (p / max) * 18;
        return (
          <rect
            key={i}
            x={i * (64 / points.length) + 1.5}
            y={22 - h}
            width={64 / points.length - 3}
            height={h}
            rx={1.5}
            fill={color}
            opacity={0.25 + (i / points.length) * 0.75}
          />
        );
      })}
    </svg>
  );
}
