import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArchiveRestore, Clock, Landmark, Search, Trash2, Wallet } from "lucide-react";
import { TRASH_TTL_MS, type BankAccount, type BankMove, type CashboxAccount, type CashMove, type TrashItem, type TrashItemType } from "../data/mock";
import { DATE, NUM } from "../utils/format";
import { ConfirmDialog, Glass, SectionHead, useApp } from "./ui";
import { useTenantState } from "../lib/tenant";

const EMPTY_TRASH: TrashItem[] = [];

/** عدد الأيام المتبقية قبل الحذف الدائم */
function daysLeft(expiresAt: number) {
  return Math.max(0, Math.ceil((expiresAt - Date.now()) / 86400000));
}

/** شريحة الوقت المتبقي */
function ExpiryChip({ expiresAt }: { expiresAt: number }) {
  const days = daysLeft(expiresAt);
  const cls =
    days <= 3
      ? "chip-red"
      : days <= 10
        ? "chip-gold"
        : "chip-gray";
  return (
    <span className={`chip ${cls} flex items-center gap-1`}>
      <Clock size={10} />
      {days === 0 ? "تنتهي اليوم" : `${NUM(days)} يوم`}
    </span>
  );
}

const TYPE_LABEL: Record<TrashItemType, string> = {
  cashbox: "صندوق نقدي",
  bank: "حساب بنكي",
  cashMove: "حركة صندوق",
  bankMove: "حركة بنكية",
};

const TYPE_ICON: Record<TrashItemType, typeof Wallet> = {
  cashbox: Wallet,
  bank: Landmark,
  cashMove: Wallet,
  bankMove: Landmark,
};

const TYPE_COLOR: Record<TrashItemType, string> = {
  cashbox: "var(--gold-bright)",
  bank: "var(--sky)",
  cashMove: "var(--green)",
  bankMove: "var(--sky)",
};

/** إضافة عنصر للسلة */
export function moveToTrash(
  setTrash: (fn: (prev: TrashItem[]) => TrashItem[]) => void,
  type: TrashItemType,
  label: string,
  detail: string,
  data: CashboxAccount | BankAccount | CashMove | BankMove,
  originalId: string
) {
  const now = Date.now();
  const item: TrashItem = {
    id: `trash_${now}_${Math.random().toString(36).slice(2, 7)}`,
    originalId,
    type,
    label,
    detail,
    deletedAt: now,
    expiresAt: now + TRASH_TTL_MS,
    data,
  };
  setTrash((prev) => [item, ...prev.filter((t) => t.id !== item.id)]);
}

export default function TrashBin() {
  const { notify, tenantUid } = useApp();
  const [trash, setTrash] = useTenantState<TrashItem[]>(tenantUid, "treasury/trash", EMPTY_TRASH);
  const [q, setQ] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | TrashItemType>("all");
  const [restoring, setRestoring] = useState<TrashItem | null>(null);
  const [deleting, setDeleting] = useState<TrashItem | null>(null);

  // استعادة حالة الصناديق والبنوك والحركات لتحديثها عند الاستعادة
  const [, setCashboxes] = useTenantState<CashboxAccount[]>(tenantUid, "treasury/cashboxes", []);
  const [, setBanks] = useTenantState<BankAccount[]>(tenantUid, "treasury/banks", []);
  const [, setCashMoves] = useTenantState<CashMove[]>(tenantUid, "treasury/cashMoves", []);
  const [, setBankMoves] = useTenantState<BankMove[]>(tenantUid, "treasury/bankMoves", []);

  // تنظيف تلقائي للعناصر المنتهية
  const active = useMemo(() => trash.filter((t) => t.expiresAt > Date.now()), [trash]);
  const expired = useMemo(() => trash.filter((t) => t.expiresAt <= Date.now()), [trash]);

  const shown = useMemo(() => {
    return active
      .filter((t) => {
        if (typeFilter !== "all" && t.type !== typeFilter) return false;
        if (!q) return true;
        return t.label.includes(q) || (t.detail ?? "").includes(q);
      })
      .sort((a, b) => b.deletedAt - a.deletedAt);
  }, [active, q, typeFilter]);

  const restore = (item: TrashItem) => {
    switch (item.type) {
      case "cashbox":
        setCashboxes((prev) => [item.data as CashboxAccount, ...prev.filter((c) => c.id !== item.originalId)]);
        break;
      case "bank":
        setBanks((prev) => [item.data as BankAccount, ...prev.filter((b) => b.id !== item.originalId)]);
        break;
      case "cashMove":
        setCashMoves((prev) => [item.data as CashMove, ...prev.filter((m) => m.id !== item.originalId)]);
        break;
      case "bankMove":
        setBankMoves((prev) => [item.data as BankMove, ...prev.filter((m) => m.id !== item.originalId)]);
        break;
    }
    setTrash((prev) => prev.filter((t) => t.id !== item.id));
    notify(`تم استعادة «${item.label}» إلى قسمه الأصلي بنجاح`);
    setRestoring(null);
  };

  const deletePermanently = (item: TrashItem) => {
    if (daysLeft(item.expiresAt) > 0) {
      notify(`لا يمكن الحذف الدائم — تبقى ${NUM(daysLeft(item.expiresAt))} يوم قبل انتهاء المهلة`, "warn");
      return;
    }
    setTrash((prev) => prev.filter((t) => t.id !== item.id));
    notify(`تم حذف «${item.label}» نهائياً`);
    setDeleting(null);
  };

  const purgeExpired = () => {
    setTrash((prev) => prev.filter((t) => t.expiresAt > Date.now()));
    notify(`تم تنظيف ${NUM(expired.length)} عنصر منتهي المدة نهائياً`);
  };

  return (
    <div className="space-y-5">
      <SectionHead
        title="سلة المهملات 🗑️"
        sub={`العناصر المحذوفة تُحفظ 30 يوماً ثم تُحذف نهائياً — ${NUM(active.length)} عنصر نشط`}
        actions={
          expired.length > 0 ? (
            <button onClick={purgeExpired} className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold text-[var(--red)]">
              <Trash2 size={14} /> مسح المنتهية ({NUM(expired.length)})
            </button>
          ) : undefined
        }
      />

      {/* إحصائيات */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "إجمالي السلة", value: active.length, color: "var(--text)" },
          { label: "صناديق محذوفة", value: active.filter((t) => t.type === "cashbox").length, color: "var(--gold-bright)" },
          { label: "بنوك محذوفة", value: active.filter((t) => t.type === "bank").length, color: "var(--sky)" },
          { label: "حركات محذوفة", value: active.filter((t) => t.type === "cashMove" || t.type === "bankMove").length, color: "var(--muted)" },
        ].map((s) => (
          <Glass key={s.label} className="rounded-[18px] px-4 py-3">
            <p className="text-[10px] font-bold text-[var(--muted)]">{s.label}</p>
            <p className="num mt-1 font-display text-xl font-black" style={{ color: s.color }}>{NUM(s.value)}</p>
          </Glass>
        ))}
      </div>

      {/* شريط الفلاتر والبحث */}
      <Glass className="overflow-hidden rounded-[20px]">
        <div className="flex flex-wrap items-center gap-3 border-b border-[var(--border)] px-5 py-3.5">
          <div className="flex gap-1 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1">
            {(["all", "cashbox", "bank", "cashMove", "bankMove"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTypeFilter(t)}
                className={`rounded-lg px-3 py-1.5 text-[10px] font-black transition-all ${typeFilter === t ? "bg-gradient-to-l from-[var(--gold-bright)] to-[var(--gold)] text-[#171207]" : "text-[var(--muted)] hover:text-[var(--text)]"}`}
              >
                {t === "all" ? "الكل" : TYPE_LABEL[t]}
              </button>
            ))}
          </div>
          <div className="relative w-full max-w-xs">
            <Search size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--faint)]" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="بحث بالاسم أو التفاصيل…"
              className="field w-full rounded-xl py-2 pr-9 ps-3 text-xs"
            />
          </div>
          <p className="ms-auto text-[11px] font-bold text-[var(--muted)]">
            {NUM(shown.length)} عنصر
          </p>
        </div>

        {shown.length === 0 ? (
          <div className="flex flex-col items-center gap-3 py-16 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-dashed border-[var(--border)] text-[var(--faint)]">
              <Trash2 size={22} />
            </span>
            <p className="text-sm text-[var(--muted)]">سلة المهملات فارغة</p>
          </div>
        ) : (
          <div className="max-h-[58vh] overflow-auto">
            <table className="lux-table">
              <thead>
                <tr>
                  <th>النوع</th>
                  <th>العنصر</th>
                  <th>التفاصيل</th>
                  <th>تاريخ الحذف</th>
                  <th>الوقت المتبقي</th>
                  <th className="no-print">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence initial={false}>
                  {shown.map((item) => {
                    const Icon = TYPE_ICON[item.type];
                    const days = daysLeft(item.expiresAt);
                    const canDelete = days === 0;
                    return (
                      <motion.tr
                        key={item.id}
                        layout
                        initial={{ opacity: 0, y: -8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ duration: 0.22 }}
                      >
                        <td>
                          <span className="flex items-center gap-1.5">
                            <span
                              className="flex h-7 w-7 items-center justify-center rounded-lg border"
                              style={{
                                color: TYPE_COLOR[item.type],
                                borderColor: "color-mix(in srgb, currentColor 30%, transparent)",
                                background: "color-mix(in srgb, currentColor 10%, transparent)",
                              }}
                            >
                              <Icon size={13} />
                            </span>
                            <span className="text-[10px] font-bold text-[var(--muted)]">{TYPE_LABEL[item.type]}</span>
                          </span>
                        </td>
                        <td className="font-black">{item.label}</td>
                        <td className="text-[var(--muted)]">{item.detail || "—"}</td>
                        <td className="num text-[var(--muted)]">{DATE(new Date(item.deletedAt).toISOString())}</td>
                        <td><ExpiryChip expiresAt={item.expiresAt} /></td>
                        <td className="no-print">
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => setRestoring(item)}
                              className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[10px] font-black text-[var(--green)] hover:bg-[var(--green-soft)] transition-colors"
                              title="استعادة العنصر"
                            >
                              <ArchiveRestore size={13} /> استعادة
                            </button>
                            <button
                              onClick={() => canDelete ? setDeleting(item) : notify(`لا يمكن الحذف الدائم — تبقى ${NUM(days)} يوم`, "warn")}
                              className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[10px] font-black transition-colors ${canDelete ? "text-[var(--red)] hover:bg-[var(--red-soft)]" : "cursor-not-allowed text-[var(--faint)]"}`}
                              title={canDelete ? "حذف نهائي" : `الحذف الدائم متاح بعد ${NUM(days)} يوم`}
                            >
                              <Trash2 size={13} /> {canDelete ? "حذف نهائي" : `بعد ${NUM(days)} ي`}
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    );
                  })}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        )}
      </Glass>

      {/* تنبيه العناصر المنتهية */}
      {expired.length > 0 && (
        <Glass className="rounded-[18px] border border-[var(--red)] bg-[var(--red-soft)] px-5 py-4">
          <p className="text-xs font-black text-[var(--red)]">
            ⚠️ {NUM(expired.length)} عنصر انتهت مدته وسيُحذف نهائياً — اضغط «مسح المنتهية» لتنظيف السلة.
          </p>
        </Glass>
      )}

      {/* تأكيد الاستعادة */}
      <ConfirmDialog
        open={!!restoring}
        onClose={() => setRestoring(null)}
        onConfirm={() => restoring && restore(restoring)}
        variant="gold"
        title="استعادة العنصر"
        message={`هل تريد استعادة «${restoring?.label ?? ""}» وإعادته إلى قسمه الأصلي؟`}
        confirmLabel="نعم، استعادة"
      />

      {/* تأكيد الحذف الدائم */}
      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={() => deleting && deletePermanently(deleting)}
        variant="danger"
        title="حذف نهائي لا يمكن التراجع عنه"
        message={`هل أنت متأكد من حذف «${deleting?.label ?? ""}» نهائياً؟ لا يمكن استعادته بعد ذلك.`}
        confirmLabel="حذف نهائياً"
      />
    </div>
  );
}
