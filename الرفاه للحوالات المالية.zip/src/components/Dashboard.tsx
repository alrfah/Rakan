import { useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowLeftRight, BarChart3, BookOpenCheck, CircleDollarSign, HandCoins, LayoutGrid,
  Landmark, PiggyBank, ReceiptText, Scissors, Settings, Trash2, TrendingDown, TrendingUp, Truck, Users, Wallet,
} from "lucide-react";
import { DAILY_FLOW, ENTRIES as EMPTY_ENTRIES, EXPENSE_BREAKDOWN, INVOICES as EMPTY_INVOICES, INVOICE_STATUS_CHIP, INVOICE_STATUS_LABEL, MONTHLY_FLOW, YEARLY_FLOW, accountName, type Debt, type Invoice, type JournalEntry, type Partner } from "../data/mock";
import { DATE, NUM, SAR } from "../utils/format";
import { BarsChart, Donut, FlowChart } from "./charts";
import { Chip, Glass, Spark } from "./ui";
import type { SectionId } from "./Shell";
import { useApp } from "./ui";
import { useTenantSnapshot } from "../lib/tenant";

const card = {
  hidden: { opacity: 0, y: 22 },
  show: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.5, ease: [0.2, 0.8, 0.3, 1] as const } }),
};

function Stat({ i, icon: Icon, label, value, sub, delta, spark, gold, accent }: {
  i: number; icon: typeof Wallet; label: string; value: string; sub?: string; delta?: number;
  spark?: number[]; gold?: boolean; accent?: string;
}) {
  return (
    <motion.div variants={card} custom={i} initial="hidden" animate="show" className={`card-hover rounded-[20px] p-5 ${gold ? "glass-gold" : "glass"}`}>
      <div className="flex items-start justify-between">
        <span
          className="flex h-10 w-10 items-center justify-center rounded-xl border"
          style={{
            color: accent ?? "var(--gold-bright)",
            borderColor: "color-mix(in srgb, currentColor 30%, transparent)",
            background: "color-mix(in srgb, currentColor 10%, transparent)",
          }}
        >
          <Icon size={18} />
        </span>
        {delta !== undefined && (
          <span className={`chip ${delta >= 0 ? "chip-green" : "chip-red"}`}>{delta >= 0 ? "▲" : "▼"} {Math.abs(delta)}٪</span>
        )}
      </div>
      <p className="num mt-4 font-display text-[26px] font-black leading-none">{value}</p>
      <p className="mt-1.5 text-xs font-bold text-[var(--muted)]">{label}</p>
      {spark && <div className="mt-3"><Spark points={spark} color={accent ?? "var(--gold)"} /></div>}
      {sub && <p className="mt-3 border-t border-[var(--border)] pt-2.5 text-[11px] font-bold text-[var(--faint)]">{sub}</p>}
    </motion.div>
  );
}

function useDashboardStats() {
  const { tenantUid } = useApp();
  const entries = useTenantSnapshot<JournalEntry[]>(tenantUid, "entries", EMPTY_ENTRIES);
  const invoices = useTenantSnapshot<Invoice[]>(tenantUid, "invoices", EMPTY_INVOICES);
  const customers = useTenantSnapshot<Partner[]>(tenantUid, "customers", []);
  const suppliers = useTenantSnapshot<Partner[]>(tenantUid, "suppliers", []);
  const debts = useTenantSnapshot<Debt[]>(tenantUid, "debts", []);
  const cashboxes = useTenantSnapshot<Array<{ balance: number; currency?: string }>>(tenantUid, "treasury/cashboxes", []);
  const banks = useTenantSnapshot<Array<{ balance: number; currency: string }>>(tenantUid, "treasury/banks", []);
  const cutting = useTenantSnapshot<Array<{ qty: number; buy: number; sell: number }>>(tenantUid, "cutting", []);
  const exIn = useTenantSnapshot<Array<{ kind: "expenses" | "income"; amount: number }>>(tenantUid, "treasury/incomeExpenses", []);

  const cashBalance = cashboxes.reduce((s, b) => s + (b.balance || 0), 0);
  const bankBalance = banks.reduce((s, b) => s + (b.currency === "$" ? b.balance * 3.75 : b.balance), 0);
  const cuttingProfit = cutting.reduce((s, c) => {
    const buyUsd = c.buy > 0 ? c.qty / c.buy : 0;
    const sellUsd = c.sell > 0 ? c.qty / c.sell : 0;
    return s + (sellUsd - buyUsd);
  }, 0);
  const opIncome = exIn.filter((i) => i.kind === "income").reduce((s, i) => s + i.amount, 0);
  const opExpenses = exIn.filter((i) => i.kind === "expenses").reduce((s, i) => s + i.amount, 0);
  const income = opIncome + Math.max(0, cuttingProfit);
  const expenses = opExpenses + Math.max(0, -cuttingProfit);

  const kpi = {
    totalBalance: cashBalance + bankBalance,
    profits: income - expenses,
    expenses,
    debtsFor: debts.filter((d) => d.kind === "for").reduce((s, d) => s + d.amount - d.paid, 0),
    debtsOn: debts.filter((d) => d.kind === "on").reduce((s, d) => s + d.amount - d.paid, 0),
    customers: customers.length,
    suppliers: suppliers.length,
    invoices: invoices.length,
    journalEntries: entries.length,
    cashflow: cashBalance,
  };

  return {
    kpi,
    bankBalance,
    cashBalance,
    entries,
    invoices,
  };
}

export default function Dashboard({ go }: { go: (s: SectionId) => void }) {
  const { kpi, bankBalance, cashBalance } = useDashboardStats();

  return (
    <div className="space-y-6">
      {/* بطاقة إجمالي الرصيد في أعلى الرئيسية */}
      <motion.div variants={card} custom={0} initial="hidden" animate="show" className="card-hover glass-gold flex flex-col justify-between rounded-[22px] p-5 md:p-6">
        <div>
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#171207] text-[var(--gold-bright)]"><CircleDollarSign size={22} /></span>
            <div>
              <p className="text-xs font-bold text-[var(--muted)]">إجمالي الرصيد</p>
              <p className="num font-display text-3xl font-black md:text-4xl">{SAR(kpi.totalBalance)}</p>
            </div>
            <span className="chip chip-gray ms-auto">جاهز للعمل</span>
          </div>
          <p className="mt-3 text-[11px] font-bold leading-5 text-[var(--muted)]">
            لا توجد أرصدة مسجلة بعد — ابدأ بإضافة حساب بنكي أو حركة صندوق
          </p>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-3">
          {[
            { l: "البنوك", v: bankBalance, icon: Landmark },
            { l: "الصندوق", v: cashBalance, icon: Wallet },
            { l: "حوالات معلقة", v: 0, icon: HandCoins },
          ].map((b) => (
            <div key={b.l} className="rounded-xl border border-[var(--border-gold)] bg-[var(--surface)] px-3 py-2.5">
              <p className="flex items-center gap-1.5 text-[10px] font-bold text-[var(--muted)]"><b.icon size={11} /> {b.l}</p>
              <p className="num mt-1 text-sm font-black">{SAR(b.v)}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* شبكة أيقونات الأقسام — نمط تطبيق أندرويد متناسق */}
      <div>
        <div className="mb-3 flex items-center gap-2 text-xs font-black text-[var(--muted)]">
          <LayoutGrid size={15} className="text-[var(--gold)]" />
          <span>أقسام التطبيق السريعة</span>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {[
            { id: "analytics" as const, label: "لوحة التحكم", sub: "إحصائيات ورسوم", icon: BarChart3, color: "#C5A069" },
            { id: "invoices" as const, label: "الحوالات المالية", sub: "إصدار ومتابعة", icon: ReceiptText, color: "#5B8BB5" },
            { id: "customers" as const, label: "العملاء والوكلاء", sub: "كشوف الحساب", icon: Users, color: "#2F9E77" },
            { id: "cutting" as const, label: "القص والاعتماد", sub: "أرباح وعمليات", icon: Scissors, color: "#C9574F" },
            { id: "debts" as const, label: "الدائنون والديون", sub: "مستحقات وواتساب", icon: HandCoins, color: "#C5A069" },
            { id: "cash" as const, label: "الصندوق", icon: Wallet, sub: "إيداع وصرف", color: "#5B8BB5" },
            { id: "banks" as const, label: "البنوك", icon: Landmark, sub: "حسابات وتحويل", color: "#2F9E77" },
            { id: "journal" as const, label: "القيود اليومية", icon: BookOpenCheck, sub: "قيد مزدوج", color: "#C5A069" },
            { id: "reports" as const, label: "التقارير المالية", icon: BarChart3, sub: "12 تقريراً", color: "#5B8BB5" },
            { id: "trash" as const, label: "سلة المهملات", icon: Trash2, sub: "استعادة خلال 30 يوماً", color: "#C9574F" },
            { id: "settings" as const, label: "الإعدادات", icon: Settings, sub: "المنشأة والنسخ", color: "#8A8F98" },
          ].map((app, idx) => (
            <motion.button
              key={app.id}
              onClick={() => go(app.id)}
              whileHover={{ y: -3, scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.04, duration: 0.3 }}
              className="card-hover glass flex flex-col items-center justify-center gap-2 rounded-2xl p-4 text-center transition-all sm:p-5"
            >
              <span
                className="flex h-12 w-12 items-center justify-center rounded-2xl border shadow-md sm:h-14 sm:w-14"
                style={{
                  color: app.color,
                  borderColor: `${app.color}44`,
                  background: `${app.color}18`,
                }}
              >
                <app.icon className="h-6 w-6 sm:h-7 sm:w-7" />
              </span>
              <div>
                <p className="font-display text-xs font-black sm:text-sm">{app.label}</p>
                <p className="mt-0.5 text-[10px] font-bold text-[var(--muted)]">{app.sub}</p>
              </div>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}

export function AnalyticsPanel({ go }: { go: (s: SectionId) => void }) {
  const { kpi, entries, invoices } = useDashboardStats();
  const [range, setRange] = useState<"daily" | "monthly" | "yearly">("daily");
  const flow = range === "daily" ? DAILY_FLOW : range === "monthly" ? MONTHLY_FLOW : YEARLY_FLOW;
  const entryTotal = (e: JournalEntry) => e.lines.reduce((s, l) => s + l.debit, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black md:text-3xl">لوحة التحكم والمؤشرات</h1>
          <p className="mt-1 text-xs text-[var(--muted)] md:text-sm">الرسوم البيانية والمؤشرات المالية التشغيلية لشركة الرفاه</p>
        </div>
        <button onClick={() => go("dashboard")} className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-black">
          <ArrowLeftRight size={14} /> العودة للرئيسية
        </button>
      </div>

      {/* شبكة المؤشرات (بينتو) */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        <Stat i={1} icon={TrendingUp} label="الأرباح (صافي الفترة)" value={SAR(kpi.profits)} delta={0} spark={[0, 0, 0, 0, 0, 0, 0]} accent="var(--green)" sub="محسوبة من حسابات الإيرادات والمصروفات" />
        <Stat i={2} icon={TrendingDown} label="المصروفات (السنة الحالية)" value={SAR(kpi.expenses)} delta={0} spark={[0, 0, 0, 0, 0, 0, 0]} accent="var(--red)" sub="محدّثة لحظياً" />
        <Stat i={3} icon={HandCoins} label="ديون مستحقة لنا" value={SAR(kpi.debtsFor)} spark={[0, 0, 0, 0, 0, 0, 0]} accent="var(--gold)" sub="محدّثة لحظياً" />
        <Stat i={4} icon={Wallet} label="ديون مطلوبة علينا" value={SAR(kpi.debtsOn)} spark={[0, 0, 0, 0, 0, 0, 0]} accent="var(--sky)" sub="محدّثة لحظياً" />
        <Stat i={5} icon={Users} label="العملاء النشطون" value={NUM(kpi.customers)} delta={0} accent="var(--sky)" sub="داخل مساحة المستخدم الحالية" />
        <Stat i={6} icon={Truck} label="الوكلاء والجهات" value={NUM(kpi.suppliers)} delta={0} accent="var(--gold)" sub="داخل مساحة المستخدم الحالية" />
        <Stat i={7} icon={PiggyBank} label="الحوالات المسجلة" value={NUM(kpi.invoices)} delta={0} spark={[0, 0, 0, 0, 0, 0, 0]} accent="var(--green)" sub="محدّثة لحظياً" />
        <Stat i={8} icon={BookOpenCheck} label="القيود اليومية" value={NUM(kpi.journalEntries)} delta={0} spark={[0, 0, 0, 0, 0, 0, 0]} accent="var(--gold)" sub="محدّثة لحظياً" />
      </div>

      {/* الرسوم البيانية */}
      <div className="grid gap-4 xl:grid-cols-3">
        <Glass className="rounded-[20px] p-5 xl:col-span-2">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-lg font-extrabold">التدفق النقدي</h2>
              <p className="text-xs text-[var(--muted)]">مقارنة الداخل والخارج عبر الزمن</p>
            </div>
            <div className="no-print flex rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1">
              {([["daily", "يومي"], ["monthly", "شهري"], ["yearly", "سنوي"]] as const).map(([k, l]) => (
                <button
                  key={k}
                  onClick={() => setRange(k)}
                  className={`relative rounded-lg px-4 py-1.5 text-xs font-black transition-colors ${range === k ? "text-[#171207]" : "text-[var(--muted)] hover:text-[var(--text)]"}`}
                >
                  {range === k && (
                    <motion.span layoutId="range-pill" className="absolute inset-0 rounded-lg bg-gradient-to-l from-[var(--gold-bright)] to-[var(--gold)]" transition={{ type: "spring", stiffness: 420, damping: 34 }} />
                  )}
                  <span className="relative z-10">{l}</span>
                </button>
              ))}
            </div>
          </div>
          <FlowChart key={range} data={flow} aLabel="الداخل" bLabel="الخارج" />
        </Glass>

        <Glass className="rounded-[20px] p-5">
          <h2 className="font-display text-lg font-extrabold">توزيع المصروفات</h2>
          <p className="mb-4 text-xs text-[var(--muted)]">السنة المالية الحالية</p>
          <Donut data={EXPENSE_BREAKDOWN} center="0" centerLabel="إجمالي المصروفات" />
        </Glass>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Glass className="rounded-[20px] p-5 xl:col-span-2">
          <h2 className="mb-1 font-display text-lg font-extrabold">الإيرادات مقابل المصروفات</h2>
          <p className="mb-4 text-xs text-[var(--muted)]">عرض شهري مجمّع لسنة 2025</p>
          <BarsChart data={MONTHLY_FLOW} />
        </Glass>

        {/* آخر القيود */}
        <Glass className="rounded-[20px] p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-lg font-extrabold">آخر القيود</h2>
            <button onClick={() => go("journal")} className="text-[11px] font-black text-[var(--gold)] hover:underline">عرض الكل ←</button>
          </div>
          <ul className="space-y-1">
            {entries.slice(0, 4).map((e) => (
              <li key={e.id} className="group rounded-xl px-2.5 py-2.5 transition-colors hover:bg-[var(--gold-dim)]">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-xs font-black">#{NUM(e.no)} · {e.desc}</p>
                  <span className="num shrink-0 text-xs font-black text-[var(--gold-bright)]">{SAR(entryTotal(e))}</span>
                </div>
                <div className="mt-1 flex items-center justify-between text-[10px] font-bold text-[var(--faint)]">
                  <span>{DATE(e.date)} · {accountName(e.lines[0].accountId)}</span>
                  <Chip label={e.status === "posted" ? "مرحّل" : "مسودة"} cls={e.status === "posted" ? "chip-green" : "chip-gray"} />
                </div>
              </li>
            ))}
          </ul>
        </Glass>
      </div>

      {/* أحدث الحوالات */}
      <Glass className="overflow-hidden rounded-[20px]">
        <div className="flex items-center justify-between px-5 pt-5">
          <h2 className="font-display text-lg font-extrabold">أحدث الحوالات</h2>
          <button onClick={() => go("invoices")} className="no-print text-[11px] font-black text-[var(--gold)] hover:underline">إدارة الحوالات ←</button>
        </div>
        <div className="mt-3 overflow-x-auto">
          <table className="lux-table">
            <thead><tr><th>الرقم</th><th>النوع</th><th>الطرف</th><th>التاريخ</th><th>الإجمالي</th><th>الحالة</th></tr></thead>
            <tbody>
              {invoices.slice(0, 6).map((inv) => (
                <tr key={inv.id} className="cursor-pointer" onClick={() => go("invoices")}>
                  <td className="num font-black text-[var(--gold-bright)]">{inv.no}</td>
                  <td className="text-[var(--muted)]">{inv.type === "sale" ? "حوالة صادرة" : inv.type === "purchase" ? "حوالة واردة" : inv.type === "quote" ? "حوالة أولية" : "حوالة معكوسة"}</td>
                  <td className="font-bold">{inv.party}</td>
                  <td className="num text-[var(--muted)]">{DATE(inv.date)}</td>
                  <td className="num font-black">{SAR(inv.total)}</td>
                  <td><Chip label={INVOICE_STATUS_LABEL[inv.status]} cls={INVOICE_STATUS_CHIP[inv.status]} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Glass>
    </div>
  );
}
