import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDownUp, BarChart3, CalendarDays, Coins, FileDown, FileSpreadsheet, Pencil, Plus, Printer, Scissors, Search, Trash2, X } from "lucide-react";
import { AR_LATN, NUM, DATE } from "../utils/format";
import { downloadExcel } from "../utils/excel";
import { ConfirmDialog, EmptyState, Glass, L, Modal, PdfPreviewModal, inputCls, useApp } from "./ui";
import { useTenantState } from "../lib/tenant";
import { useTenantSnapshot } from "../lib/tenant";
import { DEFAULT_COMPANY_SETTINGS, type CompanySettings } from "../types/settings";

interface CutEntry {
  id: string;
  at: string; // ISO
  seller: string;
  qty: number; // المبلغ (الكمية)
  buy: number; // سعر الشراء
  sell: number; // سعر البيع
}

type PendingAction =
  | { type: "add"; data: Pick<CutEntry, "seller" | "qty" | "buy" | "sell"> }
  | { type: "edit"; id: string; data: Pick<CutEntry, "seller" | "qty" | "buy" | "sell"> }
  | { type: "delete"; entry: CutEntry };

/**
 * المبلغ بالليرة التركية، والأسعار هي عدد الليرات مقابل الدولار.
 * الربح = (المبلغ / سعر البيع) - (المبلغ / سعر الشراء).
 */
const purchaseUsd = (e: Pick<CutEntry, "qty" | "buy">) => (e.buy > 0 ? e.qty / e.buy : 0);
const saleUsd = (e: Pick<CutEntry, "qty" | "sell">) => (e.sell > 0 ? e.qty / e.sell : 0);
const profitOf = (e: Pick<CutEntry, "qty" | "buy" | "sell">) => saleUsd(e) - purchaseUsd(e);
const USD = (n: number) =>
  `${new Intl.NumberFormat(AR_LATN, { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n)} $`;

const EMPTY_ENTRIES: CutEntry[] = [];

const TIME = (iso: string) =>
  new Date(iso).toLocaleTimeString(AR_LATN, { hour: "2-digit", minute: "2-digit" });

const sameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

/* ==================== تصدير PDF — تقرير A4 ==================== */
function buildPdfWindow(entries: CutEntry[], company: CompanySettings) {
  const total = entries.reduce((s, e) => s + profitOf(e), 0);
  const nowStr = new Date().toLocaleString(AR_LATN, {
    weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit",
  });
  const usd = (n: number) => `${new Intl.NumberFormat(AR_LATN, { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n)} $`;

  const rows = entries
    .map((e, i) => `
      <tr class="${i % 2 === 1 ? "alt" : ""}">
        <td>${new Intl.NumberFormat(AR_LATN).format(i + 1)}</td>
        <td>${DATE(e.at)}<br><small>${TIME(e.at)}</small></td>
        <td class="strong">${e.seller}</td>
        <td>${new Intl.NumberFormat(AR_LATN).format(e.qty)}</td>
        <td>${e.buy.toFixed(2)}</td>
        <td>${e.sell.toFixed(2)}</td>
        <td class="profit ${profitOf(e) < 0 ? "neg" : ""}">${usd(profitOf(e))}</td>
      </tr>`)
    .join("");

  return `<!doctype html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8" />
<title>تقرير القص والاعتماد — ${company.companyName}</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@500;700;800;900&display=swap" rel="stylesheet">
<style>
  @page { size: A4; margin: 13mm 12mm; }
  * { box-sizing: border-box; }
  body { font-family: "Cairo", Tahoma, sans-serif; color: #161616; margin: 0; background: #fff; }
  .head { display: flex; align-items: center; justify-content: space-between; border-bottom: 3px solid #C5A069; padding-bottom: 14px; }
  .logo { display: flex; align-items: center; gap: 12px; }
  .mark { width: 52px; height: 52px; border-radius: 12px; background: #161616; color: #C5A069; font-size: 26px; font-weight: 900; display: flex; align-items: center; justify-content: center; }
  .co { font-size: 21px; font-weight: 900; line-height: 1.15; }
  .co small { display: block; font-size: 9px; letter-spacing: 4px; color: #C5A069; font-weight: 700; }
  .meta { text-align: left; font-size: 10.5px; color: #555; line-height: 1.8; }
  h1 { text-align: center; font-size: 22px; margin: 18px 0 2px; font-weight: 900; }
  h2 { text-align: center; font-size: 13px; color: #C5A069; margin: 0 0 4px; font-weight: 800; letter-spacing: 1px; }
  .created { text-align: center; font-size: 10.5px; color: #666; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; border: 1px solid #d8c9a8; border-radius: 10px; overflow: hidden; font-size: 11.5px; }
  thead th { background: #C5A069; color: #141414; padding: 9px 8px; font-weight: 800; border: 1px solid #b8935c; }
  tbody td { padding: 8px; text-align: center; border: 1px solid #e7e2d6; }
  tbody tr.alt { background: #f8f6f1; }
  .strong { font-weight: 800; }
  .profit { font-weight: 900; color: #1e7a52; }
  .profit.neg { color: #b3352e; }
  small { color: #888; font-size: 9px; }
  .summary { display: flex; gap: 12px; margin-top: 16px; }
  .box { flex: 1; border: 1.5px solid #C5A069; border-radius: 10px; padding: 10px 14px; text-align: center; }
  .box .l { font-size: 10.5px; color: #666; font-weight: 700; }
  .box .v { font-size: 17px; font-weight: 900; margin-top: 2px; }
  .box.gold { background: #C5A069; }
  .box.gold .l { color: #3d2f17; }
  .signs { display: flex; justify-content: space-between; margin-top: 46px; font-size: 11.5px; font-weight: 700; }
  .signs div { text-align: center; width: 200px; }
  .signs .line { border-bottom: 1.5px dotted #999; height: 34px; margin-bottom: 6px; }
  .foot { margin-top: 26px; text-align: center; font-size: 9px; color: #999; border-top: 1px solid #eee; padding-top: 8px; }
</style>
</head>
<body>
  <div class="head">
    <div class="logo">
      <div class="mark">ر</div>
      <div class="co">${company.companyName}<small>ALRAFAH TRANSFERS</small></div>
    </div>
    <div class="meta">
      الرقم الضريبي: ${company.taxNumber || "غير محدد"}<br>
      ${company.address}<br>
      هاتف: ${company.phone || "غير محدد"}
    </div>
  </div>
  <h1>${company.companyName}</h1>
  <h2>تقرير القص والاعتماد</h2>
  <p class="created">تاريخ ووقت إنشاء التقرير: ${nowStr}</p>
  <table>
    <thead>
      <tr><th>التسلسل</th><th>التاريخ والوقت</th><th>اسم البائع</th><th>المبلغ (TRY)</th><th>سعر الشراء</th><th>سعر البيع</th><th>الربح (USD)</th></tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="summary">
    <div class="box gold"><div class="l">إجمالي الأرباح بالدولار</div><div class="v">${usd(total)}</div></div>
    <div class="box"><div class="l">إجمالي عدد القيود</div><div class="v">${new Intl.NumberFormat(AR_LATN).format(entries.length)}</div></div>
    <div class="box"><div class="l">متوسط ربح القيد</div><div class="v">${usd(entries.length ? total / entries.length : 0)}</div></div>
  </div>
  <div class="signs">
    <div><div class="line"></div>توقيع المحاسب</div>
    <div><div class="line"></div>اعتماد المدير العام</div>
  </div>
  <p class="foot">أُنشئ هذا التقرير آلياً بواسطة نظام الرفاه للحوالات المالية — مبلغ العملية بالليرة التركية والأرباح بالدولار الأمريكي</p>
  <script>window.onload = function(){ setTimeout(function(){ window.print(); }, 450); }</script>
</body>
</html>`;
}

/* ==================== القسم ==================== */
export default function Cutting() {
  const { notify, tenantUid } = useApp();
  const [entries, setEntries] = useTenantState<CutEntry[]>(tenantUid, "cutting", EMPTY_ENTRIES);
  const company = useTenantSnapshot<CompanySettings>(tenantUid, "settings/company", DEFAULT_COMPANY_SETTINGS);
  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [sort, setSort] = useState<{ key: "date" | "profit"; dir: 1 | -1 }>({ key: "date", dir: -1 });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [entryModal, setEntryModal] = useState(false);
  const [pending, setPending] = useState<PendingAction | null>(null);
  const [form, setForm] = useState({ seller: "", qty: "", buy: "", sell: "" });

  const liveProfit = useMemo(() => {
    const qty = Number(form.qty) || 0;
    const buy = Number(form.buy) || 0;
    const sell = Number(form.sell) || 0;
    return sell > 0 && buy > 0 ? qty / sell - qty / buy : 0;
  }, [form]);
  const profitReady = Number(form.qty) > 0 && Number(form.buy) > 0 && Number(form.sell) > 0;

  /* الإحصائيات الثلاث — تتحدث لحظياً مع كل قيد */
  const stats = useMemo(() => {
    const now = new Date();
    let day = 0, month = 0, year = 0, dayN = 0, monthN = 0, yearN = 0;
    for (const e of entries) {
      const d = new Date(e.at);
      const p = profitOf(e);
      if (sameDay(d, now)) { day += p; dayN++; }
      if (d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth()) { month += p; monthN++; }
      if (d.getFullYear() === now.getFullYear()) { year += p; yearN++; }
    }
    return { day, month, year, dayN, monthN, yearN };
  }, [entries]);

  const shown = useMemo(() => {
    let list = entries.filter((e) => {
      const d = e.at.slice(0, 10);
      return (!q || e.seller.includes(q)) && (!from || d >= from) && (!to || d <= to);
    });
    list = [...list].sort((a, b) => {
      const va = sort.key === "date" ? a.at : profitOf(a);
      const vb = sort.key === "date" ? b.at : profitOf(b);
      return (va < vb ? -1 : va > vb ? 1 : 0) * sort.dir;
    });
    return list;
  }, [entries, q, from, to, sort]);

  const filteredTotal = shown.reduce((s, e) => s + profitOf(e), 0);
  const hasFilter = q !== "" || from !== "" || to !== "";

  const resetForm = () => { setForm({ seller: "", qty: "", buy: "", sell: "" }); setEditingId(null); };

  const submit = () => {
    if (!form.seller.trim()) { notify("اسم البائع مطلوب", "warn"); return; }
    if (!(Number(form.qty) > 0)) { notify("أدخل مبلغاً (كمية) أكبر من صفر", "warn"); return; }
    if (!(Number(form.buy) > 0) || !(Number(form.sell) > 0)) { notify("يجب أن يكون سعرا الشراء والبيع أكبر من صفر", "warn"); return; }
    const data = { seller: form.seller.trim(), qty: Number(form.qty), buy: Number(form.buy), sell: Number(form.sell) };
    setPending(editingId ? { type: "edit", id: editingId, data } : { type: "add", data });
  };

  const confirmAction = () => {
    if (!pending) return;
    if (pending.type === "add") {
      setEntries((es) => [{ id: `c${Date.now()}`, at: new Date().toISOString(), ...pending.data }, ...es]);
      notify(`تم إضافة القيد — الربح المحتسب ${USD(profitOf(pending.data))} ✓`);
      resetForm();
      setEntryModal(false);
    } else if (pending.type === "edit") {
      setEntries((es) => es.map((e) => (e.id === pending.id ? { ...e, ...pending.data } : e)));
      notify(`تم حفظ التعديل — الربح الجديد ${USD(profitOf(pending.data))}`);
      resetForm();
      setEntryModal(false);
    } else {
      setEntries((es) => es.filter((x) => x.id !== pending.entry.id));
      if (editingId === pending.entry.id) resetForm();
      notify(`تم حذف قيد ${pending.entry.seller}`, "info");
    }
    setPending(null);
  };

  const startEdit = (e: CutEntry) => {
    setEditingId(e.id);
    setForm({ seller: e.seller, qty: String(e.qty), buy: String(e.buy), sell: String(e.sell) });
    setEntryModal(true);
  };

  const openAdd = () => {
    resetForm();
    setEntryModal(true);
  };

  const closeEntryModal = () => {
    setEntryModal(false);
    resetForm();
  };

  const remove = (e: CutEntry) => {
    setPending({ type: "delete", entry: e });
  };

  const [previewOpen, setPreviewOpen] = useState(false);
  const previewHtml = useMemo(
    () => buildPdfWindow([...entries].sort((a, b) => (a.at < b.at ? 1 : -1)), company),
    [entries, company]
  );

  const thSortBtn = (key: "date" | "profit", label: string) => (
    <th style={{ background: "#C5A069", color: "#171207" }}>
      <button
        className="flex items-center gap-1 font-extrabold"
        onClick={() => setSort((s) => ({ key, dir: s.key === key ? ((s.dir * -1) as 1 | -1) : -1 }))}
      >
        {label} <ArrowDownUp size={11} className={sort.key === key ? "opacity-100" : "opacity-40"} />
      </button>
    </th>
  );

  const STAT_CARDS = [
    { icon: Coins, label: "الأرباح اليومية", value: stats.day, count: stats.dayN, sub: "قيود اليوم حتى الآن", tint: "var(--gold-bright)" },
    { icon: CalendarDays, label: "الأرباح الشهرية", value: stats.month, count: stats.monthN, sub: "الشهر الميلادي الحالي", tint: "var(--green)" },
    { icon: BarChart3, label: "الأرباح السنوية", value: stats.year, count: stats.yearN, sub: "السنة الحالية", tint: "var(--sky)" },
  ];

  return (
    <div className="flex h-[calc(100dvh-9.5rem)] min-h-[560px] flex-col gap-3 overflow-hidden">
      {/* شريط علوي ثابت: الإجراءات ومؤشرات الأرباح لا تتحرك مع الجدول */}
      <div className="no-print flex shrink-0 justify-end gap-2">
        <button onClick={() => setPreviewOpen(true)} className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-black">
          <FileDown size={15} /> تصدير PDF
        </button>
        <button onClick={openAdd} className="btn-gold flex items-center gap-2 rounded-xl px-5 py-2 text-xs font-black">
          <Plus size={16} /> إضافة قيد
        </button>
      </div>

      <Glass className="grid shrink-0 grid-cols-3 divide-x-reverse divide-x divide-[var(--border)] overflow-hidden rounded-[20px]">
        {STAT_CARDS.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.07, duration: 0.45 }}
            className={`relative flex min-w-0 items-center gap-2 overflow-hidden px-2 py-3 sm:gap-3 sm:px-5 sm:py-4 ${i === 0 ? "bg-[var(--gold-dim)]" : ""}`}
          >
            <span className="relative flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border sm:h-11 sm:w-11 sm:rounded-xl" style={{ color: s.tint, borderColor: "color-mix(in srgb, currentColor 35%, transparent)", background: "color-mix(in srgb, currentColor 12%, transparent)" }}>
              <s.icon className="h-4 w-4 sm:h-[19px] sm:w-[19px]" />
            </span>
            <div className="min-w-0">
              <p className="truncate text-[9px] font-bold text-[var(--muted)] sm:text-xs">{s.label}</p>
              <AnimatePresence mode="popLayout">
                <motion.p
                  key={s.value}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25 }}
                  className="num mt-0.5 truncate font-display text-[11px] font-black leading-tight sm:text-xl"
                  style={{ color: s.value < 0 ? "var(--red)" : s.tint }}
                  title={USD(s.value)}
                >
                  {USD(s.value)}
                </motion.p>
              </AnimatePresence>
              <p className="mt-0.5 hidden text-[9px] font-bold text-[var(--faint)] sm:block">{NUM(s.count)} قيداً</p>
            </div>
          </motion.div>
        ))}
      </Glass>

      {/* جدول القيود */}
      <Glass className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-[20px] shadow-[0_18px_46px_rgba(0,0,0,0.25)]">
        <div className="flex shrink-0 flex-wrap items-center gap-3 border-b border-[var(--border)] px-5 py-3.5">
          <div className="relative w-full max-w-[220px]">
            <Search size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--faint)]" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث باسم البائع…" className="field w-full rounded-xl py-2 pr-9 ps-3 text-xs" />
          </div>
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-[var(--muted)]">
            من <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="field rounded-lg px-2 py-1.5 text-[11px]" />
            إلى <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="field rounded-lg px-2 py-1.5 text-[11px]" />
          </div>
          {hasFilter && (
            <button onClick={() => { setQ(""); setFrom(""); setTo(""); }} className="chip chip-gray cursor-pointer">
              <X size={11} /> مسح الفلاتر
            </button>
          )}
          <div className="no-print ms-auto flex items-center gap-2">
            <button
              onClick={() => window.print()}
              title="طباعة"
              className="btn-ghost flex h-9 w-9 items-center justify-center rounded-xl"
            >
              <Printer size={15} />
            </button>
            <button
              onClick={() => {
                try {
                  downloadExcel(
                    [
                      ["#", "التاريخ", "البائع", "المبلغ (ل.ت)", "سعر الشراء", "سعر البيع", "الربح ($)"],
                      ...shown.map((e, i) => [i + 1, DATE(e.at), e.seller, e.qty, e.buy, e.sell, Number(profitOf(e).toFixed(2))]),
                    ],
                    "سجل-القص-والاعتماد",
                    "القص والاعتماد"
                  );
                  notify("تم تنزيل ملف Excel (.xlsx) بنجاح");
                } catch {
                  notify("تعذر إنشاء ملف Excel", "warn");
                }
              }}
              title="تصدير Excel"
              className="btn-ghost flex h-9 w-9 items-center justify-center rounded-xl text-[var(--green)]"
            >
              <FileSpreadsheet size={15} />
            </button>
            <button
              onClick={() => setPreviewOpen(true)}
              title="معاينة وتصدير PDF"
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#C5A069] text-[#171207] shadow-[0_6px_18px_var(--gold-dim)] transition-all hover:-translate-y-0.5 hover:shadow-[0_10px_26px_rgba(197,160,105,0.45)] active:scale-95"
            >
              <FileDown size={16} />
            </button>
          </div>
        </div>

        <div className="min-h-0 flex-1 overflow-auto">
          <table className="lux-table">
            <thead>
              <tr>
                <th style={{ background: "#C5A069", color: "#171207" }}>التسلسل</th>
                {thSortBtn("date", "التاريخ والوقت")}
                <th style={{ background: "#C5A069", color: "#171207" }}>اسم البائع</th>
                <th style={{ background: "#C5A069", color: "#171207" }}>المبلغ (TRY)</th>
                <th style={{ background: "#C5A069", color: "#171207" }}>سعر الشراء</th>
                <th style={{ background: "#C5A069", color: "#171207" }}>سعر البيع</th>
                {thSortBtn("profit", "الربح (USD)")}
                <th style={{ background: "#C5A069", color: "#171207" }} className="no-print">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence initial={false}>
                {shown.map((e, i) => {
                  const p = profitOf(e);
                  return (
                    <motion.tr
                      key={e.id}
                      layout
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: 30 }}
                      transition={{ duration: 0.25 }}
                      className={editingId === e.id ? "!bg-[var(--gold-dim)]" : ""}
                    >
                      <td className="num font-black text-[var(--faint)]">{NUM(i + 1)}</td>
                      <td>
                        <p className="num text-xs font-bold">{DATE(e.at)}</p>
                        <p className="num text-[10px] text-[var(--faint)]">{TIME(e.at)}</p>
                      </td>
                      <td className="font-black">{e.seller}</td>
                      <td className="num font-bold">{NUM(e.qty)}</td>
                      <td className="num text-[var(--muted)]">{e.buy.toFixed(2)}</td>
                      <td className="num text-[var(--muted)]">{e.sell.toFixed(2)}</td>
                      <td className={`num font-black ${p < 0 ? "text-[var(--red)]" : "text-[var(--green)]"}`}>{USD(p)}</td>
                      <td className="no-print">
                        <span className="flex items-center gap-1">
                          <button onClick={() => startEdit(e)} title="تعديل" className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--gold)] transition-colors hover:bg-[var(--gold-dim)]">
                            <Pencil size={13} />
                          </button>
                          <button onClick={() => remove(e)} title="حذف" className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--red)] transition-colors hover:bg-[var(--red-soft)]">
                            <Trash2 size={13} />
                          </button>
                        </span>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
              {shown.length === 0 && (
                <tr>
                  <td colSpan={8}>
                    <EmptyState icon={<Scissors size={22} />} text={hasFilter ? "لا قيود مطابقة للفلاتر الحالية" : "لا قيود بعد — اضغط زر إضافة قيد"} />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* ملخص أسفل الجدول */}
        <div className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-[var(--border)] bg-[var(--surface)] px-5 py-3.5">
          <p className="text-[11px] font-bold text-[var(--muted)]">
            عدد القيود المعروضة: <span className="num font-black text-[var(--text)]">{NUM(shown.length)}</span> من {NUM(entries.length)}
          </p>
          <p className="text-xs font-black">
            إجمالي الأرباح {hasFilter ? "(بعد الفلترة)" : ""}:{" "}
            <span className={`num font-display text-lg ${filteredTotal < 0 ? "text-[var(--red)]" : "text-[var(--gold-bright)]"}`}>{USD(filteredTotal)}</span>
          </p>
        </div>
      </Glass>

      <Modal open={entryModal} onClose={closeEntryModal} title={editingId ? "تعديل قيد القص والاعتماد" : "إضافة قيد قص واعتماد"} wide onSubmit={submit}>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <L label="اسم البائع" className="sm:col-span-2 lg:col-span-2">
            <input autoFocus className={inputCls} value={form.seller} onChange={(e) => setForm({ ...form, seller: e.target.value })} placeholder="اسم البائع" enterKeyHint="next" />
          </L>
          <L label="المبلغ (ليرة تركية)">
            <input type="number" min={0} className={`${inputCls} num`} value={form.qty} onChange={(e) => setForm({ ...form, qty: e.target.value })} placeholder="0" enterKeyHint="next" />
          </L>
          <L label="سعر الشراء (ليرة / دولار)">
            <input type="number" min={0} step="0.01" className={`${inputCls} num`} value={form.buy} onChange={(e) => setForm({ ...form, buy: e.target.value })} placeholder="0.00" enterKeyHint="next" />
          </L>
          <L label="سعر البيع (ليرة / دولار)">
            <input type="number" min={0} step="0.01" className={`${inputCls} num`} value={form.sell} onChange={(e) => setForm({ ...form, sell: e.target.value })} placeholder="0.00" enterKeyHint="go" />
          </L>
        </div>

        <div className={`mt-5 rounded-xl border px-5 py-4 transition-all duration-300 ${
          profitReady && liveProfit < 0 ? "border-[var(--red)] bg-[var(--red-soft)]" : "border-[var(--border-gold)] bg-[var(--gold-dim)]"
        }`}>
          <p className="text-[10px] font-black tracking-widest text-[var(--muted)]">الأرباح المحسوبة تلقائياً</p>
          <AnimatePresence mode="popLayout">
            <motion.p
              key={profitReady ? liveProfit : "x"}
              initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }}
              className={`num mt-1 font-display text-2xl font-black ${profitReady ? (liveProfit < 0 ? "text-[var(--red)]" : "text-[var(--gold-bright)]") : "text-[var(--faint)]"}`}
            >
              {profitReady ? USD(liveProfit) : "أدخل القيم ليظهر الربح"}
            </motion.p>
          </AnimatePresence>
        </div>

        <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <button onClick={closeEntryModal} className="btn-ghost rounded-xl px-6 py-3 text-xs font-bold">إلغاء</button>
          <button onClick={submit} className="btn-gold flex items-center justify-center gap-2 rounded-xl px-8 py-3 font-display text-sm">
            {editingId ? <><Pencil size={16} /> حفظ التعديل</> : <><Plus size={17} /> إضافة القيد</>}
          </button>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!pending}
        onClose={() => setPending(null)}
        onConfirm={confirmAction}
        variant={pending?.type === "delete" ? "danger" : "gold"}
        title={pending?.type === "add" ? "تأكيد إضافة القيد" : pending?.type === "edit" ? "تأكيد حفظ التعديل" : "تأكيد حذف القيد"}
        message={
          pending?.type === "delete"
            ? `هل تريد حذف قيد «${pending.entry.seller}»؟ لا يمكن التراجع عن هذه العملية.`
            : pending?.type === "edit"
              ? `سيتم تحديث بيانات قيد «${pending.data.seller}» وإعادة احتساب الأرباح تلقائياً.`
              : pending?.type === "add"
                ? `سيتم إضافة قيد جديد باسم «${pending.data.seller}» إلى السجل.`
                : ""
        }
        detail={pending ? (pending.type === "delete" ? `الربح المسجل: ${USD(profitOf(pending.entry))}` : `الربح بعد العملية: ${USD(profitOf(pending.data))}`) : undefined}
        confirmLabel={pending?.type === "add" ? "نعم، إضافة القيد" : pending?.type === "edit" ? "نعم، حفظ التعديل" : "نعم، حذف القيد"}
      />

      <PdfPreviewModal
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        html={previewHtml}
        filename="تقرير-القص-والاعتماد"
        title="تقرير القص والاعتماد"
      />
    </div>
  );
}
