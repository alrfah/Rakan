import { deleteApp, initializeApp } from "firebase/app";
import { createUserWithEmailAndPassword, deleteUser, getAuth, inMemoryPersistence, setPersistence, signOut, updateProfile } from "firebase/auth";
import { ref, set } from "firebase/database";
import { ADMIN_UID, auth, db, firebaseConfig, isAdminAuth } from "./firebase";
import type { UserProfile } from "../types/firebase";

export interface CreateTenantInput {
  name: string;
  email: string;
  phone: string;
  password: string;
  role: "accountant" | "staff";
  subscriptionEnd: string;
}

/**
 * ينشئ المستخدم بواسطة Firebase Web Auth داخل تطبيق ثانوي، لذلك تبقى جلسة المدير
 * الأساسية كما هي. كتابة ملف المستخدم محمية أيضاً بقواعد Realtime Database.
 */
export async function createTenantUser(input: CreateTenantInput) {
  if (!isAdminAuth(auth.currentUser)) throw new Error("admin/permission-denied");
  if (!input.name.trim() || !input.email.trim()) throw new Error("admin/missing-fields");
  if (!input.password) {
    // توليد كلمة مرور تلقائية قوية إذا لم يحددها المستخدم
    input.password = "Rf@" + Math.random().toString(36).slice(2, 10) + "!" + Math.floor(Math.random() * 1000);
  } else if (input.password.length < 6) throw new Error("auth/weak-password");
  const end = new Date(input.subscriptionEnd);
  if (Number.isNaN(end.getTime())) throw new Error("admin/invalid-subscription");

  const secondary = initializeApp(firebaseConfig, `tenant-creator-${Date.now()}`);
  const secondaryAuth = getAuth(secondary);
  await setPersistence(secondaryAuth, inMemoryPersistence);
  let createdUser: Awaited<ReturnType<typeof createUserWithEmailAndPassword>>["user"] | null = null;

  try {
    const credential = await createUserWithEmailAndPassword(
      secondaryAuth,
      input.email.trim().toLowerCase(),
      input.password
    );
    createdUser = credential.user;
    await updateProfile(createdUser, { displayName: input.name.trim() });

    const profile: UserProfile = {
      name: input.name.trim(),
      email: input.email.trim().toLowerCase(),
      phone: input.phone.trim(),
      role: input.role,
      status: "active",
      subscriptionEnd: end.toISOString(),
      createdAt: Date.now(),
    };

    // Realtime Database لا يخزن الكائنات الفارغة؛ تُنشأ الأقسام عند أول عملية.
    await set(ref(db, `users/${createdUser.uid}/profile`), profile);
    await set(ref(db, `users/${createdUser.uid}/settings/system`), {
      initialized: true,
      tenantVersion: 1,
      createdBy: ADMIN_UID,
      createdAt: Date.now(),
    });

    await signOut(secondaryAuth);
    return { uid: createdUser.uid, profile };
  } catch (error) {
    console.error("createTenantUser failed:", error);
    // يمنع بقاء حساب Authentication يتيم إذا فشلت كتابة ملفه في قاعدة البيانات.
    if (createdUser) {
      try { await deleteUser(createdUser); } catch { /* قد يكون الحساب حُذف بالفعل */ }
    }
    throw error;
  } finally {
    try { await signOut(secondaryAuth); } catch { /* لا توجد جلسة */ }
    await deleteApp(secondary);
  }
}

/**
 * ينشئ حساباً فرعياً تابعاً لحساب موجود — مثل موظف أو محاسب ينشئه المدير أو المحاسب.
 * - حساب Firebase Auth حقيقي بكلمة مرور قوية (المستخدم يدخل مباشرة بالايميل + الباسورد).
 * - يحفظ ملفه الشخصي تحت users/{parentUid}/team/{newUid}/profile
 *   ليبقى عزل تام: لا يمكن لحساب فرعي رؤية بيانات غيره أو بيانات المنشئ.
 * - مدة الاشتراك موروثة من المنشئ (تنتهي بانتهاء اشتراكه).
 */
export async function createTeamMember(input: {
  name: string;
  email: string;
  phone: string;
  role: "accountant" | "staff";
  subscriptionEnd: string;
  parentUid: string;
  parentIsAdmin: boolean;
}) {
  if (!isAdminAuth(auth.currentUser)) throw new Error("admin/permission-denied");
  if (!input.name.trim() || !input.email.trim()) throw new Error("admin/missing-fields");
  // كلمة مرور قوية ومولّدة تلقائياً
  const password = "Rf@" + Math.random().toString(36).slice(2, 10) + "!" + Math.floor(Math.random() * 1000);
  const end = new Date(input.subscriptionEnd);
  if (Number.isNaN(end.getTime())) throw new Error("admin/invalid-subscription");

  // استراتيجية الكتابة: نستخدم جلسة المستخدم المنشئ نفسه (admin/auth) لأن قواعد
  // team/{uid} تسمح للمالك بالكتابة. لا نحتاج تطبيقاً ثانوياً لأن
  // المستخدم المنشئ (admin) يحمل صلاحيات الكتابة في مسارات فريقه فقط.
  let createdUser: Awaited<ReturnType<typeof createUserWithEmailAndPassword>>["user"] | null = null;

  // استخدام تطبيق ثانوي فقط لإنشاء الحساب في Auth (حتى لا تنتقل جلسة المستخدم)
  const secondary = initializeApp(firebaseConfig, `team-creator-${Date.now()}`);
  const secondaryAuth = getAuth(secondary);
  await setPersistence(secondaryAuth, inMemoryPersistence);

  try {
    const credential = await createUserWithEmailAndPassword(
      secondaryAuth,
      input.email.trim().toLowerCase(),
      password
    );
    createdUser = credential.user;
    await updateProfile(createdUser, { displayName: input.name.trim() });

    const profile: UserProfile & { parentUid: string } = {
      name: input.name.trim(),
      email: input.email.trim().toLowerCase(),
      phone: input.phone.trim(),
      role: input.role,
      status: "active",
      subscriptionEnd: end.toISOString(),
      createdAt: Date.now(),
      parentUid: input.parentUid,
    };

    // 1) حفظ بيانات الفريق تحت المستخدم المنشئ (مسار المالك).
    await set(
      ref(db, `users/${input.parentUid}/team/${createdUser.uid}/profile`),
      profile
    );
    // 2) حفظ نسخة عامة قابلة للقراءة من أي حساب في team_members/{uid}
    //    حتى يستطيع الحساب الفرعي قراءة ملفه الشخصي عند تسجيل الدخول.
    await set(ref(db, `team_members/${createdUser.uid}`), profile);
    // 3) فهرس البحث بالبريد ليستطيع التطبيق إيجاد ملف المستخدم الفرعي
    //    عند تسجيل دخوله (lookup by email).
    await set(
      ref(db, `team_index/${input.email.trim().toLowerCase().replace(/[.#$\[\]/]/g, "_")}`),
      { subUid: createdUser.uid, parentUid: input.parentUid, createdAt: Date.now() }
    );

    await signOut(secondaryAuth);
    return { uid: createdUser.uid, password, profile };
  } catch (error) {
    console.error("createTeamMember failed:", error);
    if (createdUser) {
      try { await deleteUser(createdUser); } catch { /* */ }
    }
    throw error;
  } finally {
    try { await signOut(secondaryAuth); } catch { /* */ }
    await deleteApp(secondary);
  }
}

export function readableCreateUserError(error: unknown) {
  const code = typeof error === "object" && error && "code" in error ? String(error.code) : error instanceof Error ? error.message : String(error);
  if (code.includes("email-already-in-use")) return "البريد الإلكتروني مستخدم في حساب آخر.";
  if (code.includes("invalid-email")) return "صيغة البريد الإلكتروني غير صحيحة.";
  if (code.includes("weak-password")) return "كلمة المرور ضعيفة؛ استخدم 6 أحرف على الأقل.";
  if (code.includes("operation-not-allowed") || code.includes("configuration-not-found")) return "فعّل تسجيل الدخول بالبريد وكلمة المرور من Firebase Authentication.";
  if (code.includes("permission-denied") || code.includes("PERMISSION_DENIED")) return "قواعد Realtime Database تمنع الحفظ [permission-denied]. انسخ القواعد من database.rules.json وضعها في Firebase Console.";
  if (code.includes("network-request-failed")) return "تعذر الاتصال بـ Firebase. تحقق من الإنترنت.";
  return `تعذر إنشاء المستخدم (${code}). تأكد من تفعيل Email/Password ونشر قواعد Realtime Database.`;
}