/* هياكل نظام الرفاه للحوالات المالية — تبدأ جميع البيانات التشغيلية من الصفر */

export type AccountType = "assets" | "liabilities" | "equity" | "income" | "expenses";

export interface Account {
  id: string;
  code: string;
  name: string;
  type: AccountType;
  parentId: string | null;
  balance: number; // موجب = مدين
  system?: boolean;
}

export interface JournalLine {
  accountId: string;
  debit: number;
  credit: number;
}

export interface JournalEntry {
  id: string;
  no: number;
  date: string;
  ref: string;
  desc: string;
  lines: JournalLine[];
  status: "posted" | "draft";
  by: string;
}

export type InvoiceType = "sale" | "purchase" | "saleReturn" | "purchaseReturn" | "quote";
export type InvoiceStatus = "paid" | "partial" | "late" | "open" | "draft";

export interface Invoice {
  id: string;
  no: string;
  type: InvoiceType;
  party: string;
  date: string;
  due: string;
  subtotal: number;
  vat: number;
  total: number;
  paid: number;
  status: InvoiceStatus;
}

export interface Partner {
  id: string;
  name: string;
  kind: "customer" | "supplier";
  contact: string;
  phone: string;
  city: string;
  balance: number; // للعميل: له(سالب)/عليه(موجب) — نبقيه "مستحق لنا"
  limit: number;
  since: string;
  transactions: { id: string; date: string; desc: string; debit: number; credit: number }[];
}

export interface Debt {
  id: string;
  party: string;
  kind: "for" | "on"; // for = لنا (على الغير)، on = علينا (للغير)
  amount: number;
  paid: number;
  due: string;
  origin: string;
  phone?: string;
  notes?: string;
}

export interface CashboxAccount {
  id: string;
  no: string | number; // رقم الصندوق
  name: string; // اسم الصندوق
  balance: number; // رصيد الصندوق
  currency?: string;
}

export type TrashItemType = "cashbox" | "bank" | "cashMove" | "bankMove";

export interface TrashItem {
  id: string;                      // معرف فريد لعنصر السلة
  originalId: string;              // المعرف الأصلي في قاعدة البيانات
  type: TrashItemType;             // نوع العنصر
  label: string;                   // اسم قابل للعرض
  detail?: string;                 // تفاصيل إضافية
  deletedAt: number;               // Unix timestamp بالمللي ثانية
  expiresAt: number;               // deletedAt + 30 يوماً
  data: CashboxAccount | BankAccount | CashMove | BankMove;
}

export const TRASH_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 يوم

export interface BankAccount {
  id: string;
  bank: string;
  iban: string;
  balance: number;
  currency: string;
  no?: string | number;
  name?: string;
}

export interface CashMove {
  id: string;
  date: string;
  desc: string;
  in: number;
  out: number;
  cashboxId?: string;
  cashboxName?: string;
  transferToId?: string;
  transferToName?: string;
  type?: "deposit" | "withdraw" | "transfer-box" | "transfer-bank";
  balanceAfter?: number;
}

export interface BankMove {
  id: string;
  date: string;
  desc: string;
  in: number;
  out: number;
  bankId?: string;
  bankName?: string;
  transferToId?: string;
  transferToName?: string;
  type?: "deposit" | "withdraw" | "transfer-bank" | "transfer-box";
  balanceAfter?: number;
}

export interface NotificationItem {
  id: string;
  kind: "debt" | "invoice" | "bank" | "system";
  title: string;
  body: string;
  time: string;
  read: boolean;
}

export interface TeamUser {
  id: string;
  name: string;
  role: "admin" | "accountant" | "staff";
  active: boolean;
  last: string;
}

/* ============ الحسابات التشغيلية المعتمدة للقيود والتقارير ============ */
export const JOURNAL_ACCOUNTS = [
  { id: "acc_cash", code: "101", name: "الصندوق النقدي" },
  { id: "acc_bank", code: "102", name: "الحسابات البنكية" },
  { id: "acc_cust", code: "103", name: "ذمم العملاء والوكلاء" },
  { id: "acc_rev", code: "401", name: "إيرادات عمولات الحوالات" },
  { id: "acc_exp", code: "501", name: "تكاليف ومصاريف التشغيل" },
  { id: "acc_tax", code: "201", name: "رسوم وضرائب مستحقة" },
  { id: "acc_cap", code: "301", name: "رأس المال" },
];

export const accountName = (id: string) => JOURNAL_ACCOUNTS.find((a) => a.id === id)?.name ?? "حساب عام";

/* ============ القيود اليومية ============ */
const ENTRIES_SEED: JournalEntry[] = [
  {
    id: "j1", no: 1024, date: "2026-02-18", ref: "INV-2088", desc: "فاتورة مبيعات آجلة — شركة الأفق للتقنية",
    status: "posted", by: "محمد العتيبي",
    lines: [
      { accountId: "a12", debit: 46000, credit: 0 },
      { accountId: "a41", debit: 0, credit: 40000 },
      { accountId: "a22", debit: 0, credit: 6000 },
    ],
  },
  {
    id: "j2", no: 1023, date: "2026-02-17", ref: "PAY-3321", desc: "تحصيل دفعة من مؤسسة البنيان بشيك",
    status: "posted", by: "سارة القحطاني",
    lines: [
      { accountId: "a112", debit: 25000, credit: 0 },
      { accountId: "a12", debit: 0, credit: 25000 },
    ],
  },
  {
    id: "j3", no: 1022, date: "2026-02-16", ref: "EXP-1187", desc: "إيداع نقدي من الصندوق إلى بنك الراجحي",
    status: "posted", by: "سارة القحطاني",
    lines: [
      { accountId: "a112", debit: 15000, credit: 0 },
      { accountId: "a111", debit: 0, credit: 15000 },
    ],
  },
  {
    id: "j4", no: 1021, date: "2026-02-15", ref: "SAL-02", desc: "مسير رواتب شهر فبراير — النصف الأول",
    status: "posted", by: "محمد العتيبي",
    lines: [
      { accountId: "a52", debit: 63000, credit: 0 },
      { accountId: "a23", debit: 0, credit: 63000 },
    ],
  },
  {
    id: "j5", no: 1020, date: "2026-02-14", ref: "PUR-0955", desc: "فاتورة مشتريات نقدية — مصنع الشرق للبلاستيك",
    status: "posted", by: "خالد الشمري",
    lines: [
      { accountId: "a13", debit: 32200, credit: 0 },
      { accountId: "a111", debit: 0, credit: 32200 },
    ],
  },
  {
    id: "j6", no: 1019, date: "2026-02-13", ref: "MKT-221", desc: "حملة إعلانية — منصة سناب شات",
    status: "draft", by: "خالد الشمري",
    lines: [
      { accountId: "a54", debit: 8400, credit: 0 },
      { accountId: "a22", debit: 1260, credit: 0 },
      { accountId: "a113", debit: 0, credit: 9660 },
    ],
  },
  {
    id: "j7", no: 1018, date: "2026-02-11", ref: "INV-2087", desc: "فاتورة مبيعات نقدية — متجر لمسة",
    status: "posted", by: "محمد العتيبي",
    lines: [
      { accountId: "a111", debit: 21850, credit: 0 },
      { accountId: "a41", debit: 0, credit: 19000 },
      { accountId: "a22", debit: 0, credit: 2850 },
    ],
  },
];

/* ============ الفواتير ============ */
const INVOICES_SEED: Invoice[] = [
  { id: "i1", no: "INV-2088", type: "sale", party: "شركة الأفق للتقنية", date: "2026-02-18", due: "2026-03-18", subtotal: 40000, vat: 6000, total: 46000, paid: 0, status: "open" },
  { id: "i2", no: "INV-2087", type: "sale", party: "متجر لمسة", date: "2026-02-11", due: "2026-02-11", subtotal: 19000, vat: 2850, total: 21850, paid: 21850, status: "paid" },
  { id: "i3", no: "INV-2086", type: "sale", party: "شركة الروابي التجارية", date: "2026-01-28", due: "2026-02-12", subtotal: 61500, vat: 9225, total: 70725, paid: 30000, status: "late" },
  { id: "i4", no: "INV-2085", type: "sale", party: "مؤسسة البنيان", date: "2026-01-22", due: "2026-02-21", subtotal: 25000, vat: 3750, total: 28750, paid: 28750, status: "paid" },
  { id: "i5", no: "INV-2084", type: "sale", party: "مؤسسة الوفاء للتجارة", date: "2026-01-15", due: "2026-02-14", subtotal: 33400, vat: 5010, total: 38410, paid: 15000, status: "late" },
  { id: "i6", no: "PUR-0955", type: "purchase", party: "مصنع الشرق للبلاستيك", date: "2026-02-14", due: "2026-02-14", subtotal: 28000, vat: 4200, total: 32200, paid: 32200, status: "paid" },
  { id: "i7", no: "PUR-0954", type: "purchase", party: "شركة الإمداد الأول", date: "2026-02-02", due: "2026-03-02", subtotal: 54800, vat: 8220, total: 63020, paid: 20000, status: "open" },
  { id: "i8", no: "PUR-0953", type: "purchase", party: "مؤسسة التوريدات الحديثة", date: "2026-01-20", due: "2026-02-19", subtotal: 41600, vat: 6240, total: 47840, paid: 0, status: "open" },
  { id: "i9", no: "RET-0312", type: "saleReturn", party: "شركة الروابي التجارية", date: "2026-02-08", due: "2026-02-08", subtotal: 4200, vat: 630, total: 4830, paid: 4830, status: "paid" },
  { id: "i10", no: "RET-0311", type: "purchaseReturn", party: "شركة الإمداد الأول", date: "2026-02-05", due: "2026-02-05", subtotal: 2600, vat: 390, total: 2990, paid: 2990, status: "paid" },
  { id: "i11", no: "QT-0788", type: "quote", party: "شركة نخبة الأعمال", date: "2026-02-16", due: "2026-03-16", subtotal: 88000, vat: 13200, total: 101200, paid: 0, status: "draft" },
  { id: "i12", no: "QT-0787", type: "quote", party: "مجموعة الرؤية القابضة", date: "2026-02-10", due: "2026-03-10", subtotal: 46500, vat: 6975, total: 53475, paid: 0, status: "draft" },
];

export const INVOICE_TYPE_LABEL: Record<InvoiceType, string> = {
  sale: "مبيعات",
  purchase: "مشتريات",
  saleReturn: "مرتجع مبيعات",
  purchaseReturn: "مرتجع مشتريات",
  quote: "عرض سعر",
};

export const INVOICE_STATUS_LABEL: Record<InvoiceStatus, string> = {
  paid: "مدفوعة",
  partial: "جزئية",
  late: "متأخرة",
  open: "آجلة",
  draft: "مسودة",
};

export const INVOICE_STATUS_CHIP: Record<InvoiceStatus, string> = {
  paid: "chip-green",
  partial: "chip-gold",
  late: "chip-red",
  open: "chip-sky",
  draft: "chip-gray",
};

/* ============ العملاء والموردون ============ */
const PARTNERS_SEED: Partner[] = [
  {
    id: "c1", name: "شركة الأفق للتقنية", kind: "customer", contact: "عبدالله الحربي", phone: "0551234567",
    city: "الرياض", balance: 46000, limit: 150000, since: "2022-03-14",
    transactions: [
      { id: "t1", date: "2026-02-18", desc: "فاتورة INV-2088", debit: 46000, credit: 0 },
      { id: "t2", date: "2026-01-05", desc: "فاتورة INV-2079", debit: 38000, credit: 0 },
      { id: "t3", date: "2026-01-19", desc: "سند قبض RC-1108", debit: 0, credit: 38000 },
    ],
  },
  {
    id: "c2", name: "مؤسسة البنيان", kind: "customer", contact: "فيصل الدوسري", phone: "0567891234",
    city: "جدة", balance: 0, limit: 80000, since: "2021-09-02",
    transactions: [
      { id: "t4", date: "2026-01-22", desc: "فاتورة INV-2085", debit: 28750, credit: 0 },
      { id: "t5", date: "2026-02-17", desc: "شيك رقم 4471", debit: 0, credit: 28750 },
    ],
  },
  {
    id: "c3", name: "شركة الروابي التجارية", kind: "customer", contact: "ماجد السبيعي", phone: "0509876543",
    city: "الدمام", balance: 40725, limit: 120000, since: "2020-11-20",
    transactions: [
      { id: "t6", date: "2026-01-28", desc: "فاتورة INV-2086", debit: 70725, credit: 0 },
      { id: "t7", date: "2026-02-04", desc: "تحويل بنكي", debit: 0, credit: 30000 },
    ],
  },
  {
    id: "c4", name: "متجر لمسة", kind: "customer", contact: "نورة العنزي", phone: "0542223344",
    city: "الرياض", balance: 0, limit: 40000, since: "2023-06-11",
    transactions: [{ id: "t8", date: "2026-02-11", desc: "فاتورة INV-2087 نقدية", debit: 21850, credit: 21850 }],
  },
  {
    id: "c5", name: "مؤسسة الوفاء للتجارة", kind: "customer", contact: "تركي المطيري", phone: "0533334455",
    city: "بريدة", balance: 23410, limit: 60000, since: "2022-12-01",
    transactions: [
      { id: "t9", date: "2026-01-15", desc: "فاتورة INV-2084", debit: 38410, credit: 0 },
      { id: "t10", date: "2026-02-01", desc: "دفعة نقدية", debit: 0, credit: 15000 },
    ],
  },
  {
    id: "s1", name: "شركة الإمداد الأول", kind: "supplier", contact: "سامي الغامدي", phone: "0577665544",
    city: "الرياض", balance: 43020, limit: 200000, since: "2019-04-18",
    transactions: [
      { id: "t11", date: "2026-02-02", desc: "فاتورة PUR-0954", debit: 0, credit: 63020 },
      { id: "t12", date: "2026-02-09", desc: "دفعة تحويل", debit: 20000, credit: 0 },
    ],
  },
  {
    id: "s2", name: "مصنع الشرق للبلاستيك", kind: "supplier", contact: "رمزي حداد", phone: "0588112233",
    city: "جدة", balance: 0, limit: 120000, since: "2020-08-25",
    transactions: [{ id: "t13", date: "2026-02-14", desc: "فاتورة PUR-0955 نقدية", debit: 32200, credit: 32200 }],
  },
  {
    id: "s3", name: "مؤسسة التوريدات الحديثة", kind: "supplier", contact: "وليد باشا", phone: "0599443322",
    city: "المدينة", balance: 47840, limit: 100000, since: "2021-02-09",
    transactions: [{ id: "t14", date: "2026-01-20", desc: "فاتورة PUR-0953 آجلة", debit: 0, credit: 47840 }],
  },
];

/* ============ الديون ============ */
const DEBTS_SEED: Debt[] = [
  { id: "d1", party: "شركة الروابي التجارية", kind: "for", amount: 40725, paid: 30000, due: "2026-02-12", origin: "INV-2086" },
  { id: "d2", party: "مؤسسة الوفاء للتجارة", kind: "for", amount: 23410, paid: 15000, due: "2026-02-14", origin: "INV-2084" },
  { id: "d3", party: "شركة الأفق للتقنية", kind: "for", amount: 46000, paid: 0, due: "2026-03-18", origin: "INV-2088" },
  { id: "d4", party: "شركة الإمداد الأول", kind: "on", amount: 43020, paid: 20000, due: "2026-03-02", origin: "PUR-0954" },
  { id: "d5", party: "مؤسسة التوريدات الحديثة", kind: "on", amount: 47840, paid: 0, due: "2026-02-19", origin: "PUR-0953" },
  { id: "d6", party: "هيئة الزكاة والضريبة", kind: "on", amount: 31240, paid: 0, due: "2026-03-31", origin: "إقرار الربع الأول" },
];

/* ============ البنوك والصندوق ============ */
const BANKS_SEED: BankAccount[] = [
  { id: "b1", bank: "مصرف الراجحي", iban: "SA03 8000 0000 6080 1016 7519", balance: 386400, currency: "ر.س" },
  { id: "b2", bank: "البنك الأهلي", iban: "SA44 1000 0024 5609 8700 0104", balance: 214800, currency: "ر.س" },
  { id: "b3", bank: "بنك الرياض — دولار", iban: "SA77 2000 0003 1210 4410 0901", balance: 18250, currency: "$" },
];

const CASH_MOVES_SEED: CashMove[] = [
  { id: "m1", date: "2026-02-18", desc: "مبيعات نقدية — لمسة", in: 21850, out: 0 },
  { id: "m2", date: "2026-02-17", desc: "إيداع إلى بنك الراجحي", in: 0, out: 15000 },
  { id: "m3", date: "2026-02-16", desc: "دفعة من مؤسسة الوفاء", in: 15000, out: 0 },
  { id: "m4", date: "2026-02-15", desc: "مصاريف ضيافة ونقل", in: 0, out: 1240 },
  { id: "m5", date: "2026-02-14", desc: "مشتريات نقدية — مصنع الشرق", in: 0, out: 32200 },
];

/* ============ سلاسل الرسوم البيانية ============ */
const DAILY_FLOW_SEED = [
  { label: "الأحد", in: 21850, out: 8400 },
  { label: "الاثنين", in: 15000, out: 32200 },
  { label: "الثلاثاء", in: 9600, out: 6100 },
  { label: "الأربعاء", in: 30250, out: 12800 },
  { label: "الخميس", in: 46700, out: 18500 },
  { label: "الجمعة", in: 8200, out: 4300 },
  { label: "السبت", in: 27900, out: 9900 },
];

const MONTHLY_FLOW_SEED = [
  { label: "يناير", in: 182000, out: 141000 },
  { label: "فبراير", in: 204500, out: 158000 },
  { label: "مارس", in: 168300, out: 149500 },
  { label: "أبريل", in: 221000, out: 163800 },
  { label: "مايو", in: 195400, out: 151200 },
  { label: "يونيو", in: 238900, out: 171600 },
  { label: "يوليو", in: 214700, out: 166300 },
  { label: "أغسطس", in: 189600, out: 148900 },
  { label: "سبتمبر", in: 243800, out: 175400 },
  { label: "أكتوبر", in: 258100, out: 182700 },
  { label: "نوفمبر", in: 231500, out: 169800 },
  { label: "ديسمبر", in: 276400, out: 197300 },
];

const YEARLY_FLOW_SEED = [
  { label: "2021", in: 1480000, out: 1210000 },
  { label: "2022", in: 1890000, out: 1520000 },
  { label: "2023", in: 2140000, out: 1685000 },
  { label: "2024", in: 2465000, out: 1908000 },
  { label: "2025", in: 2814000, out: 2141000 },
];

const EXPENSE_BREAKDOWN_SEED = [
  { label: "المشتريات", value: 318600, color: "#c5a069" },
  { label: "الرواتب", value: 126000, color: "#5b8bb5" },
  { label: "الإيجار", value: 48000, color: "#2f9e77" },
  { label: "التسويق", value: 27400, color: "#b0679b" },
  { label: "تشغيلية", value: 18950, color: "#8a8f98" },
];

/* ============ مؤشرات اللوحة ============ */
const KPI_SEED = {
  totalBalance: 649450,
  profits: 154290,
  expenses: 538950,
  debtsFor: 110135,
  debtsOn: 122100,
  customers: 38,
  suppliers: 17,
  invoices: 214,
  journalEntries: 1024,
  cashflow: 46450,
};

/* ============ الإشعارات ============ */
const NOTIFICATIONS_SEED: NotificationItem[] = [
  { id: "n1", kind: "debt", title: "دفعة متأخرة", body: "فاتورة INV-2086 على شركة الروابي متأخرة 6 أيام", time: "قبل ساعتين", read: false },
  { id: "n2", kind: "invoice", title: "فاتورة مستحقة قريباً", body: "فاتورة PUR-0953 لمؤسسة التوريدات الحديثة تستحق بعد يوم واحد", time: "قبل 5 ساعات", read: false },
  { id: "n3", kind: "bank", title: "تحويل بنكي", body: "تم استلام تحويل بقيمة 30,000 ر.س في مصرف الراجحي", time: "أمس", read: false },
  { id: "n4", kind: "debt", title: "مستحقات ضريبية", body: "إقرار ضريبة القيمة المضافة يستحق في 31 مارس", time: "قبل يومين", read: true },
  { id: "n5", kind: "system", title: "نسخة احتياطية", body: "تم إنشاء نسخة احتياطية تلقائية بنجاح", time: "قبل 3 أيام", read: true },
];

/* ============ فريق العمل ============ */
export const TEAM: TeamUser[] = [
  { id: "u1", name: "خليل محمد", role: "admin", active: true, last: "الآن" },
];

export const ROLE_LABEL: Record<TeamUser["role"], string> = {
  admin: "مدير النظام",
  accountant: "محاسب",
  staff: "موظف مبيعات",
};

/* ============ الأرصدة الافتتاحية ============ */
const OPENING_ROWS_SEED = [
  { accountId: "a111", label: "الصندوق النقدي", debit: 61700, credit: 0 },
  { accountId: "a112", label: "بنك الراجحي", debit: 298000, credit: 0 },
  { accountId: "a113", label: "البنك الأهلي", debit: 174500, credit: 0 },
  { accountId: "a13", label: "المخزون", debit: 96300, credit: 0 },
  { accountId: "a31", label: "رأس المال", debit: 0, credit: 500000 },
  { accountId: "a32", label: "أرباح مرحلة", debit: 0, credit: 130500 },
];

/* ============ حالة نظام مصفّرة ============ */
export const ENTRIES: JournalEntry[] = [];
export const INVOICES: Invoice[] = [];
export const PARTNERS: Partner[] = [];
export const DEBTS: Debt[] = [];
export const BANKS: BankAccount[] = [];
export const CASH_MOVES: CashMove[] = [];
export const CASHBOXES: CashboxAccount[] = [];
export const BANK_MOVES: BankMove[] = [];

// تبقى محاور الرسوم ظاهرة لكن جميع قيمها تبدأ من الصفر.
export const DAILY_FLOW = DAILY_FLOW_SEED.map((point) => ({ ...point, in: 0, out: 0 }));
export const MONTHLY_FLOW = MONTHLY_FLOW_SEED.map((point) => ({ ...point, in: 0, out: 0 }));
export const YEARLY_FLOW = YEARLY_FLOW_SEED.map((point) => ({ ...point, in: 0, out: 0 }));
export const EXPENSE_BREAKDOWN = EXPENSE_BREAKDOWN_SEED.map((item) => ({ ...item, value: 0 }));

export const KPI = Object.fromEntries(
  Object.keys(KPI_SEED).map((key) => [key, 0])
) as typeof KPI_SEED;

export const NOTIFICATIONS: NotificationItem[] = [];
export const OPENING_ROWS = OPENING_ROWS_SEED.map((row) => ({ ...row, debit: 0, credit: 0 }));

// تمنع تحذيرات TypeScript مع الاحتفاظ ببيانات العرض القديمة خارج الحالة الفعلية.
void ENTRIES_SEED;
void INVOICES_SEED;
void PARTNERS_SEED;
void DEBTS_SEED;
void BANKS_SEED;
void CASH_MOVES_SEED;
void EXPENSE_BREAKDOWN_SEED;
void NOTIFICATIONS_SEED;
