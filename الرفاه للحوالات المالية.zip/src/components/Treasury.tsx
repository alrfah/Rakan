import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { moveToTrash } from "./TrashBin";
import {
  ArrowDownToLine, ArrowRightLeft, ArrowUpFromLine, BellRing, CheckCircle2,
  ChevronDown, Eye, Landmark, MessageCircle, Pencil, Plus, Search, Trash2, UserRound, Wallet,
} from "lucide-react";
import {
  BANKS, BANK_MOVES, CASHBOXES, CASH_MOVES, DEBTS, OPENING_ROWS,
  type BankAccount, type BankMove, type CashboxAccount, type CashMove, type Debt,
} from "../data/mock";
import { DATE, NUM, SAR, daysLeft, dueChip, todayISO } from "../utils/format";
import { Chip, ConfirmDialog, EmptyState, ExportBar, Glass, L, Modal, SectionHead, inputCls, useApp, handleNextOrGo } from "./ui";
import { useTenantState } from "../lib/tenant";

export type TreasuryTab = "cash" | "banks" | "debts" | "opening" | "exin";

const TIME = (iso: string) => {
  try {
    return new Date(iso).toLocaleTimeString("ar", { hour: "2-digit", minute: "2-digit" });
  } catch {
    return "";
  }
};

/* ============ مكون القائمة المنسدلة لحسابات التحويل (متناسق مع الهوية) ============ */
function AccountDropdown({
  label,
  value,
  onChange,
  cashboxes,
  banks,
  excludeId,
}: {
  label: string;
  value: string;
  onChange: (id: string) => void;
  cashboxes: CashboxAccount[];
  banks: BankAccount[];
  excludeId?: string;
}) {
  const [open, setOpen] = useState(false);
  const selectedBox = cashboxes.find((c) => c.id === value);
  const selectedBank = banks.find((b) => b.id === value);

  const availableBoxes = excludeId
    ? cashboxes.filter((c) => c.id !== excludeId)
    : cashboxes;
  const availableBanks = excludeId
    ? banks.filter((b) => b.id !== excludeId)
    : banks;

  return (
    <div className="relative">
      <span className="mb-1.5 block text-xs font-bold text-[var(--muted)]">
        {label}
      </span>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="field group flex w-full items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] px-3.5 py-3 text-start transition-all hover:border-[var(--border-gold)] hover:bg-[var(--surface-2)] focus:outline-none focus:ring-2 focus:ring-[var(--gold)] cursor-pointer"
      >
        <div className="flex min-w-0 items-center gap-3">
          {selectedBox ? (
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--gold-dim)] text-[var(--gold-bright)] ring-1 ring-[var(--border-gold)]">
              <Wallet size={17} />
            </span>
          ) : selectedBank ? (
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--surface-2)] text-[var(--sky)] ring-1 ring-[var(--border)]">
              <Landmark size={17} />
            </span>
          ) : (
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--surface-2)] text-[var(--muted)]">
              <ArrowRightLeft size={17} />
            </span>
          )}
          <div className="min-w-0">
            <p className="truncate text-xs font-black text-[var(--text)]">
              {selectedBox
                ? `صندوق #${selectedBox.no} - ${selectedBox.name}`
                : selectedBank
                  ? `${selectedBank.name || selectedBank.bank} - #${selectedBank.no || selectedBank.iban}`
                  : "— اختر الحساب —"}
            </p>
            <p className="num mt-0.5 text-[10px] font-bold text-[var(--muted)]">
              {selectedBox
                ? `الرصيد: ${SAR(selectedBox.balance)}`
                : selectedBank
                  ? `الرصيد: ${selectedBank.currency === "$" ? `$${NUM(selectedBank.balance)}` : SAR(selectedBank.balance)}`
                  : "اختر الحساب المطلوب"}
            </p>
          </div>
        </div>
        <ChevronDown
          size={16}
          className={`shrink-0 text-[var(--muted)] transition-transform duration-200 ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>

      <AnimatePresence>
        {open && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: 6, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 4, scale: 0.98 }}
              transition={{ duration: 0.18 }}
              className="absolute inset-x-0 top-full z-50 mt-1.5 max-h-72 overflow-y-auto rounded-2xl border border-[var(--border-gold)] bg-[var(--bg-2)]/98 p-2 shadow-[0_25px_60px_rgba(0,0,0,0.65)] backdrop-blur-2xl"
            >
              <div className="px-3 py-1.5 text-[10px] font-black tracking-wider text-[var(--gold)]">
                📦 الصناديق النقدية
              </div>
              {availableBoxes.length === 0 ? (
                <div className="px-3 py-2 text-center text-xs text-[var(--faint)]">
                  لا توجد صناديق مخصصة
                </div>
              ) : (
                <div className="space-y-1">
                  {availableBoxes.map((c) => {
                    const isSelected = c.id === value;
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => {
                          onChange(c.id);
                          setOpen(false);
                        }}
                        className={`flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-start transition-all ${
                          isSelected
                            ? "border border-[var(--gold)] bg-[var(--gold-dim)] shadow-md"
                            : "hover:bg-[var(--surface-2)] border border-transparent"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Wallet size={15} className="shrink-0 text-[var(--gold)]" />
                          <div className="min-w-0">
                            <p className="truncate text-xs font-black">
                              صندوق #{c.no} - {c.name}
                            </p>
                            <p className="num text-[10px] text-[var(--muted)]">
                              الرصيد: {SAR(c.balance)}
                            </p>
                          </div>
                        </div>
                        {isSelected && (
                          <CheckCircle2 size={15} className="shrink-0 text-[var(--gold-bright)]" />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}

              <div className="mt-2 border-t border-[var(--border)] px-3 pt-2 pb-1.5 text-[10px] font-black tracking-wider text-[var(--sky)]">
                🏦 الحسابات البنكية
              </div>
              {availableBanks.length === 0 ? (
                <div className="px-3 py-2 text-center text-xs text-[var(--faint)]">
                  لا توجد حسابات بنكية مخصصة
                </div>
              ) : (
                <div className="space-y-1">
                  {availableBanks.map((b) => {
                    const isSelected = b.id === value;
                    return (
                      <button
                        key={b.id}
                        type="button"
                        onClick={() => {
                          onChange(b.id);
                          setOpen(false);
                        }}
                        className={`flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-start transition-all ${
                          isSelected
                            ? "border border-[var(--gold)] bg-[var(--gold-dim)] shadow-md"
                            : "hover:bg-[var(--surface-2)] border border-transparent"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Landmark size={15} className="shrink-0 text-[var(--sky)]" />
                          <div className="min-w-0">
                            <p className="truncate text-xs font-black">
                              {b.name || b.bank} - #{b.no || b.iban}
                            </p>
                            <p className="num text-[10px] text-[var(--muted)]">
                              الرصيد: {b.currency === "$" ? `$${NUM(b.balance)}` : SAR(b.balance)}
                            </p>
                          </div>
                        </div>
                        {isSelected && (
                          <CheckCircle2 size={15} className="shrink-0 text-[var(--gold-bright)]" />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ============ مودال التحويل المشترك بين الصناديق والبنوك ============ */
function TransferModal({
  open,
  onClose,
  defaultFromId,
  cashboxes,
  banks,
  onExecute,
}: {
  open: boolean;
  onClose: () => void;
  defaultFromId?: string;
  cashboxes: CashboxAccount[];
  banks: BankAccount[];
  onExecute: (fromId: string, toId: string, amount: number, desc: string) => void;
}) {
  const [fromId, setFromId] = useState(defaultFromId || (cashboxes[0]?.id ?? banks[0]?.id ?? ""));
  const [toId, setToId] = useState(() => {
    const defaultFrom = defaultFromId || (cashboxes[0]?.id ?? banks[0]?.id ?? "");
    return (
      cashboxes.find((c) => c.id !== defaultFrom)?.id ??
      banks.find((b) => b.id !== defaultFrom)?.id ??
      ""
    );
  });
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");

  const handleFromChange = (newFromId: string) => {
    setFromId(newFromId);
    if (toId === newFromId) {
      const nextTo =
        cashboxes.find((c) => c.id !== newFromId)?.id ??
        banks.find((b) => b.id !== newFromId)?.id ??
        "";
      setToId(nextTo);
    }
  };

  const submit = () => {
    const a = Number(amount);
    if (!fromId || !toId) return;
    onExecute(fromId, toId, a, desc.trim());
    setAmount("");
    setDesc("");
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="تحويل مالي بين الصناديق والحسابات البنكية"
      onSubmit={submit}
    >
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <AccountDropdown
            label="من (الطرف المرسل)"
            value={fromId}
            onChange={handleFromChange}
            cashboxes={cashboxes}
            banks={banks}
          />
          <AccountDropdown
            label="إلى (الطرف المستقبل)"
            value={toId}
            onChange={setToId}
            cashboxes={cashboxes}
            banks={banks}
            excludeId={fromId}
          />
        </div>
        <L label="المبلغ (ل.س)">
          <input
            type="number"
            min={0}
            className={`${inputCls} num`}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0"
            enterKeyHint="next"
            autoFocus
          />
        </L>
        <L label="البيان / ملاحظة التحويل">
          <input
            className={inputCls}
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            placeholder="مثال: تعزيز رصيد الصندوق من حساب البنك"
            enterKeyHint="go"
          />
        </L>
      </div>
      <div className="mt-6 flex justify-end gap-2">
        <button type="button" onClick={onClose} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">
          إلغاء
        </button>
        <button
          type="button"
          onClick={submit}
          disabled={!fromId || !toId || fromId === toId || !Number(amount)}
          className="btn-gold flex items-center gap-1.5 rounded-xl px-6 py-2.5 text-xs font-black disabled:opacity-50"
        >
          <ArrowRightLeft size={14} /> تنفيذ التحويل
        </button>
      </div>
    </Modal>
  );
}

/* ================= الصناديق النقدية ================= */
function Cashbox() {
  const { notify, tenantUid } = useApp();
  const [cashboxes, setCashboxes] = useTenantState<CashboxAccount[]>(tenantUid, "treasury/cashboxes", CASHBOXES);
  const [moves, setMoves] = useTenantState<CashMove[]>(tenantUid, "treasury/cashMoves", CASH_MOVES);
  const [banks, setBanks] = useTenantState<BankAccount[]>(tenantUid, "treasury/banks", BANKS);
  const [, setBankMoves] = useTenantState<BankMove[]>(tenantUid, "treasury/bankMoves", BANK_MOVES);
  const [, setTrash] = useTenantState<unknown[]>(tenantUid, "treasury/trash", []);

  const [createModal, setCreateModal] = useState(false);
  const [boxForm, setBoxForm] = useState({ no: "", name: "", balance: "0" });
  const [transferOpen, setTransferOpen] = useState(false);
  const [defaultFromId, setDefaultFromId] = useState<string | undefined>(undefined);
  const [moveModal, setMoveModal] = useState<{ type: "deposit" | "withdraw"; cashboxId: string } | null>(null);
  const [moveForm, setMoveForm] = useState({ amount: "", desc: "" });
  const [deleteBox, setDeleteBox] = useState<CashboxAccount | null>(null);
  const [q, setQ] = useState("");
  // الحركات: عرض التفاصيل / تعديل / حذف
  const [viewingMove, setViewingMove] = useState<CashMove | null>(null);
  const [editingMove, setEditingMove] = useState<CashMove | null>(null);
  const [editMoveForm, setEditMoveForm] = useState({ desc: "", amount: "" });
  const [deletingMove, setDeletingMove] = useState<CashMove | null>(null);

  const totalCash = cashboxes.reduce((s, c) => s + (c.balance || 0), 0);
  const todayIn = moves.filter((m) => m.date.slice(0, 10) === todayISO()).reduce((s, m) => s + m.in, 0);
  const todayOut = moves.filter((m) => m.date.slice(0, 10) === todayISO()).reduce((s, m) => s + m.out, 0);

  const shownMoves = useMemo(
    () =>
      moves.filter(
        (m) =>
          !q ||
          m.desc.includes(q) ||
          (m.cashboxName && m.cashboxName.includes(q))
      ),
    [moves, q]
  );

  const createCashbox = () => {
    if (!boxForm.no.trim() || !boxForm.name.trim()) {
      notify("أدخل رقم الصندوق واسمه", "warn");
      return;
    }
    if (cashboxes.some((c) => String(c.no).trim() === boxForm.no.trim())) {
      notify("رقم الصندوق مستخدم مسبقاً", "warn");
      return;
    }
    const initBalance = Number(boxForm.balance) || 0;
    const newBox: CashboxAccount = {
      id: `cb_${Date.now()}`,
      no: boxForm.no.trim(),
      name: boxForm.name.trim(),
      balance: initBalance,
      currency: "ل.س",
    };
    setCashboxes((list) => [...list, newBox]);
    if (initBalance > 0) {
      setMoves((ms) => [
        {
          id: `m_${Date.now()}_init`,
          date: new Date().toISOString(),
          cashboxId: newBox.id,
          cashboxName: `صندوق #${newBox.no} - ${newBox.name}`,
          desc: `رصيد افتتاحي للصندوق #${newBox.no} - ${newBox.name}`,
          in: initBalance,
          out: 0,
          balanceAfter: initBalance,
          type: "deposit",
        },
        ...ms,
      ]);
    }
    notify(`تم إنشاء الصندوق رقم #${newBox.no} - «${newBox.name}» بنجاح ✓`);
    setCreateModal(false);
    setBoxForm({ no: "", name: "", balance: "0" });
  };

  const executeTransfer = (fromId: string, toId: string, amountVal: number, descText: string) => {
    const fromBox = cashboxes.find((c) => c.id === fromId);
    const fromBank = banks.find((b) => b.id === fromId);
    const toBox = cashboxes.find((c) => c.id === toId);
    const toBank = banks.find((b) => b.id === toId);

    if ((!fromBox && !fromBank) || (!toBox && !toBank)) {
      notify("تعذر تحديد الحساب المرسل أو المستقبل", "warn");
      return;
    }
    if (!amountVal || amountVal <= 0) {
      notify("أدخل مبلغاً صحيحاً أكبر من صفر", "warn");
      return;
    }

    const senderName = fromBox
      ? `صندوق #${fromBox.no} - ${fromBox.name}`
      : `${fromBank?.name || fromBank?.bank} (#${fromBank?.no || fromBank?.iban})`;
    const receiverName = toBox
      ? `صندوق #${toBox.no} - ${toBox.name}`
      : `${toBank?.name || toBank?.bank} (#${toBank?.no || toBank?.iban})`;
    const nowIso = new Date().toISOString();

    if (fromBox) {
      const updatedBalance = (fromBox.balance || 0) - amountVal;
      setCashboxes((list) => list.map((c) => (c.id === fromBox.id ? { ...c, balance: updatedBalance } : c)));
      setMoves((ms) => [
        {
          id: `m_${Date.now()}_out`,
          date: nowIso,
          cashboxId: fromBox.id,
          cashboxName: senderName,
          desc: `تحويل صادر إلى: ${receiverName}` + (descText ? ` — ${descText}` : ""),
          in: 0,
          out: amountVal,
          balanceAfter: updatedBalance,
          type: "transfer-bank",
        },
        ...ms,
      ]);
    } else if (fromBank) {
      const updatedBalance = (fromBank.balance || 0) - amountVal;
      setBanks((list) => list.map((b) => (b.id === fromBank.id ? { ...b, balance: updatedBalance } : b)));
      setBankMoves((ms) => [
        {
          id: `bm_${Date.now()}_out`,
          date: nowIso,
          bankId: fromBank.id,
          bankName: senderName,
          desc: `تحويل صادر إلى: ${receiverName}` + (descText ? ` — ${descText}` : ""),
          in: 0,
          out: amountVal,
          balanceAfter: updatedBalance,
          type: "transfer-bank",
        },
        ...ms,
      ]);
    }

    if (toBox) {
      const updatedBalance = (toBox.balance || 0) + amountVal;
      setCashboxes((list) => list.map((c) => (c.id === toBox.id ? { ...c, balance: updatedBalance } : c)));
      setMoves((ms) => [
        {
          id: `m_${Date.now()}_in`,
          date: nowIso,
          cashboxId: toBox.id,
          cashboxName: receiverName,
          desc: `تحويل وارد من: ${senderName}` + (descText ? ` — ${descText}` : ""),
          in: amountVal,
          out: 0,
          balanceAfter: updatedBalance,
          type: "transfer-box",
        },
        ...ms,
      ]);
    } else if (toBank) {
      const updatedBalance = (toBank.balance || 0) + amountVal;
      setBanks((list) => list.map((b) => (b.id === toBank.id ? { ...b, balance: updatedBalance } : b)));
      setBankMoves((ms) => [
        {
          id: `bm_${Date.now()}_in`,
          date: nowIso,
          bankId: toBank.id,
          bankName: receiverName,
          desc: `تحويل وارد من: ${senderName}` + (descText ? ` — ${descText}` : ""),
          in: amountVal,
          out: 0,
          balanceAfter: updatedBalance,
          type: "transfer-bank",
        },
        ...ms,
      ]);
    }

    notify(`تم تحويل ${SAR(amountVal)} من «${senderName}» إلى «${receiverName}» وتقييد الحركات بنجاح ✓`);
  };

  const executeQuickMove = () => {
    if (!moveModal) return;
    const a = Number(moveForm.amount);
    if (!a || a <= 0 || !moveForm.desc.trim()) {
      notify("أدخل المبلغ والبيان", "warn");
      return;
    }
    const box = cashboxes.find((c) => c.id === moveModal.cashboxId);
    if (!box) return;
    const isIn = moveModal.type === "deposit";
    const updatedBalance = (box.balance || 0) + (isIn ? a : -a);
    setCashboxes((list) => list.map((c) => (c.id === box.id ? { ...c, balance: updatedBalance } : c)));
    setMoves((ms) => [
      {
        id: `m_${Date.now()}`,
        date: new Date().toISOString(),
        cashboxId: box.id,
        cashboxName: `صندوق #${box.no} - ${box.name}`,
        desc: moveForm.desc.trim(),
        in: isIn ? a : 0,
        out: isIn ? 0 : a,
        balanceAfter: updatedBalance,
        type: isIn ? "deposit" : "withdraw",
      },
      ...ms,
    ]);
    notify(isIn ? `تم إيداع ${SAR(a)} في الصندوق #${box.no} ✓` : `تم صرف ${SAR(a)} من الصندوق #${box.no} ✓`);
    setMoveModal(null);
    setMoveForm({ amount: "", desc: "" });
  };

  const openEditMove = (m: CashMove) => {
    setEditingMove(m);
    setEditMoveForm({ desc: m.desc, amount: String(m.in > 0 ? m.in : m.out) });
  };

  const saveEditMove = () => {
    if (!editingMove) return;
    const a = Number(editMoveForm.amount);
    if (!editMoveForm.desc.trim() || !a) { notify("أدخل البيان والمبلغ", "warn"); return; }
    const isIn = editingMove.in > 0;
    setMoves((ms) => ms.map((m) =>
      m.id === editingMove.id
        ? { ...m, desc: editMoveForm.desc.trim(), in: isIn ? a : 0, out: isIn ? 0 : a }
        : m
    ));
    notify("تم تعديل الحركة بنجاح");
    setEditingMove(null);
  };

  const confirmDeleteMove = () => {
    if (!deletingMove) return;
    moveToTrash(
      setTrash as Parameters<typeof moveToTrash>[0],
      "cashMove",
      deletingMove.desc || "حركة صندوق",
      `${deletingMove.in > 0 ? `وارد: ${SAR(deletingMove.in)}` : `صادر: ${SAR(deletingMove.out)}`} — ${DATE(deletingMove.date)}`,
      deletingMove,
      deletingMove.id
    );
    setMoves((ms) => ms.filter((m) => m.id !== deletingMove.id));
    notify("تم نقل الحركة إلى سلة المهملات", "info");
    setDeletingMove(null);
  };

  const confirmDeleteBox = () => {
    if (!deleteBox) return;
    moveToTrash(
      setTrash as Parameters<typeof moveToTrash>[0],
      "cashbox",
      `صندوق #${deleteBox.no} - ${deleteBox.name}`,
      `رصيد: ${SAR(deleteBox.balance)}`,
      deleteBox,
      deleteBox.id
    );
    setCashboxes((list) => list.filter((c) => c.id !== deleteBox.id));
    notify(`تم نقل الصندوق «${deleteBox.name}» إلى سلة المهملات — يمكن استعادته خلال 30 يوماً`, "info");
    setDeleteBox(null);
  };

  return (
    <div className="space-y-6">
      {/* شريط علوي ثابت: بطاقة إجمالي الرصيد + زرّا التحويل وإنشاء الصندوق جنباً إلى جنب */}
      <div className="flex flex-wrap items-stretch gap-3">
        <Glass gold className="relative flex min-w-0 flex-1 items-center gap-3 overflow-hidden rounded-[20px] px-4 py-3 sm:px-5">
          <div className="pointer-events-none absolute -left-10 -top-12 h-32 w-32 rounded-full bg-[var(--gold)] opacity-10 blur-2xl" />
          <span
            className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border"
            style={{
              color: "var(--gold-bright)",
              borderColor: "color-mix(in srgb, currentColor 35%, transparent)",
              background: "color-mix(in srgb, currentColor 12%, transparent)",
            }}
          >
            <Wallet className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-[10px] font-bold text-[var(--muted)] sm:text-xs">إجمالي أرصدة الصناديق</p>
            <p
              className="num truncate font-display text-lg font-black leading-tight text-[var(--gold-bright)] sm:text-2xl"
              title={SAR(totalCash)}
            >
              {SAR(totalCash)}
            </p>
            <p className="mt-0.5 hidden text-[9px] font-bold text-[var(--faint)] sm:block">
              عدد الصناديق: {NUM(cashboxes.length)}
            </p>
          </div>
          {/* وارد / صادر اليوم كرقائق مدمجة */}
          <div className="ms-auto hidden shrink-0 flex-col gap-1.5 lg:flex">
            <span className="chip chip-green num">
              <ArrowDownToLine size={11} /> وارد اليوم: {SAR(todayIn)}
            </span>
            <span className="chip chip-red num">
              <ArrowUpFromLine size={11} /> صادر اليوم: {SAR(todayOut)}
            </span>
          </div>
        </Glass>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setDefaultFromId(cashboxes[0]?.id);
              setTransferOpen(true);
            }}
            className="btn-ghost flex h-full items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-bold"
          >
            <ArrowRightLeft size={14} /> تحويل
          </button>
          <button
            onClick={() => setCreateModal(true)}
            className="btn-gold flex h-full items-center gap-1.5 rounded-xl px-5 py-2.5 text-xs font-black"
          >
            <Plus size={15} /> إنشاء صندوق
          </button>
        </div>
      </div>

      {/* وارد / صادر اليوم على الشاشات الصغيرة */}
      <div className="grid grid-cols-2 gap-3 lg:hidden">
        <Glass className="flex items-center gap-2 rounded-[16px] px-3 py-2.5">
          <ArrowDownToLine size={14} className="shrink-0 text-[var(--green)]" />
          <div className="min-w-0">
            <p className="text-[9px] font-bold text-[var(--muted)]">وارد اليوم</p>
            <p className="num truncate text-xs font-black text-[var(--green)]">{SAR(todayIn)}</p>
          </div>
        </Glass>
        <Glass className="flex items-center gap-2 rounded-[16px] px-3 py-2.5">
          <ArrowUpFromLine size={14} className="shrink-0 text-[var(--red)]" />
          <div className="min-w-0">
            <p className="text-[9px] font-bold text-[var(--muted)]">صادر اليوم</p>
            <p className="num truncate text-xs font-black text-[var(--red)]">{SAR(todayOut)}</p>
          </div>
        </Glass>
      </div>

      {/* هذه تعرض الارصدا الكاملة بقسم الصنديق ولكن لكل صندوق رصيد منفصل */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <p className="font-display text-sm font-black text-[var(--gold-bright)]">
            📦 الصناديق النقدية المتاحة (رصيد منفصل لكل صندوق)
          </p>
          <span className="text-xs font-bold text-[var(--muted)]">{NUM(cashboxes.length)} صندوقاً</span>
        </div>

        {cashboxes.length === 0 ? (
          <Glass>
            <EmptyState
              icon={<Wallet size={24} />}
              text="لا توجد صناديق نقدية بعد — اضغط على زر « + إنشاء صندوق » في الأعلى لإضافة أول صندوق"
            />
          </Glass>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {cashboxes.map((box, i) => (
              <Glass
                key={box.id}
                gold={i === 0}
                className="card-hover relative flex flex-col justify-between overflow-hidden p-5"
              >
                <div className="pointer-events-none absolute -left-8 -top-10 h-28 w-28 rounded-full bg-[var(--gold)] opacity-10 blur-2xl" />
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="chip chip-gold font-black">صندوق #{box.no}</span>
                    <button
                      onClick={() => setDeleteBox(box)}
                      className="flex h-7 w-7 items-center justify-center rounded-lg text-[var(--red)] transition-colors hover:bg-[var(--red-soft)]"
                      title="حذف الصندوق"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <h3 className="mt-3 font-display text-lg font-black">{box.name}</h3>
                  <p className="num mt-2 font-display text-2xl font-black text-[var(--gold-bright)]">
                    {SAR(box.balance)}
                  </p>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 border-t border-[var(--border)] pt-3">
                  <button
                    onClick={() => {
                      setMoveModal({ type: "deposit", cashboxId: box.id });
                      setMoveForm({ amount: "", desc: "" });
                    }}
                    className="btn-ghost rounded-xl py-2 text-[11px] font-extrabold text-[var(--green)]"
                  >
                    + إيداع
                  </button>
                  <button
                    onClick={() => {
                      setMoveModal({ type: "withdraw", cashboxId: box.id });
                      setMoveForm({ amount: "", desc: "" });
                    }}
                    className="btn-ghost rounded-xl py-2 text-[11px] font-extrabold text-[var(--red)]"
                  >
                    - صرف
                  </button>
                  <button
                    onClick={() => {
                      setDefaultFromId(box.id);
                      setTransferOpen(true);
                    }}
                    className="btn-ghost rounded-xl py-2 text-[11px] font-extrabold text-[var(--gold)]"
                  >
                    ⇄ تحويل
                  </button>
                </div>
              </Glass>
            ))}
          </div>
        )}
      </div>

      {/* سجل حركات وتحويلات الصناديق المفصل */}
      <Glass className="overflow-hidden rounded-[20px] shadow-[0_18px_46px_rgba(0,0,0,0.25)]">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-5 py-4">
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-display text-base font-extrabold">📑 سجل حركات وتحويلات الصناديق المفصل</p>
            <ExportBar
              name="سجل-الصناديق"
              rows={[
                ["التاريخ", "الصندوق", "البيان", "وارد", "صادر", "الرصيد بعد الحركة"],
                ...shownMoves.map((m) => [
                  DATE(m.date),
                  m.cashboxName || "صندوق عام",
                  m.desc,
                  m.in || 0,
                  m.out || 0,
                  m.balanceAfter ?? "",
                ]),
              ]}
            />
          </div>
          <div className="relative w-full max-w-[240px]">
            <Search
              size={14}
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--faint)]"
            />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="بحث بالبيان أو اسم الصندوق…"
              className="field w-full rounded-xl py-2 pr-9 ps-3 text-xs"
            />
          </div>
        </div>
        <div className="max-h-[50vh] overflow-auto">
          <table className="lux-table">
            <thead>
              <tr>
                <th>#</th>
                <th>التاريخ والوقت</th>
                <th>الصندوق</th>
                <th>البيان / تفاصيل الحركة</th>
                <th>وارد (+)</th>
                <th>صادر (-)</th>
                <th>الرصيد بعد الحركة</th>
                <th className="no-print">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {shownMoves.map((m, i) => (
                <tr key={m.id} className="group">
                  <td className="num font-black text-[var(--faint)]">{NUM(i + 1)}</td>
                  <td>
                    <p className="num text-xs font-bold">{DATE(m.date)}</p>
                    <p className="num text-[10px] text-[var(--faint)]">{TIME(m.date)}</p>
                  </td>
                  <td className="font-black text-[var(--gold-bright)]">{m.cashboxName || "صندوق عام"}</td>
                  <td className="max-w-[220px] truncate font-bold" title={m.desc}>{m.desc}</td>
                  <td className="num font-black text-[var(--green)]">{m.in > 0 ? SAR(m.in) : "—"}</td>
                  <td className="num font-black text-[var(--red)]">{m.out > 0 ? SAR(m.out) : "—"}</td>
                  <td className="num font-black text-[var(--text)]">
                    {m.balanceAfter != null ? SAR(m.balanceAfter) : "—"}
                  </td>
                  <td className="no-print">
                    <span className="flex items-center gap-1 opacity-70 transition-opacity group-hover:opacity-100">
                      <button
                        onClick={() => setViewingMove(m)}
                        title="عرض التفاصيل"
                        className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--sky)] hover:bg-[var(--sky-soft)]"
                      >
                        <Eye size={13} />
                      </button>
                      <button
                        onClick={() => openEditMove(m)}
                        title="تعديل الحركة"
                        className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--gold)] hover:bg-[var(--gold-dim)]"
                      >
                        <Pencil size={13} />
                      </button>
                      <button
                        onClick={() => setDeletingMove(m)}
                        title="نقل إلى السلة"
                        className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--red)] hover:bg-[var(--red-soft)]"
                      >
                        <Trash2 size={13} />
                      </button>
                    </span>
                  </td>
                </tr>
              ))}
              {shownMoves.length === 0 && (
                <tr>
                  <td colSpan={8}>
                    <EmptyState
                      icon={<Wallet size={24} />}
                      text={
                        q
                          ? "لا توجد حركات مطابقة للبحث"
                          : "لا توجد حركات مسجلة بعد — قم بإنشاء صندوق أو إجراء إيداع وتحويل"
                      }
                    />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--border)] bg-[var(--surface)] px-5 py-3.5">
          <p className="text-[11px] font-bold text-[var(--muted)]">
            عدد الحركات المسجلة: <span className="num font-black text-[var(--text)]">{NUM(shownMoves.length)}</span>
          </p>
          <div className="flex gap-4 text-xs font-black">
            <span className="text-[var(--green)]">إجمالي الوارد: {SAR(shownMoves.reduce((s, m) => s + m.in, 0))}</span>
            <span className="text-[var(--red)]">إجمالي الصادر: {SAR(shownMoves.reduce((s, m) => s + m.out, 0))}</span>
          </div>
        </div>
      </Glass>

      {/* ====== مودال عرض تفاصيل الحركة ====== */}
      <Modal open={!!viewingMove} onClose={() => setViewingMove(null)} title="تفاصيل الحركة النقدية">
        {viewingMove && (
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-3">
              {[
                { l: "الصندوق", v: viewingMove.cashboxName || "صندوق عام" },
                { l: "نوع الحركة", v: viewingMove.type === "deposit" ? "إيداع" : viewingMove.type === "withdraw" ? "صرف" : viewingMove.type === "transfer-bank" ? "تحويل صادر" : viewingMove.type === "transfer-box" ? "تحويل وارد" : "حركة" },
                { l: "التاريخ", v: DATE(viewingMove.date) },
                { l: "الوقت", v: TIME(viewingMove.date) },
              ].map(({ l, v }) => (
                <div key={l} className="rounded-xl border border-[var(--border)] px-3.5 py-3">
                  <p className="text-[10px] font-bold text-[var(--muted)]">{l}</p>
                  <p className="mt-0.5 font-black">{v}</p>
                </div>
              ))}
            </div>
            <div className="rounded-xl border border-[var(--border)] px-3.5 py-3">
              <p className="text-[10px] font-bold text-[var(--muted)]">البيان</p>
              <p className="mt-0.5 font-bold leading-5">{viewingMove.desc}</p>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-xl border border-[var(--border)] px-3.5 py-3">
                <p className="text-[10px] font-bold text-[var(--muted)]">وارد (+)</p>
                <p className="num mt-0.5 font-black text-[var(--green)]">{viewingMove.in > 0 ? SAR(viewingMove.in) : "—"}</p>
              </div>
              <div className="rounded-xl border border-[var(--border)] px-3.5 py-3">
                <p className="text-[10px] font-bold text-[var(--muted)]">صادر (-)</p>
                <p className="num mt-0.5 font-black text-[var(--red)]">{viewingMove.out > 0 ? SAR(viewingMove.out) : "—"}</p>
              </div>
              <div className="glass-gold rounded-xl px-3.5 py-3">
                <p className="text-[10px] font-bold text-[var(--muted)]">الرصيد بعد</p>
                <p className="num mt-0.5 font-black text-[var(--gold-bright)]">{viewingMove.balanceAfter != null ? SAR(viewingMove.balanceAfter) : "—"}</p>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => { setViewingMove(null); openEditMove(viewingMove); }} className="btn-ghost flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-bold">
                <Pencil size={13} /> تعديل
              </button>
              <button onClick={() => setViewingMove(null)} className="btn-gold rounded-xl px-5 py-2.5 text-xs font-black">
                إغلاق
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* ====== مودال تعديل الحركة ====== */}
      <Modal open={!!editingMove} onClose={() => setEditingMove(null)} title="تعديل الحركة النقدية" onSubmit={saveEditMove}>
        {editingMove && (
          <div className="space-y-4">
            <div className="rounded-xl border border-[var(--border-gold)] bg-[var(--gold-dim)] px-4 py-3 text-xs">
              <span className="font-bold text-[var(--muted)]">الحركة: </span>
              <span className="font-black">{editingMove.in > 0 ? `وارد — ${SAR(editingMove.in)}` : `صادر — ${SAR(editingMove.out)}`}</span>
              <span className="mx-2 text-[var(--faint)]">|</span>
              <span className="text-[var(--muted)]">{DATE(editingMove.date)}</span>
            </div>
            <L label="البيان">
              <input autoFocus className={inputCls} value={editMoveForm.desc} onChange={(e) => setEditMoveForm({ ...editMoveForm, desc: e.target.value })} enterKeyHint="next" />
            </L>
            <L label={`المبلغ (${editingMove.in > 0 ? "وارد" : "صادر"})`}>
              <input type="number" min={0} className={`${inputCls} num`} value={editMoveForm.amount} onChange={(e) => setEditMoveForm({ ...editMoveForm, amount: e.target.value })} enterKeyHint="go" />
            </L>
          </div>
        )}
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setEditingMove(null)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">إلغاء</button>
          <button onClick={saveEditMove} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">حفظ التعديل</button>
        </div>
      </Modal>

      {/* ====== تأكيد حذف الحركة ====== */}
      <ConfirmDialog
        open={!!deletingMove}
        onClose={() => setDeletingMove(null)}
        onConfirm={confirmDeleteMove}
        variant="danger"
        title="نقل الحركة إلى سلة المهملات"
        message={`هل تريد نقل حركة «${deletingMove?.desc ?? ""}» إلى السلة؟ يمكن استعادتها خلال 30 يوماً.`}
        confirmLabel="نقل إلى السلة"
      />

      {/* مودال إنشاء صندوق */}
      <Modal open={createModal} onClose={() => setCreateModal(false)} title="إنشاء صندوق نقدي جديد">
        <div className="grid grid-cols-2 gap-4">
          <L label="رقم الصندوق">
            <input
              autoFocus
              className={`${inputCls} num`}
              value={boxForm.no}
              onChange={(e) => setBoxForm({ ...boxForm, no: e.target.value })}
              placeholder="مثال: 1 أو 101"
            />
          </L>
          <L label="اسم الصندوق">
            <input
              className={inputCls}
              value={boxForm.name}
              onChange={(e) => setBoxForm({ ...boxForm, name: e.target.value })}
              placeholder="مثال: الصندوق الرئيسي أو الفرع"
            />
          </L>
          <L label="الرصيد الافتتاحي (ل.س)" className="col-span-2">
            <input
              type="number"
              min={0}
              className={`${inputCls} num`}
              value={boxForm.balance}
              onChange={(e) => setBoxForm({ ...boxForm, balance: e.target.value })}
              placeholder="0"
            />
          </L>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setCreateModal(false)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">
            إلغاء
          </button>
          <button onClick={createCashbox} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">
            حفظ الصندوق في Firebase
          </button>
        </div>
      </Modal>

      {/* مودال إيداع / صرف سريع */}
      <Modal
        open={!!moveModal}
        onClose={() => setMoveModal(null)}
        title={moveModal?.type === "deposit" ? "إيداع نقدي في الصندوق" : "صرف نقدي من الصندوق"}
      >
        <div className="space-y-4">
          <L label="المبلغ (ل.س)">
            <input
              type="number"
              min={0}
              className={`${inputCls} num`}
              value={moveForm.amount}
              onChange={(e) => setMoveForm({ ...moveForm, amount: e.target.value })}
              placeholder="0"
              autoFocus
            />
          </L>
          <L label="البيان / ملاحظة الحركة">
            <input
              className={inputCls}
              value={moveForm.desc}
              onChange={(e) => setMoveForm({ ...moveForm, desc: e.target.value })}
              placeholder={moveModal?.type === "deposit" ? "مثال: إيداع عهدة نقدية" : "مثال: صرف مصاريف تشغيلية"}
            />
          </L>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setMoveModal(null)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">
            إلغاء
          </button>
          <button onClick={executeQuickMove} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">
            تأكيد الحركة النقدية
          </button>
        </div>
      </Modal>

      {/* نافذة التحويل المشتركة */}
      <TransferModal
        open={transferOpen}
        onClose={() => setTransferOpen(false)}
        defaultFromId={defaultFromId}
        cashboxes={cashboxes}
        banks={banks}
        onExecute={executeTransfer}
      />

      {/* تأكيد حذف الصندوق */}
      <ConfirmDialog
        open={!!deleteBox}
        onClose={() => setDeleteBox(null)}
        onConfirm={confirmDeleteBox}
        variant="danger"
        title="نقل الصندوق إلى سلة المهملات"
        message={`سيتم نقل صندوق #${deleteBox?.no} - «${deleteBox?.name}» إلى سلة المهملات. يمكن استعادته خلال 30 يوماً.`}
        detail={deleteBox && deleteBox.balance > 0 ? `⚠️ يحتوي الصندوق على رصيد ${SAR(deleteBox.balance)} — تأكد من التحويل قبل الحذف` : undefined}
        confirmLabel="نقل إلى السلة"
      />
    </div>
  );
}

/* ================= البنوك ================= */
function Banks() {
  const { notify, tenantUid } = useApp();
  const [banks, setBanks] = useTenantState<BankAccount[]>(tenantUid, "treasury/banks", BANKS);
  const [bankMoves, setBankMoves] = useTenantState<BankMove[]>(tenantUid, "treasury/bankMoves", BANK_MOVES);
  const [cashboxes, setCashboxes] = useTenantState<CashboxAccount[]>(tenantUid, "treasury/cashboxes", CASHBOXES);
  const [, setMoves] = useTenantState<CashMove[]>(tenantUid, "treasury/cashMoves", CASH_MOVES);
  const [, setTrash] = useTenantState<unknown[]>(tenantUid, "treasury/trash", []);

  const [createModal, setCreateModal] = useState(false);
  const [bankForm, setBankForm] = useState({ no: "", name: "", iban: "", balance: "0", currency: "ل.س" });
  const [transferOpen, setTransferOpen] = useState(false);
  const [defaultFromId, setDefaultFromId] = useState<string | undefined>(undefined);
  const [moveModal, setMoveModal] = useState<{ type: "deposit" | "withdraw"; bankId: string } | null>(null);
  const [moveForm, setMoveForm] = useState({ amount: "", desc: "" });
  const [deleteBank, setDeleteBank] = useState<BankAccount | null>(null);
  const [q, setQ] = useState("");
  // حركات البنوك: عرض / تعديل / حذف
  const [viewingBankMove, setViewingBankMove] = useState<BankMove | null>(null);
  const [editingBankMove, setEditingBankMove] = useState<BankMove | null>(null);
  const [editBankMoveForm, setEditBankMoveForm] = useState({ desc: "", amount: "" });
  const [deletingBankMove, setDeletingBankMove] = useState<BankMove | null>(null);

  const totalBank = banks.reduce((s, b) => s + (b.balance || 0), 0);
  const todayIn = bankMoves.filter((m) => m.date.slice(0, 10) === todayISO()).reduce((s, m) => s + m.in, 0);
  const todayOut = bankMoves.filter((m) => m.date.slice(0, 10) === todayISO()).reduce((s, m) => s + m.out, 0);

  const shownMoves = useMemo(
    () =>
      bankMoves.filter(
        (m) =>
          !q ||
          m.desc.includes(q) ||
          (m.bankName && m.bankName.includes(q))
      ),
    [bankMoves, q]
  );

  const createBank = () => {
    if (!bankForm.name.trim() || (!bankForm.no.trim() && !bankForm.iban.trim())) {
      notify("أدخل اسم البنك ورقم الحساب / IBAN", "warn");
      return;
    }
    const initBalance = Number(bankForm.balance) || 0;
    const newBank: BankAccount = {
      id: `bk_${Date.now()}`,
      no: bankForm.no.trim() || bankForm.iban.trim(),
      bank: bankForm.name.trim(),
      name: bankForm.name.trim(),
      iban: bankForm.iban.trim() || bankForm.no.trim(),
      balance: initBalance,
      currency: bankForm.currency,
    };
    setBanks((list) => [...list, newBank]);
    if (initBalance > 0) {
      setBankMoves((ms) => [
        {
          id: `bm_${Date.now()}_init`,
          date: new Date().toISOString(),
          bankId: newBank.id,
          bankName: `${newBank.name || newBank.bank} (#${newBank.no || newBank.iban})`,
          desc: `رصيد افتتاحي للحساب البنكي «${newBank.name || newBank.bank}»`,
          in: initBalance,
          out: 0,
          balanceAfter: initBalance,
          type: "deposit",
        },
        ...ms,
      ]);
    }
    notify(`تم إضافة حساب البنك «${newBank.name || newBank.bank}» بنجاح ✓`);
    setCreateModal(false);
    setBankForm({ no: "", name: "", iban: "", balance: "0", currency: "ل.س" });
  };

  const executeTransfer = (fromId: string, toId: string, amountVal: number, descText: string) => {
    const fromBox = cashboxes.find((c) => c.id === fromId);
    const fromBank = banks.find((b) => b.id === fromId);
    const toBox = cashboxes.find((c) => c.id === toId);
    const toBank = banks.find((b) => b.id === toId);

    if ((!fromBox && !fromBank) || (!toBox && !toBank)) {
      notify("تعذر تحديد الحساب المرسل أو المستقبل", "warn");
      return;
    }
    if (!amountVal || amountVal <= 0) {
      notify("أدخل مبلغاً صحيحاً أكبر من صفر", "warn");
      return;
    }

    const senderName = fromBox
      ? `صندوق #${fromBox.no} - ${fromBox.name}`
      : `${fromBank?.name || fromBank?.bank} (#${fromBank?.no || fromBank?.iban})`;
    const receiverName = toBox
      ? `صندوق #${toBox.no} - ${toBox.name}`
      : `${toBank?.name || toBank?.bank} (#${toBank?.no || toBank?.iban})`;
    const nowIso = new Date().toISOString();

    if (fromBox) {
      const updatedBalance = (fromBox.balance || 0) - amountVal;
      setCashboxes((list) => list.map((c) => (c.id === fromBox.id ? { ...c, balance: updatedBalance } : c)));
      setMoves((ms) => [
        {
          id: `m_${Date.now()}_out`,
          date: nowIso,
          cashboxId: fromBox.id,
          cashboxName: senderName,
          desc: `تحويل صادر إلى: ${receiverName}` + (descText ? ` — ${descText}` : ""),
          in: 0,
          out: amountVal,
          balanceAfter: updatedBalance,
          type: "transfer-bank",
        },
        ...ms,
      ]);
    } else if (fromBank) {
      const updatedBalance = (fromBank.balance || 0) - amountVal;
      setBanks((list) => list.map((b) => (b.id === fromBank.id ? { ...b, balance: updatedBalance } : b)));
      setBankMoves((ms) => [
        {
          id: `bm_${Date.now()}_out`,
          date: nowIso,
          bankId: fromBank.id,
          bankName: senderName,
          desc: `تحويل صادر إلى: ${receiverName}` + (descText ? ` — ${descText}` : ""),
          in: 0,
          out: amountVal,
          balanceAfter: updatedBalance,
          type: "transfer-bank",
        },
        ...ms,
      ]);
    }

    if (toBox) {
      const updatedBalance = (toBox.balance || 0) + amountVal;
      setCashboxes((list) => list.map((c) => (c.id === toBox.id ? { ...c, balance: updatedBalance } : c)));
      setMoves((ms) => [
        {
          id: `m_${Date.now()}_in`,
          date: nowIso,
          cashboxId: toBox.id,
          cashboxName: receiverName,
          desc: `تحويل وارد من: ${senderName}` + (descText ? ` — ${descText}` : ""),
          in: amountVal,
          out: 0,
          balanceAfter: updatedBalance,
          type: "transfer-box",
        },
        ...ms,
      ]);
    } else if (toBank) {
      const updatedBalance = (toBank.balance || 0) + amountVal;
      setBanks((list) => list.map((b) => (b.id === toBank.id ? { ...b, balance: updatedBalance } : b)));
      setBankMoves((ms) => [
        {
          id: `bm_${Date.now()}_in`,
          date: nowIso,
          bankId: toBank.id,
          bankName: receiverName,
          desc: `تحويل وارد من: ${senderName}` + (descText ? ` — ${descText}` : ""),
          in: amountVal,
          out: 0,
          balanceAfter: updatedBalance,
          type: "transfer-bank",
        },
        ...ms,
      ]);
    }

    notify(`تم تحويل ${SAR(amountVal)} من «${senderName}» إلى «${receiverName}» وتقييد الحركات بنجاح ✓`);
  };

  const executeQuickMove = () => {
    if (!moveModal) return;
    const a = Number(moveForm.amount);
    if (!a || a <= 0 || !moveForm.desc.trim()) {
      notify("أدخل المبلغ والبيان", "warn");
      return;
    }
    const bank = banks.find((b) => b.id === moveModal.bankId);
    if (!bank) return;
    const isIn = moveModal.type === "deposit";
    const updatedBalance = (bank.balance || 0) + (isIn ? a : -a);
    setBanks((list) => list.map((b) => (b.id === bank.id ? { ...b, balance: updatedBalance } : b)));
    setBankMoves((ms) => [
      {
        id: `bm_${Date.now()}`,
        date: new Date().toISOString(),
        bankId: bank.id,
        bankName: `${bank.name || bank.bank} (#${bank.no || bank.iban})`,
        desc: moveForm.desc.trim(),
        in: isIn ? a : 0,
        out: isIn ? 0 : a,
        balanceAfter: updatedBalance,
        type: isIn ? "deposit" : "withdraw",
      },
      ...ms,
    ]);
    notify(isIn ? `تم إيداع ${SAR(a)} في الحساب البنكي ✓` : `تم سحب ${SAR(a)} من الحساب البنكي ✓`);
    setMoveModal(null);
    setMoveForm({ amount: "", desc: "" });
  };

  const openEditBankMove = (m: BankMove) => {
    setEditingBankMove(m);
    setEditBankMoveForm({ desc: m.desc, amount: String(m.in > 0 ? m.in : m.out) });
  };

  const saveEditBankMove = () => {
    if (!editingBankMove) return;
    const a = Number(editBankMoveForm.amount);
    if (!editBankMoveForm.desc.trim() || !a) { notify("أدخل البيان والمبلغ", "warn"); return; }
    const isIn = editingBankMove.in > 0;
    setBankMoves((ms) => ms.map((m) =>
      m.id === editingBankMove.id
        ? { ...m, desc: editBankMoveForm.desc.trim(), in: isIn ? a : 0, out: isIn ? 0 : a }
        : m
    ));
    notify("تم تعديل حركة البنك بنجاح");
    setEditingBankMove(null);
  };

  const confirmDeleteBankMove = () => {
    if (!deletingBankMove) return;
    moveToTrash(
      setTrash as Parameters<typeof moveToTrash>[0],
      "bankMove",
      deletingBankMove.desc || "حركة بنكية",
      `${deletingBankMove.in > 0 ? `وارد: ${SAR(deletingBankMove.in)}` : `صادر: ${SAR(deletingBankMove.out)}`} — ${DATE(deletingBankMove.date)}`,
      deletingBankMove,
      deletingBankMove.id
    );
    setBankMoves((ms) => ms.filter((m) => m.id !== deletingBankMove.id));
    notify("تم نقل حركة البنك إلى سلة المهملات", "info");
    setDeletingBankMove(null);
  };

  const confirmDeleteBank = () => {
    if (!deleteBank) return;
    moveToTrash(
      setTrash as Parameters<typeof moveToTrash>[0],
      "bank",
      `${deleteBank.name || deleteBank.bank} (#${deleteBank.no || deleteBank.iban})`,
      `رصيد: ${SAR(deleteBank.balance)} ${deleteBank.currency}`,
      deleteBank,
      deleteBank.id
    );
    setBanks((list) => list.filter((b) => b.id !== deleteBank.id));
    notify(`تم نقل الحساب «${deleteBank.name || deleteBank.bank}» إلى سلة المهملات — يمكن استعادته خلال 30 يوماً`, "info");
    setDeleteBank(null);
  };

  return (
    <div className="space-y-6">
      {/* شريط علوي ثابت: بطاقة إجمالي الرصيد + زرّا الإضافة والتحويل جنباً إلى جنب */}
      <div className="flex flex-wrap items-stretch gap-3">
        <Glass gold className="relative flex min-w-0 flex-1 items-center gap-3 overflow-hidden rounded-[20px] px-4 py-3 sm:px-5">
          <div className="pointer-events-none absolute -left-10 -top-12 h-32 w-32 rounded-full bg-[var(--gold)] opacity-10 blur-2xl" />
          <span
            className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border"
            style={{
              color: "var(--gold-bright)",
              borderColor: "color-mix(in srgb, currentColor 35%, transparent)",
              background: "color-mix(in srgb, currentColor 12%, transparent)",
            }}
          >
            <Landmark className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-[10px] font-bold text-[var(--muted)] sm:text-xs">إجمالي الأرصدة البنكية</p>
            <p
              className="num truncate font-display text-lg font-black leading-tight text-[var(--gold-bright)] sm:text-2xl"
              title={SAR(totalBank)}
            >
              {SAR(totalBank)}
            </p>
            <p className="mt-0.5 hidden text-[9px] font-bold text-[var(--faint)] sm:block">
              عدد البنوك: {NUM(banks.length)}
            </p>
          </div>
          {/* وارد / صادر اليوم كرقائق مدمجة */}
          <div className="ms-auto hidden shrink-0 flex-col gap-1.5 lg:flex">
            <span className="chip chip-green num">
              <ArrowDownToLine size={11} /> وارد اليوم: {SAR(todayIn)}
            </span>
            <span className="chip chip-red num">
              <ArrowUpFromLine size={11} /> صادر اليوم: {SAR(todayOut)}
            </span>
          </div>
        </Glass>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setDefaultFromId(banks[0]?.id);
              setTransferOpen(true);
            }}
            className="btn-ghost flex h-full items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-bold"
          >
            <ArrowRightLeft size={14} /> تحويل
          </button>
          <button
            onClick={() => setCreateModal(true)}
            className="btn-gold flex h-full items-center gap-1.5 rounded-xl px-5 py-2.5 text-xs font-black"
          >
            <Plus size={15} /> إضافة بنك
          </button>
        </div>
      </div>

      {/* وارد / صادر اليوم على الشاشات الصغيرة */}
      <div className="grid grid-cols-2 gap-3 lg:hidden">
        <Glass className="flex items-center gap-2 rounded-[16px] px-3 py-2.5">
          <ArrowDownToLine size={14} className="shrink-0 text-[var(--green)]" />
          <div className="min-w-0">
            <p className="text-[9px] font-bold text-[var(--muted)]">وارد اليوم</p>
            <p className="num truncate text-xs font-black text-[var(--green)]">{SAR(todayIn)}</p>
          </div>
        </Glass>
        <Glass className="flex items-center gap-2 rounded-[16px] px-3 py-2.5">
          <ArrowUpFromLine size={14} className="shrink-0 text-[var(--red)]" />
          <div className="min-w-0">
            <p className="text-[9px] font-bold text-[var(--muted)]">صادر اليوم</p>
            <p className="num truncate text-xs font-black text-[var(--red)]">{SAR(todayOut)}</p>
          </div>
        </Glass>
      </div>

      {/* لكل بنك رصيد منفصل */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <p className="font-display text-sm font-black text-[var(--gold-bright)]">
            🏦 الحسابات المصرفية المتاحة (رصيد منفصل لكل بنك)
          </p>
          <span className="text-xs font-bold text-[var(--muted)]">{NUM(banks.length)} حساباً</span>
        </div>

        {banks.length === 0 ? (
          <Glass>
            <EmptyState
              icon={<Landmark size={24} />}
              text="لا توجد حسابات بنكية بعد — اضغط على زر « + إضافة بنك جديد » في الأعلى لإضافة أول حساب"
            />
          </Glass>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {banks.map((b, i) => (
              <Glass
                key={b.id}
                gold={i === 0}
                className="card-hover relative flex flex-col justify-between overflow-hidden p-5"
              >
                <div className="pointer-events-none absolute -left-8 -top-10 h-28 w-28 rounded-full bg-[var(--gold)] opacity-10 blur-2xl" />
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="chip chip-gray font-black">{b.currency}</span>
                    <button
                      onClick={() => setDeleteBank(b)}
                      className="flex h-7 w-7 items-center justify-center rounded-lg text-[var(--red)] transition-colors hover:bg-[var(--red-soft)]"
                      title="حذف البنك"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <h3 className="mt-3 font-display text-lg font-black">{b.name || b.bank}</h3>
                  <p className="num mt-0.5 text-xs text-[var(--muted)]" dir="ltr">
                    #{b.no || b.iban}
                  </p>
                  <p className="num mt-2 font-display text-2xl font-black text-[var(--gold-bright)]">
                    {b.currency === "$" ? `$${NUM(b.balance)}` : SAR(b.balance)}
                  </p>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 border-t border-[var(--border)] pt-3">
                  <button
                    onClick={() => {
                      setMoveModal({ type: "deposit", bankId: b.id });
                      setMoveForm({ amount: "", desc: "" });
                    }}
                    className="btn-ghost rounded-xl py-2 text-[11px] font-extrabold text-[var(--green)]"
                  >
                    + إيداع
                  </button>
                  <button
                    onClick={() => {
                      setMoveModal({ type: "withdraw", bankId: b.id });
                      setMoveForm({ amount: "", desc: "" });
                    }}
                    className="btn-ghost rounded-xl py-2 text-[11px] font-extrabold text-[var(--red)]"
                  >
                    - سحب
                  </button>
                  <button
                    onClick={() => {
                      setDefaultFromId(b.id);
                      setTransferOpen(true);
                    }}
                    className="btn-ghost rounded-xl py-2 text-[11px] font-extrabold text-[var(--gold)]"
                  >
                    ⇄ تحويل
                  </button>
                </div>
              </Glass>
            ))}
          </div>
        )}
      </div>

      {/* سجل حركات وتحويلات البنوك المفصل */}
      <Glass className="overflow-hidden rounded-[20px] shadow-[0_18px_46px_rgba(0,0,0,0.25)]">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] px-5 py-4">
          <p className="font-display text-base font-extrabold">📑 سجل حركات وتحويلات البنوك المفصل</p>
          <div className="relative w-full max-w-[240px]">
            <Search
              size={14}
              className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--faint)]"
            />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="بحث بالبيان أو اسم البنك…"
              className="field w-full rounded-xl py-2 pr-9 ps-3 text-xs"
            />
          </div>
        </div>
        <div className="max-h-[50vh] overflow-auto">
          <table className="lux-table">
            <thead>
              <tr>
                <th>#</th>
                <th>التاريخ والوقت</th>
                <th>اسم البنك / الحساب</th>
                <th>البيان / تفاصيل التحويل</th>
                <th>وارد (+)</th>
                <th>صادر (-)</th>
                <th>الرصيد بعد الحركة</th>
                <th className="no-print">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {shownMoves.map((m, i) => (
                <tr key={m.id} className="group">
                  <td className="num font-black text-[var(--faint)]">{NUM(i + 1)}</td>
                  <td>
                    <p className="num text-xs font-bold">{DATE(m.date)}</p>
                    <p className="num text-[10px] text-[var(--faint)]">{TIME(m.date)}</p>
                  </td>
                  <td className="font-black text-[var(--gold-bright)]">{m.bankName || "بنك عام"}</td>
                  <td className="max-w-[220px] truncate font-bold" title={m.desc}>{m.desc}</td>
                  <td className="num font-black text-[var(--green)]">{m.in > 0 ? SAR(m.in) : "—"}</td>
                  <td className="num font-black text-[var(--red)]">{m.out > 0 ? SAR(m.out) : "—"}</td>
                  <td className="num font-black text-[var(--text)]">
                    {m.balanceAfter != null ? SAR(m.balanceAfter) : "—"}
                  </td>
                  <td className="no-print">
                    <span className="flex items-center gap-1 opacity-70 transition-opacity group-hover:opacity-100">
                      <button onClick={() => setViewingBankMove(m)} title="عرض التفاصيل" className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--sky)] hover:bg-[var(--sky-soft)]"><Eye size={13} /></button>
                      <button onClick={() => openEditBankMove(m)} title="تعديل" className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--gold)] hover:bg-[var(--gold-dim)]"><Pencil size={13} /></button>
                      <button onClick={() => setDeletingBankMove(m)} title="نقل إلى السلة" className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--red)] hover:bg-[var(--red-soft)]"><Trash2 size={13} /></button>
                    </span>
                  </td>
                </tr>
              ))}
              {shownMoves.length === 0 && (
                <tr>
                  <td colSpan={8}>
                    <EmptyState icon={<Landmark size={24} />} text={q ? "لا توجد حركات بنكية مطابقة للبحث" : "لا توجد حركات مسجلة بعد — قم بإضافة بنك أو إجراء إيداع وتحويل"} />
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--border)] bg-[var(--surface)] px-5 py-3.5">
          <p className="text-[11px] font-bold text-[var(--muted)]">
            عدد الحركات المسجلة: <span className="num font-black text-[var(--text)]">{NUM(shownMoves.length)}</span>
          </p>
          <div className="flex gap-4 text-xs font-black">
            <span className="text-[var(--green)]">إجمالي الوارد: {SAR(shownMoves.reduce((s, m) => s + m.in, 0))}</span>
            <span className="text-[var(--red)]">إجمالي الصادر: {SAR(shownMoves.reduce((s, m) => s + m.out, 0))}</span>
          </div>
        </div>
      </Glass>

      {/* مودال إنشاء حساب بنكي */}
      <Modal open={createModal} onClose={() => setCreateModal(false)} title="إضافة حساب بنكي جديد">
        <div className="grid grid-cols-2 gap-4">
          <L label="رقم الحساب / IBAN">
            <input
              autoFocus
              className={`${inputCls} num`}
              value={bankForm.no}
              onChange={(e) => setBankForm({ ...bankForm, no: e.target.value })}
              placeholder="مثال: SA03... أو 1001"
            />
          </L>
          <L label="اسم البنك / المصرف">
            <input
              className={inputCls}
              value={bankForm.name}
              onChange={(e) => setBankForm({ ...bankForm, name: e.target.value })}
              placeholder="مثال: مصرف الراجحي أو بنك الرياض"
            />
          </L>
          <L label="الرصيد الافتتاحي">
            <input
              type="number"
              min={0}
              className={`${inputCls} num`}
              value={bankForm.balance}
              onChange={(e) => setBankForm({ ...bankForm, balance: e.target.value })}
              placeholder="0"
            />
          </L>
          <L label="العملة">
            <select
              className={inputCls}
              value={bankForm.currency}
              onChange={(e) => setBankForm({ ...bankForm, currency: e.target.value })}
            >
              <option value="ل.س">ل.س (ليرة سورية)</option>
              <option value="$">$ (دولار أمريكي)</option>
              <option value="ر.س">ر.س (ريال سعودي)</option>
            </select>
          </L>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setCreateModal(false)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">
            إلغاء
          </button>
          <button onClick={createBank} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">
            حفظ الحساب في Firebase
          </button>
        </div>
      </Modal>

      {/* مودال إيداع / سحب بنكي سريع */}
      <Modal
        open={!!moveModal}
        onClose={() => setMoveModal(null)}
        title={moveModal?.type === "deposit" ? "إيداع مالي في الحساب البنكي" : "سحب مالي من الحساب البنكي"}
      >
        <div className="space-y-4">
          <L label="المبلغ (ل.س)">
            <input
              type="number"
              min={0}
              className={`${inputCls} num`}
              value={moveForm.amount}
              onChange={(e) => setMoveForm({ ...moveForm, amount: e.target.value })}
              placeholder="0"
              autoFocus
            />
          </L>
          <L label="البيان / ملاحظة الحركة">
            <input
              className={inputCls}
              value={moveForm.desc}
              onChange={(e) => setMoveForm({ ...moveForm, desc: e.target.value })}
              placeholder={moveModal?.type === "deposit" ? "مثال: إيداع حوالة واردة" : "مثال: سحب نقدي لتعزيز الصندوق"}
            />
          </L>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setMoveModal(null)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">
            إلغاء
          </button>
          <button onClick={executeQuickMove} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">
            تأكيد الحركة البنكية
          </button>
        </div>
      </Modal>

      {/* نافذة التحويل المشتركة */}
      <TransferModal
        open={transferOpen}
        onClose={() => setTransferOpen(false)}
        defaultFromId={defaultFromId}
        cashboxes={cashboxes}
        banks={banks}
        onExecute={executeTransfer}
      />

      {/* ====== مودال عرض تفاصيل حركة البنك ====== */}
      <Modal open={!!viewingBankMove} onClose={() => setViewingBankMove(null)} title="تفاصيل الحركة البنكية">
        {viewingBankMove && (
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-3">
              {[
                { l: "البنك / الحساب", v: viewingBankMove.bankName || "بنك عام" },
                { l: "نوع الحركة", v: viewingBankMove.type === "deposit" ? "إيداع" : viewingBankMove.type === "withdraw" ? "سحب" : viewingBankMove.type === "transfer-bank" ? "تحويل صادر" : viewingBankMove.type === "transfer-box" ? "تحويل وارد للصندوق" : "حركة" },
                { l: "التاريخ", v: DATE(viewingBankMove.date) },
                { l: "الوقت", v: TIME(viewingBankMove.date) },
              ].map(({ l, v }) => (
                <div key={l} className="rounded-xl border border-[var(--border)] px-3.5 py-3">
                  <p className="text-[10px] font-bold text-[var(--muted)]">{l}</p>
                  <p className="mt-0.5 font-black">{v}</p>
                </div>
              ))}
            </div>
            <div className="rounded-xl border border-[var(--border)] px-3.5 py-3">
              <p className="text-[10px] font-bold text-[var(--muted)]">البيان</p>
              <p className="mt-0.5 font-bold leading-5">{viewingBankMove.desc}</p>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-xl border border-[var(--border)] px-3.5 py-3">
                <p className="text-[10px] font-bold text-[var(--muted)]">وارد (+)</p>
                <p className="num mt-0.5 font-black text-[var(--green)]">{viewingBankMove.in > 0 ? SAR(viewingBankMove.in) : "—"}</p>
              </div>
              <div className="rounded-xl border border-[var(--border)] px-3.5 py-3">
                <p className="text-[10px] font-bold text-[var(--muted)]">صادر (-)</p>
                <p className="num mt-0.5 font-black text-[var(--red)]">{viewingBankMove.out > 0 ? SAR(viewingBankMove.out) : "—"}</p>
              </div>
              <div className="glass-gold rounded-xl px-3.5 py-3">
                <p className="text-[10px] font-bold text-[var(--muted)]">الرصيد بعد</p>
                <p className="num mt-0.5 font-black text-[var(--gold-bright)]">{viewingBankMove.balanceAfter != null ? SAR(viewingBankMove.balanceAfter) : "—"}</p>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => { setViewingBankMove(null); openEditBankMove(viewingBankMove); }} className="btn-ghost flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-bold">
                <Pencil size={13} /> تعديل
              </button>
              <button onClick={() => setViewingBankMove(null)} className="btn-gold rounded-xl px-5 py-2.5 text-xs font-black">إغلاق</button>
            </div>
          </div>
        )}
      </Modal>

      {/* ====== مودال تعديل حركة البنك ====== */}
      <Modal open={!!editingBankMove} onClose={() => setEditingBankMove(null)} title="تعديل الحركة البنكية" onSubmit={saveEditBankMove}>
        {editingBankMove && (
          <div className="space-y-4">
            <div className="rounded-xl border border-[var(--border-gold)] bg-[var(--gold-dim)] px-4 py-3 text-xs">
              <span className="font-bold text-[var(--muted)]">الحركة: </span>
              <span className="font-black">{editingBankMove.in > 0 ? `وارد — ${SAR(editingBankMove.in)}` : `صادر — ${SAR(editingBankMove.out)}`}</span>
              <span className="mx-2 text-[var(--faint)]">|</span>
              <span className="text-[var(--muted)]">{DATE(editingBankMove.date)}</span>
            </div>
            <L label="البيان">
              <input autoFocus className={inputCls} value={editBankMoveForm.desc} onChange={(e) => setEditBankMoveForm({ ...editBankMoveForm, desc: e.target.value })} enterKeyHint="next" />
            </L>
            <L label={`المبلغ (${editingBankMove.in > 0 ? "وارد" : "صادر"})`}>
              <input type="number" min={0} className={`${inputCls} num`} value={editBankMoveForm.amount} onChange={(e) => setEditBankMoveForm({ ...editBankMoveForm, amount: e.target.value })} enterKeyHint="go" />
            </L>
          </div>
        )}
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setEditingBankMove(null)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">إلغاء</button>
          <button onClick={saveEditBankMove} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">حفظ التعديل</button>
        </div>
      </Modal>

      {/* ====== تأكيد حذف حركة البنك ====== */}
      <ConfirmDialog
        open={!!deletingBankMove}
        onClose={() => setDeletingBankMove(null)}
        onConfirm={confirmDeleteBankMove}
        variant="danger"
        title="نقل حركة البنك إلى سلة المهملات"
        message={`هل تريد نقل حركة «${deletingBankMove?.desc ?? ""}» إلى السلة؟ يمكن استعادتها خلال 30 يوماً.`}
        confirmLabel="نقل إلى السلة"
      />

      {/* تأكيد حذف الحساب البنكي */}
      <ConfirmDialog
        open={!!deleteBank}
        onClose={() => setDeleteBank(null)}
        onConfirm={confirmDeleteBank}
        variant="danger"
        title="نقل الحساب إلى سلة المهملات"
        message={`سيتم نقل حساب «${deleteBank?.name || deleteBank?.bank}» إلى سلة المهملات. يمكن استعادته خلال 30 يوماً.`}
        detail={deleteBank && deleteBank.balance > 0 ? `⚠️ يحتوي الحساب على رصيد ${SAR(deleteBank.balance)} ${deleteBank?.currency ?? ""} — تأكد من التحويل قبل النقل` : undefined}
        confirmLabel="نقل إلى السلة"
      />
    </div>
  );
}

/* ================= الديون ================= */
function Debts() {
  const { notify, tenantUid } = useApp();
  const [debts, setDebts] = useTenantState<Debt[]>(tenantUid, "debts", DEBTS);
  const [paying, setPaying] = useState<Debt | null>(null);
  const [creditor, setCreditor] = useState<Debt | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [form, setForm] = useState({ party: "", phone: "", amount: "", due: todayISO(), origin: "", notes: "" });
  // تعديل وحذف الدين
  const [editingDebt, setEditingDebt] = useState<Debt | null>(null);
  const [editForm, setEditForm] = useState({ party: "", phone: "", amount: "", due: "", origin: "", notes: "" });
  const [deletingDebt, setDeletingDebt] = useState<Debt | null>(null);

  const list = debts.filter((d) => d.kind === "on");
  const overdue = list.filter((d) => daysLeft(d.due) < 0 && d.amount - d.paid > 0);
  const totalRemaining = list.reduce((s, d) => s + (d.amount - d.paid), 0);

  const openEdit = (d: Debt) => {
    setEditingDebt(d);
    setEditForm({
      party: d.party,
      phone: d.phone ?? "",
      amount: String(d.amount),
      due: d.due,
      origin: d.origin,
      notes: d.notes ?? "",
    });
  };

  const saveEdit = () => {
    if (!editingDebt) return;
    if (!editForm.party.trim() || !(Number(editForm.amount) > 0)) {
      notify("اسم الدائن ومبلغ الدين مطلوبان", "warn");
      return;
    }
    setDebts((items) =>
      items.map((d) =>
        d.id === editingDebt.id
          ? {
              ...d,
              party: editForm.party.trim(),
              phone: editForm.phone.trim(),
              amount: Number(editForm.amount),
              due: editForm.due,
              origin: editForm.origin.trim(),
              notes: editForm.notes.trim(),
            }
          : d
      )
    );
    notify(`تم تعديل بيانات دين «${editForm.party}» بنجاح`);
    setEditingDebt(null);
  };

  const confirmDeleteDebt = () => {
    if (!deletingDebt) return;
    setDebts((items) => items.filter((d) => d.id !== deletingDebt.id));
    notify(`تم حذف دين «${deletingDebt.party}» نهائياً`, "info");
    setDeletingDebt(null);
  };

  const addCreditor = () => {
    const debtAmount = Number(form.amount);
    if (!form.party.trim() || !form.phone.trim() || !(debtAmount > 0)) { notify("اسم الدائن ورقم الواتساب والمبلغ مطلوبة", "warn"); return; }
    const debt: Debt = {
      id: `debt_${Date.now()}`,
      party: form.party.trim(), phone: form.phone.trim(), kind: "on", amount: debtAmount, paid: 0,
      due: form.due, origin: form.origin.trim() || "دين مباشر", notes: form.notes.trim(),
    };
    setDebts((items) => [debt, ...items]);
    setAddOpen(false);
    setForm({ party: "", phone: "", amount: "", due: todayISO(), origin: "", notes: "" });
    notify(`تم إنشاء ملف الدائن «${debt.party}» وحفظ الدين في Firebase`);
  };

  const creditorDebts = creditor ? list.filter((d) => d.party === creditor.party && (d.phone ?? "") === (creditor.phone ?? "")) : [];
  const creditorRemaining = creditorDebts.reduce((s, d) => s + d.amount - d.paid, 0);
  const openWhatsApp = (d: Debt, detailed = false) => {
    const phone = (d.phone ?? "").replace(/\D/g, "").replace(/^00/, "");
    if (!phone) { notify("لا يوجد رقم واتساب محفوظ لهذا الدائن", "warn"); return; }
    const related = detailed ? list.filter((x) => x.party === d.party && (x.phone ?? "") === (d.phone ?? "")) : [d];
    const remaining = related.reduce((s, x) => s + x.amount - x.paid, 0);
    const details = related.map((x, i) => `${i + 1}- ${x.origin}: ${SAR(x.amount - x.paid)} - استحقاق ${DATE(x.due)}`).join("\n");
    const message = `مرحباً ${d.party}،\nتذكير من شركة الرفاه للحوالات المالية.\n${details}\nإجمالي الدين المتبقي: ${SAR(remaining)}\nيرجى التواصل لتسوية المستحقات، وشكراً.`;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
  };

  const pay = () => {
    const a = Number(amount);
    if (!a || !paying) { notify("أدخل مبلغاً صحيحاً", "warn"); return; }
    setDebts((ds) => ds.map((d) => (d.id === paying.id ? { ...d, paid: Math.min(d.paid + a, d.amount) } : d)));
    notify(`تم تسجيل دفعة ${SAR(a)} لصالح ${paying.party}`);
    setPaying(null); setAmount("");
  };

  return (
    <div className="space-y-4">
      {overdue.length > 0 && (
        <div className="glass flex items-center gap-3 rounded-2xl border-[var(--red)] !bg-[var(--red-soft)] px-5 py-3.5">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--red)] text-white"><BellRing size={16} /></span>
          <div className="flex-1">
            <p className="text-xs font-black text-[var(--red)]">تنبيه ذكي: {NUM(overdue.length)} دين متأخر يتطلب متابعة</p>
            <p className="text-[11px] text-[var(--muted)]">إجمالي المتأخرات: <span className="num font-black text-[var(--red)]">{SAR(overdue.reduce((s, d) => s + d.amount - d.paid, 0))}</span></p>
          </div>
        </div>
      )}

      <Glass className="overflow-hidden rounded-[20px]">
        <div className="flex flex-wrap items-center gap-3 border-b border-[var(--border)] px-5 py-3.5">
          <div className="flex flex-wrap items-center gap-2">
            <p className="flex items-center gap-2 text-xs font-black"><UserRound size={15} className="text-[var(--gold)]" /> سجل الدائنين وديونهم</p>
            <ExportBar
              name="سجل-الديون"
              rows={[
                ["الدائن", "رقم واتساب", "سبب الدين", "المبلغ", "المدفوع", "المتبقي", "الاستحقاق"],
                ...list.map((d) => [
                  d.party,
                  d.phone || "",
                  d.origin,
                  d.amount,
                  d.paid,
                  d.amount - d.paid,
                  DATE(d.due),
                ]),
              ]}
            />
          </div>
          <p className="ms-auto text-[11px] font-bold text-[var(--muted)]">إجمالي الديون: <span className="num font-black text-[var(--gold-bright)]">{SAR(totalRemaining)}</span></p>
          <button onClick={() => setAddOpen(true)} className="btn-gold flex items-center gap-2 rounded-xl px-4 py-2 text-xs"><Plus size={14} /> إضافة دائن</button>
        </div>
        <div className="overflow-x-auto">
          <table className="lux-table">
            <thead><tr><th>الدائن</th><th>واتساب</th><th>سبب الدين</th><th>المبلغ</th><th>المدفوع</th><th>المتبقي</th><th>الاستحقاق</th><th>الإجراءات</th></tr></thead>
            <tbody>
              {list.map((d) => {
                const remaining = d.amount - d.paid;
                const chip = dueChip(d.due);
                return (
                  <tr key={d.id}>
                    <td><button onClick={() => setCreditor(d)} className="font-black text-[var(--gold-bright)] hover:underline">{d.party}</button></td>
                    <td className="num text-[var(--muted)]" dir="ltr">{d.phone || "—"}</td>
                    <td className="num text-[var(--muted)]">{d.origin}</td>
                    <td className="num font-bold">{SAR(d.amount)}</td>
                    <td className="num text-[var(--green)]">{SAR(d.paid)}</td>
                    <td className="num font-black" style={{ color: remaining === 0 ? "var(--green)" : "var(--gold-bright)" }}>{remaining === 0 ? "✓" : SAR(remaining)}</td>
                    <td><Chip label={remaining === 0 ? "مسدّد بالكامل" : chip.text} cls={remaining === 0 ? "chip-green" : chip.cls} /></td>
                    <td className="no-print">
                       <span className="flex flex-wrap items-center gap-1">
                         <button onClick={() => setCreditor(d)} title="صفحة الدائن" className="btn-ghost flex h-7 w-7 items-center justify-center rounded-md text-[var(--sky)] hover:bg-[var(--sky-soft)]"><Eye size={13} /></button>
                         <button onClick={() => openEdit(d)} title="تعديل الدين" className="btn-ghost flex h-7 w-7 items-center justify-center rounded-md text-[var(--gold)] hover:bg-[var(--gold-dim)]"><Pencil size={13} /></button>
                         <button onClick={() => openWhatsApp(d)} title="واتساب" className="flex h-7 w-7 items-center justify-center rounded-md bg-[#25D366]/15 text-[#25D366] hover:bg-[#25D366]/25"><MessageCircle size={13} /></button>
                         {remaining > 0 && <button onClick={() => { setPaying(d); setAmount(""); }} className="btn-ghost rounded-md px-2 py-1 text-[10px] font-black">دفعة</button>}
                         <button onClick={() => setDeletingDebt(d)} title="حذف الدين" className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--red)] hover:bg-[var(--red-soft)]"><Trash2 size={13} /></button>
                       </span>
                     </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Glass>

      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="إضافة دائن جديد">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <L label="اسم الدائن"><input autoFocus className={inputCls} value={form.party} onChange={(e) => setForm({ ...form, party: e.target.value })} /></L>
          <L label="رقم واتساب (مع رمز الدولة)"><input dir="ltr" className={inputCls} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="905xxxxxxxxx" /></L>
          <L label="مبلغ الدين"><input type="number" min={0} className={`${inputCls} num`} value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></L>
          <L label="تاريخ الاستحقاق"><input type="date" className={inputCls} value={form.due} onChange={(e) => setForm({ ...form, due: e.target.value })} /></L>
          <L label="سبب / مصدر الدين" className="sm:col-span-2"><input className={inputCls} value={form.origin} onChange={(e) => setForm({ ...form, origin: e.target.value })} placeholder="مثال: حوالة غير مسددة" /></L>
          <L label="ملاحظات" className="sm:col-span-2"><textarea className={`${inputCls} min-h-20 resize-none`} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></L>
        </div>
        <div className="mt-6 flex justify-end gap-2"><button onClick={() => setAddOpen(false)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs">إلغاء</button><button onClick={addCreditor} className="btn-gold rounded-xl px-6 py-2.5 text-xs">حفظ الدائن والدين</button></div>
      </Modal>

      <Modal open={!!creditor} onClose={() => setCreditor(null)} title={`صفحة الدائن — ${creditor?.party ?? ""}`} wide>
        {creditor && <div>
          <div className="mb-5 grid gap-3 sm:grid-cols-3">
            <div className="glass-gold rounded-xl p-4"><p className="text-[10px] text-[var(--muted)]">إجمالي المتبقي</p><p className="num mt-1 text-xl font-black">{SAR(creditorRemaining)}</p></div>
            <div className="glass rounded-xl p-4"><p className="text-[10px] text-[var(--muted)]">عدد الديون</p><p className="num mt-1 text-xl font-black">{NUM(creditorDebts.length)}</p></div>
            <button onClick={() => openWhatsApp(creditor, true)} className="flex items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 py-3 text-sm font-black text-white shadow-lg hover:brightness-105"><MessageCircle size={18} /> إرسال كشف الدين واتساب</button>
          </div>
          <div className="overflow-x-auto rounded-xl border border-[var(--border)]"><table className="lux-table"><thead><tr><th>المصدر</th><th>المبلغ</th><th>المدفوع</th><th>المتبقي</th><th>الاستحقاق</th></tr></thead><tbody>{creditorDebts.map((d) => <tr key={d.id}><td className="font-bold">{d.origin}</td><td className="num">{SAR(d.amount)}</td><td className="num text-[var(--green)]">{SAR(d.paid)}</td><td className="num font-black text-[var(--gold-bright)]">{SAR(d.amount - d.paid)}</td><td>{DATE(d.due)}</td></tr>)}</tbody></table></div>
          {creditor.notes && <p className="mt-4 rounded-xl bg-[var(--surface)] p-3 text-xs text-[var(--muted)]">{creditor.notes}</p>}
        </div>}
      </Modal>

      <Modal open={!!paying} onClose={() => setPaying(null)} title={`دفعة — ${paying?.party ?? ""}`}>
        <p className="mb-4 rounded-xl border border-[var(--border-gold)] bg-[var(--gold-dim)] px-4 py-3 text-xs font-bold">
          المتبقي المستحق: <span className="num font-black text-[var(--gold-bright)]">{paying ? SAR(paying.amount - paying.paid) : ""}</span>
        </p>
        <L label="مبلغ الدفعة"><input type="number" min={0} className={`${inputCls} num`} value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" autoFocus /></L>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setPaying(null)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">إلغاء</button>
          <button onClick={pay} className="btn-gold flex items-center gap-1.5 rounded-xl px-6 py-2.5 text-xs font-black"><CheckCircle2 size={14} /> تأكيد الدفعة</button>
        </div>
      </Modal>

      {/* ====== مودال تعديل الدين ====== */}
      <Modal open={!!editingDebt} onClose={() => setEditingDebt(null)} title="تعديل بيانات الدين" onSubmit={saveEdit}>
        {editingDebt && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <L label="اسم الدائن" className="sm:col-span-2">
              <input className={inputCls} value={editForm.party} onChange={(e) => setEditForm({ ...editForm, party: e.target.value })} autoFocus enterKeyHint="next" />
            </L>
            <L label="رقم واتساب">
              <input dir="ltr" className={inputCls} value={editForm.phone} onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })} placeholder="905xxxxxxxxx" enterKeyHint="next" />
            </L>
            <L label="مبلغ الدين">
              <input type="number" min={0} className={`${inputCls} num`} value={editForm.amount} onChange={(e) => setEditForm({ ...editForm, amount: e.target.value })} enterKeyHint="next" />
            </L>
            <L label="تاريخ الاستحقاق">
              <input type="date" className={inputCls} value={editForm.due} onChange={(e) => setEditForm({ ...editForm, due: e.target.value })} />
            </L>
            <L label="سبب / مصدر الدين">
              <input className={inputCls} value={editForm.origin} onChange={(e) => setEditForm({ ...editForm, origin: e.target.value })} placeholder="مثال: حوالة غير مسددة" enterKeyHint="next" />
            </L>
            <L label="ملاحظات" className="sm:col-span-2">
              <textarea className={`${inputCls} min-h-20 resize-none`} value={editForm.notes} onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })} />
            </L>
          </div>
        )}
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setEditingDebt(null)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">إلغاء</button>
          <button onClick={saveEdit} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">حفظ التعديلات</button>
        </div>
      </Modal>

      {/* ====== تأكيد حذف الدين ====== */}
      <ConfirmDialog
        open={!!deletingDebt}
        onClose={() => setDeletingDebt(null)}
        onConfirm={confirmDeleteDebt}
        variant="danger"
        title="حذف الدين نهائياً"
        message={`هل تريد حذف دين «${deletingDebt?.party ?? ""}» نهائياً؟`}
        detail={deletingDebt ? `المبلغ المتبقي: ${SAR(deletingDebt.amount - deletingDebt.paid)} — لا يمكن التراجع عن هذا الإجراء` : undefined}
        confirmLabel="حذف الدين نهائياً"
      />
    </div>
  );
}

/* ================= الأرصدة الافتتاحية ================= */
function Opening() {
  const { notify, tenantUid } = useApp();
  const initialRows = useMemo(() => OPENING_ROWS.map((r) => ({ ...r, debit: String(r.debit), credit: String(r.credit) })), []);
  const [rows, setRows] = useTenantState(tenantUid, "settings/openingBalances", initialRows);
  const tD = rows.reduce((s, r) => s + (Number(r.debit) || 0), 0);
  const tC = rows.reduce((s, r) => s + (Number(r.credit) || 0), 0);
  const balanced = tD === tC && tD > 0;

  return (
    <Glass className="overflow-hidden rounded-[20px]">
      <div className="border-b border-[var(--border)] px-5 py-4">
        <h3 className="font-display text-base font-extrabold">الأرصدة الافتتاحية — بداية التشغيل</h3>
        <p className="mt-1 text-xs text-[var(--muted)]">عدّل الأرصدة ثم احفظ — يُشترط توازن المدين والدائن كما في القيود</p>
      </div>
      <div className="overflow-x-auto">
        <table className="lux-table">
          <thead><tr><th>الحساب</th><th>مدين</th><th>دائن</th></tr></thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.accountId}>
                <td className="font-bold">{r.label}</td>
                <td><input type="number" min={0} className={`${inputCls} !w-36 !py-1.5 text-xs num`} value={r.debit} onChange={(e) => setRows((rs) => rs.map((x, j) => j === i ? { ...x, debit: e.target.value } : x))} /></td>
                <td><input type="number" min={0} className={`${inputCls} !w-36 !py-1.5 text-xs num`} value={r.credit} onChange={(e) => setRows((rs) => rs.map((x, j) => j === i ? { ...x, credit: e.target.value } : x))} /></td>
              </tr>
            ))}
            <tr>
              <td className="font-black">الإجمالي</td>
              <td className="num font-black text-[var(--green)]">{SAR(tD)}</td>
              <td className="num font-black text-[var(--red)]">{SAR(tC)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--border)] px-5 py-4">
        <span className={`chip ${balanced ? "chip-green" : "chip-red"}`}>
          {balanced ? <><CheckCircle2 size={12} /> الأرصدة متوازنة</> : `الفرق: ${SAR(Math.abs(tD - tC))}`}
        </span>
        <button onClick={() => balanced && notify("تم حفظ الأرصدة الافتتاحية وترحيلها بنجاح")} disabled={!balanced} className={`no-print rounded-xl px-6 py-2.5 text-xs font-black ${balanced ? "btn-gold" : "cursor-not-allowed bg-[var(--surface-2)] text-[var(--faint)]"}`}>
          حفظ الأرصدة الافتتاحية
        </button>
      </div>
    </Glass>
  );
}

/* ================= المصاريف والإيرادات ================= */
function ExIn() {
  const { notify, tenantUid } = useApp();
  const [tab, setTab] = useState<"expenses" | "income">("expenses");
  const [items, setItems] = useTenantState<Array<{ id: number; cat: string; desc: string; amount: number; date: string; kind: "expenses" | "income" }>>(tenantUid, "treasury/incomeExpenses", []);
  const [form, setForm] = useState({ cat: "", desc: "", amount: "" });

  const list = items.filter((i) => i.kind === tab);
  const total = list.reduce((s, i) => s + i.amount, 0);

  const add = () => {
    const a = Number(form.amount);
    if (!form.cat || !a) { notify("أدخل البند والمبلغ", "warn"); return; }
    setItems((is) => [{ id: Date.now(), cat: form.cat, desc: form.desc || form.cat, amount: a, date: todayISO(), kind: tab }, ...is]);
    notify(`تم تسجيل ${tab === "expenses" ? "مصروف" : "إيراد"} بقيمة ${SAR(a)}`);
    setForm({ cat: "", desc: "", amount: "" });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="glass rounded-[20px] p-5">
          <p className="text-xs font-bold text-[var(--muted)]">إجمالي المصاريف (الفترة)</p>
          <p className="num mt-1 font-display text-2xl font-black text-[var(--red)]">{SAR(items.filter((i) => i.kind === "expenses").reduce((s, i) => s + i.amount, 0))}</p>
        </div>
        <div className="glass rounded-[20px] p-5">
          <p className="text-xs font-bold text-[var(--muted)]">إجمالي الإيرادات (الفترة)</p>
          <p className="num mt-1 font-display text-2xl font-black text-[var(--green)]">{SAR(items.filter((i) => i.kind === "income").reduce((s, i) => s + i.amount, 0))}</p>
        </div>
      </div>

      <Glass className="overflow-hidden rounded-[20px]">
        <div className="flex flex-wrap items-center gap-3 border-b border-[var(--border)] px-5 py-3.5">
          <div className="no-print flex rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1">
            {([["expenses", "المصاريف"], ["income", "الإيرادات"]] as const).map(([k, l]) => (
              <button key={k} onClick={() => setTab(k)} className={`rounded-lg px-4 py-1.5 text-[11px] font-black transition-all ${tab === k ? "bg-gradient-to-l from-[var(--gold-bright)] to-[var(--gold)] text-[#171207]" : "text-[var(--muted)] hover:text-[var(--text)]"}`}>{l}</button>
            ))}
          </div>
          <p className="ms-auto text-[11px] font-bold text-[var(--muted)]">الإجمالي: <span className="num font-black" style={{ color: tab === "expenses" ? "var(--red)" : "var(--green)" }}>{SAR(total)}</span></p>
        </div>

        <div className="grid gap-3 border-b border-[var(--border)] bg-[var(--surface)] px-5 py-4 sm:grid-cols-[140px_1fr_140px_auto]">
          <input
            className={`${inputCls} !py-2 text-xs`}
            placeholder="البند (رواتب، عمولات حوالات…)"
            value={form.cat}
            onChange={(e) => setForm({ ...form, cat: e.target.value })}
            onKeyDown={(e) => handleNextOrGo(e, add)}
            enterKeyHint="next"
          />
          <input
            className={`${inputCls} !py-2 text-xs`}
            placeholder="البيان / الوصف"
            value={form.desc}
            onChange={(e) => setForm({ ...form, desc: e.target.value })}
            onKeyDown={(e) => handleNextOrGo(e, add)}
            enterKeyHint="next"
          />
          <input
            type="number"
            min={0}
            className={`${inputCls} !py-2 text-xs num`}
            placeholder="المبلغ"
            value={form.amount}
            onChange={(e) => setForm({ ...form, amount: e.target.value })}
            onKeyDown={(e) => handleNextOrGo(e, add)}
            enterKeyHint="go"
          />
          <button onClick={add} className="btn-gold flex items-center justify-center gap-1.5 rounded-xl px-5 py-2 text-xs font-black"><Plus size={14} /> تسجيل</button>
        </div>

        <div className="max-h-[46vh] overflow-y-auto">
          <table className="lux-table">
            <thead><tr><th>التاريخ</th><th>البند</th><th>البيان</th><th>المبلغ</th></tr></thead>
            <tbody>
              {list.map((i) => (
                <tr key={i.id}>
                  <td className="num text-[var(--muted)]">{DATE(i.date)}</td>
                  <td><Chip label={i.cat} cls="chip-gold" /></td>
                  <td className="font-bold">{i.desc}</td>
                  <td className="num font-black" style={{ color: tab === "expenses" ? "var(--red)" : "var(--green)" }}>{SAR(i.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Glass>
    </div>
  );
}

/* ================= القسم الرئيسي ================= */
export default function Treasury({ tab }: { tab: TreasuryTab }) {
  const titles: Record<TreasuryTab, [string, string]> = {
    cash: ["الصندوق", "إدارة النقدية اليومية — إيداع وصرف وتتبع الرصيد"],
    banks: ["البنوك", "الحسابات البنكية والتحويلات الداخلية"],
    debts: ["الدائنون والديون", "إدارة الدائنين، صفحات الديون، الدفعات، وتنبيهات واتساب"],
    opening: ["الأرصدة الافتتاحية", "أرصدة بداية السنة المالية"],
    exin: ["المصاريف والإيرادات", "تسجيل ومتابعة التدفقات التشغيلية"],
  };

  return (
    <div>
      {tab !== "banks" && tab !== "cash" && (
        <SectionHead title={titles[tab][0]} sub={titles[tab][1]} />
      )}
      {tab === "cash" && <Cashbox />}
      {tab === "banks" && <Banks />}
      {tab === "debts" && <Debts />}
      {tab === "opening" && <Opening />}
      {tab === "exin" && <ExIn />}
    </div>
  );
}
