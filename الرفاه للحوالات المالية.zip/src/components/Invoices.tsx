import { useMemo, useState } from "react";
import { ArrowDownUp, Eye, FilePlus2, Printer, ReceiptText } from "lucide-react";
import {
  INVOICES, INVOICE_STATUS_CHIP, INVOICE_STATUS_LABEL,
  type Invoice, type InvoiceStatus, type InvoiceType,
} from "../data/mock";
import { DATE, NUM, SAR, todayISO } from "../utils/format";
import { Chip, ExportBar, Glass, L, Modal, SectionHead, inputCls, useApp } from "./ui";
import { useTenantState } from "../lib/tenant";

type Tab = "all" | InvoiceType;
type SortKey = "no" | "date" | "total";

const TABS: { id: Tab; label: string }[] = [
  { id: "all", label: "الكل" },
  { id: "sale", label: "حوالات صادرة" },
  { id: "purchase", label: "حوالات واردة" },
  { id: "saleReturn", label: "حوالات مسترجعة" },
  { id: "purchaseReturn", label: "حوالات معكوسة" },
  { id: "quote", label: "حوالات أولية" },
];
const TRANSFER_TYPE_LABEL: Record<InvoiceType, string> = {
  sale: "حوالة صادرة",
  purchase: "حوالة واردة",
  saleReturn: "حوالة مسترجعة",
  purchaseReturn: "حوالة معكوسة",
  quote: "حوالة أولية",
};

export default function Invoices() {
  const { notify, tenantUid } = useApp();
  const [invoices, setInvoices] = useTenantState<Invoice[]>(tenantUid, "invoices", INVOICES);
  const [tab, setTab] = useState<Tab>("all");
  const [status, setStatus] = useState<"all" | InvoiceStatus>("all");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<{ key: SortKey; dir: 1 | -1 }>({ key: "date", dir: -1 });
  const [modal, setModal] = useState(false);
  const [viewing, setViewing] = useState<Invoice | null>(null);
  const [form, setForm] = useState({ type: "sale" as InvoiceType, party: "", subtotal: "", due: todayISO() });

  const shown = useMemo(() => {
    let list = invoices.filter(
      (i) =>
        (tab === "all" || i.type === tab) &&
        (status === "all" || i.status === status) &&
        (!q || i.no.toLowerCase().includes(q.toLowerCase()) || i.party.includes(q))
    );
    list = [...list].sort((a, b) => {
      const va = sort.key === "no" ? a.no : sort.key === "date" ? a.date : a.total;
      const vb = sort.key === "no" ? b.no : sort.key === "date" ? b.date : b.total;
      return (va < vb ? -1 : va > vb ? 1 : 0) * sort.dir;
    });
    return list;
  }, [invoices, tab, status, q, sort]);

  const totals = useMemo(() => ({
    all: shown.reduce((s, i) => s + i.total, 0),
    paid: shown.reduce((s, i) => s + i.paid, 0),
    late: shown.filter((i) => i.status === "late").reduce((s, i) => s + (i.total - i.paid), 0),
  }), [shown]);

  const vat = Math.round(Number(form.subtotal || 0) * 0.005 * 100) / 100;
  const grand = Number(form.subtotal || 0) + vat;

  const save = () => {
    if (!form.party.trim() || !form.subtotal) { notify("الطرف والمبلغ مطلوبان", "warn"); return; }
    const sub = Number(form.subtotal);
    setInvoices((is) => [
      {
        id: `i${Date.now()}`,
        no: `${form.type === "sale" ? "INV" : form.type === "purchase" ? "PUR" : form.type === "quote" ? "QT" : "RET"}-${3000 + is.length}`,
        type: form.type, party: form.party, date: todayISO(), due: form.due,
        subtotal: sub, vat, total: sub + vat, paid: 0,
        status: form.type === "quote" ? "draft" : "open",
      },
      ...is,
    ]);
    notify(`تم إنشاء ${TRANSFER_TYPE_LABEL[form.type]} بنجاح`);
    setModal(false);
    setForm({ type: "sale", party: "", subtotal: "", due: todayISO() });
  };

  const markPaid = (inv: Invoice) => {
    setInvoices((is) => is.map((i) => (i.id === inv.id ? { ...i, paid: i.total, status: "paid" as const } : i)));
    notify(`تم اعتماد تسوية الحوالة ${inv.no}`);
    setViewing(null);
  };

  const thSort = (key: SortKey, label: string) => (
    <th>
      <button className="flex items-center gap-1 font-inherit" onClick={() => setSort((s) => ({ key, dir: s.key === key ? ((s.dir * -1) as 1 | -1) : -1 }))}>
        {label} <ArrowDownUp size={11} className={sort.key === key ? "text-[var(--gold)]" : "opacity-40"} />
      </button>
    </th>
  );

  const csv = [
    ["الرقم", "النوع", "الطرف", "التاريخ", "الاستحقاق", "الإجمالي", "المدفوع", "الحالة"],
    ...shown.map((i) => [i.no, TRANSFER_TYPE_LABEL[i.type], i.party, i.date, i.due, i.total, i.paid, INVOICE_STATUS_LABEL[i.status]]),
  ];

  return (
    <div>
      <SectionHead
        title="الحوالات المالية"
        sub="إدارة الحوالات الصادرة والواردة، الرسوم، حالات التسليم والتسوية"
        actions={
          <>
            <ExportBar name="الحوالات-المالية" rows={csv} />
            <button onClick={() => setModal(true)} className="btn-gold flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-black">
              <FilePlus2 size={15} /> حوالة جديدة
            </button>
          </>
        }
      />

      {/* مؤشرات سريعة */}
      <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
        {[
          { l: "إجمالي المعروض", v: totals.all, c: "var(--gold-bright)" },
          { l: "المحصّل / المسدّد", v: totals.paid, c: "var(--green)" },
          { l: "مبالغ متأخرة", v: totals.late, c: "var(--red)" },
        ].map((x) => (
          <div key={x.l} className="glass rounded-2xl px-4 py-3">
            <p className="text-[10px] font-bold text-[var(--muted)]">{x.l}</p>
            <p className="num mt-0.5 font-display text-lg font-black md:text-xl" style={{ color: x.c }}>{SAR(x.v)}</p>
          </div>
        ))}
      </div>

      <Glass className="overflow-hidden rounded-[20px]">
        {/* التبويبات والفلاتر */}
        <div className="flex flex-wrap items-center gap-3 border-b border-[var(--border)] px-5 py-3.5">
          <div className="no-print flex max-w-full gap-1 overflow-x-auto rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1">
            {TABS.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)} className={`whitespace-nowrap rounded-lg px-3.5 py-1.5 text-[11px] font-black transition-all ${tab === t.id ? "bg-gradient-to-l from-[var(--gold-bright)] to-[var(--gold)] text-[#171207]" : "text-[var(--muted)] hover:text-[var(--text)]"}`}>
                {t.label}
              </button>
            ))}
          </div>
          <select value={status} onChange={(e) => setStatus(e.target.value as typeof status)} className="field rounded-xl px-3 py-2 text-xs">
            <option value="all">كل الحالات</option>
            {Object.entries(INVOICE_STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث برقم الحوالة أو الطرف…" className="field w-full sm:max-w-[220px] rounded-xl px-3.5 py-2 text-xs" />
          <p className="ms-auto text-[11px] font-bold text-[var(--muted)]"><ReceiptText size={13} className="inline text-[var(--gold)]" /> {NUM(shown.length)} مستنداً</p>
        </div>

        <div className="max-h-[58vh] overflow-auto">
          <table className="lux-table">
            <thead>
              <tr>
                {thSort("no", "الرقم")}<th>النوع</th><th>الطرف</th>{thSort("date", "التاريخ")}<th>الاستحقاق</th>{thSort("total", "الإجمالي")}<th>المدفوع</th><th>الحالة</th><th />
              </tr>
            </thead>
            <tbody>
              {shown.map((i) => (
                <tr key={i.id}>
                  <td className="num font-black text-[var(--gold-bright)]">{i.no}</td>
                  <td className="text-[var(--muted)]">{TRANSFER_TYPE_LABEL[i.type]}</td>
                  <td className="max-w-[200px] truncate font-bold">{i.party}</td>
                  <td className="num text-[var(--muted)]">{DATE(i.date)}</td>
                  <td className="num text-[var(--muted)]">{DATE(i.due)}</td>
                  <td className="num font-black">{SAR(i.total)}</td>
                  <td className="num text-[var(--muted)]">{SAR(i.paid)}</td>
                  <td><Chip label={INVOICE_STATUS_LABEL[i.status]} cls={INVOICE_STATUS_CHIP[i.status]} /></td>
                  <td className="no-print">
                    <button onClick={() => setViewing(i)} className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--sky)] hover:bg-[var(--sky-soft)]" title="عرض">
                      <Eye size={14} />
                    </button>
                  </td>
                </tr>
              ))}
              {shown.length === 0 && <tr><td colSpan={9} className="py-10 text-center text-sm text-[var(--muted)]">لا توجد حوالات مطابقة</td></tr>}
            </tbody>
          </table>
        </div>
      </Glass>

      {/* مودال حوالة جديدة */}
      <Modal open={modal} onClose={() => setModal(false)} title="إنشاء حوالة مالية" onSubmit={save}>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <L label="نوع الحوالة">
            <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as InvoiceType })}>
              <option value="sale">حوالة صادرة</option>
              <option value="purchase">حوالة واردة</option>
              <option value="saleReturn">حوالة مسترجعة</option>
              <option value="purchaseReturn">حوالة معكوسة</option>
              <option value="quote">حوالة أولية</option>
            </select>
          </L>
          <L label="تاريخ الاستحقاق"><input type="date" className={inputCls} value={form.due} onChange={(e) => setForm({ ...form, due: e.target.value })} enterKeyHint="next" /></L>
          <L label={form.type === "purchase" || form.type === "purchaseReturn" ? "الوكيل / الجهة المرسلة" : "العميل / المستفيد"} className="col-span-2">
            <input className={inputCls} value={form.party} onChange={(e) => setForm({ ...form, party: e.target.value })} placeholder="اسم الطرف…" enterKeyHint="next" />
          </L>
          <L label="مبلغ الحوالة" className="sm:col-span-2">
            <input type="number" min={0} className={`${inputCls} num`} value={form.subtotal} onChange={(e) => setForm({ ...form, subtotal: e.target.value })} placeholder="0" enterKeyHint="go" />
          </L>
        </div>
        <div className="mt-4 space-y-2 rounded-xl border border-[var(--border-gold)] bg-[var(--gold-dim)] p-4 text-sm">
          <p className="flex justify-between font-bold"><span className="text-[var(--muted)]">رسوم الخدمة 0.5%</span><span className="num">{SAR(vat)}</span></p>
          <p className="flex justify-between font-black"><span>الإجمالي المستحق</span><span className="num text-[var(--gold-bright)]">{SAR(grand)}</span></p>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={() => setModal(false)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">إلغاء</button>
          <button onClick={save} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">حفظ المستند</button>
        </div>
      </Modal>

      {/* مودال عرض الحوالة */}
      <Modal open={!!viewing} onClose={() => setViewing(null)} title={`مستند ${viewing?.no ?? ""}`}>
        {viewing && (
          <div>
            <div className="mb-4 flex items-center justify-between">
              <Chip label={TRANSFER_TYPE_LABEL[viewing.type]} cls="chip-gold" />
              <Chip label={INVOICE_STATUS_LABEL[viewing.status]} cls={INVOICE_STATUS_CHIP[viewing.status]} />
            </div>
            <div className="space-y-2.5 rounded-xl border border-[var(--border)] p-4 text-sm">
              <p className="flex justify-between"><span className="text-[var(--muted)]">الطرف</span><span className="font-black">{viewing.party}</span></p>
              <p className="flex justify-between"><span className="text-[var(--muted)]">تاريخ الإصدار</span><span className="num font-bold">{DATE(viewing.date)}</span></p>
              <p className="flex justify-between"><span className="text-[var(--muted)]">تاريخ الاستحقاق</span><span className="num font-bold">{DATE(viewing.due)}</span></p>
              <div className="border-t border-dashed border-[var(--border)] pt-2.5">
                <p className="flex justify-between font-bold"><span className="text-[var(--muted)]">مبلغ الحوالة</span><span className="num">{SAR(viewing.subtotal)}</span></p>
                <p className="mt-1.5 flex justify-between font-bold"><span className="text-[var(--muted)]">رسوم الخدمة</span><span className="num">{SAR(viewing.vat)}</span></p>
                <p className="mt-1.5 flex justify-between font-black"><span>الإجمالي</span><span className="num text-[var(--gold-bright)]">{SAR(viewing.total)}</span></p>
                <p className="mt-1.5 flex justify-between font-black"><span>المدفوع</span><span className="num text-[var(--green)]">{SAR(viewing.paid)}</span></p>
              </div>
            </div>
            <div className="mt-5 flex justify-between gap-2">
              <button onClick={() => window.print()} className="btn-ghost flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-bold"><Printer size={14} /> طباعة</button>
              {viewing.status !== "paid" && viewing.type !== "quote" && (
                <button onClick={() => markPaid(viewing)} className="btn-gold rounded-xl px-6 py-2.5 text-xs font-black">اعتماد وتسوية الحوالة</button>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
