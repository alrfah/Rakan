import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertCircle, CheckCircle2, Clock, Info, Lock, LogOut, MessageCircle, ShieldCheck, TriangleAlert } from "lucide-react";
import { onAuthStateChanged, signOut, type User } from "firebase/auth";
import { get, ref, update } from "firebase/database";
import { BottomNav, LoadBar, Sidebar, Topbar, type SectionId } from "./components/Shell";
import Dashboard, { AnalyticsPanel } from "./components/Dashboard";
import Journal from "./components/Journal";
import Invoices from "./components/Invoices";
import Partners from "./components/Partners";
import Cutting from "./components/Cutting";
import Treasury, { type TreasuryTab } from "./components/Treasury";
import Reports from "./components/Reports";
import TrashBin from "./components/TrashBin";
import { Login, Settings } from "./components/System";
import AdminPanel from "./components/AdminPanel";
import { AppProvider, BrandLogo, type NotifyKind } from "./components/ui";
import type { TeamUser } from "./data/mock";
import { auth, ADMIN_WHATSAPP, checkSubscriptionServer, db, isAdminAuth } from "./lib/firebase";
import type { UserProfile } from "./types/firebase";

interface Toast { id: number; msg: string; kind: NotifyKind }

/* ============ شاشة خطأ الوصول (انتهاء / حظر / غير مفعّل) ============ */
function AccessErrorScreen({ type, onLogout }: { type: string; onLogout: () => void }) {
  const WHATSAPP_URL = `https://wa.me/${ADMIN_WHATSAPP.replace(/^0/, "963")}`;

  const config = {
    expired: {
      icon: <Clock size={36} className="text-[var(--gold)]" />,
      bg: "border-[var(--border-gold)] bg-[var(--gold-dim)]",
      title: "انتهت صلاحية اشتراكك",
      body: "لقد انتهت مدة اشتراكك في نظام الرفاه. يُرجى التواصل مع الإدارة لتجديد الاشتراك والاستمرار في الاستخدام.",
    },
    blocked: {
      icon: <Lock size={36} className="text-[var(--red)]" />,
      bg: "border-[var(--red)] bg-[var(--red-soft)]",
      title: "تم تعليق الحساب",
      body: "تم إيقاف حسابك من قِبل الإدارة. تواصل معنا لمعرفة السبب وإعادة التفعيل.",
    },
    inactive: {
      icon: <AlertCircle size={36} className="text-[var(--muted)]" />,
      bg: "border-[var(--border)] bg-[var(--surface)]",
      title: "الحساب غير مفعّل",
      body: "لم يُفعَّل حسابك بعد. تواصل مع الإدارة لاستكمال إعداد حسابك.",
    },
    missing: {
      icon: <Info size={36} className="text-[var(--sky)]" />,
      bg: "border-[var(--border)] bg-[var(--surface)]",
      title: "لا يوجد ملف مستخدم",
      body: "لم يُعثر على بيانات حسابك في النظام. تواصل مع الإدارة لإنشاء ملف مستخدم.",
    },
  }[type] ?? {
    icon: <TriangleAlert size={36} className="text-[var(--red)]" />,
    bg: "border-[var(--red)] bg-[var(--red-soft)]",
    title: "خطأ في الوصول",
    body: "تواصل مع الإدارة.",
  };

  return (
    <div className="relative z-10 flex min-h-screen items-center justify-center p-4">
      <div className={`glass w-full max-w-sm rounded-[24px] border p-8 text-center shadow-[0_30px_70px_rgba(0,0,0,0.5)] ${config.bg}`}>
        {/* أيقونة */}
        <span className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-[var(--surface)]">
          {config.icon}
        </span>
        <h1 className="font-display text-xl font-black">{config.title}</h1>
        <p className="mt-2 text-sm font-bold leading-6 text-[var(--muted)]">{config.body}</p>

        {/* زر واتساب الإدارة */}
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-6 flex w-full items-center justify-center gap-2.5 rounded-xl bg-[#25D366] py-3.5 text-sm font-black text-white shadow-[0_8px_24px_rgba(37,211,102,0.4)] transition-all hover:brightness-105 active:scale-98"
        >
          <MessageCircle size={18} />
          <span>تواصل مع الإدارة عبر واتساب</span>
        </a>
        <p className="mt-1.5 text-[11px] font-bold text-[var(--muted)]" dir="ltr">{ADMIN_WHATSAPP}</p>

        {/* تسجيل الخروج */}
        <button
          onClick={onLogout}
          className="btn-ghost mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-bold"
        >
          <LogOut size={13} /> تسجيل الخروج
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [accessError, setAccessError] = useState<{ type: "blocked" | "expired" | "inactive" | "missing"; daysLeft?: number } | null>(null);
  const [tenantUid, setTenantUid] = useState<string>();
  const [tenantProfile, setTenantProfile] = useState<UserProfile | null>(null);
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    try {
      const saved = localStorage.getItem("diwan-theme");
      return saved === "light" ? "light" : "dark";
    } catch {
      return "dark";
    }
  });
  const [section, setSection] = useState<SectionId>("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [navKey, setNavKey] = useState(0);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem("diwan-theme", theme);
    } catch {
      /* ignore */
    }
  }, [theme]);

  useEffect(() => onAuthStateChanged(auth, async (firebaseUser) => {
    setAuthLoading(true);
    setAccessError(null);
    setTenantUid(undefined);
    setTenantProfile(null);
    if (!firebaseUser) {
      setAuthUser(null); setProfile(null); setAuthLoading(false); return;
    }
    setAuthUser(firebaseUser);
    if (isAdminAuth(firebaseUser)) {
      setProfile({ name: "المشرف العام", email: firebaseUser.email ?? "", phone: "", role: "admin", status: "active", subscriptionEnd: "2099-12-31", createdAt: Date.now() });
      setAuthLoading(false);
      return;
    }
    try {
      // 1) جرّب قراءة الملف الشخصي المباشر
      let snap = await get(ref(db, `users/${firebaseUser.uid}/profile`));
      // 2) إذا لم يوجد فهو حساب فرعي - ابحث في team_members
      if (!snap.exists()) {
        const memberSnap = await get(ref(db, `team_members/${firebaseUser.uid}`));
        if (memberSnap.exists()) {
          snap = { exists: () => true, val: () => memberSnap.val() } as any;
        }
      }
      // 3) خطة بديلة: ابحث في team_index عبر البريد الإلكتروني
      if (!snap.exists() && firebaseUser.email) {
        const emailKey = firebaseUser.email.toLowerCase().replace(/[.#$\[\]/]/g, "_");
        const indexSnap = await get(ref(db, `team_index/${emailKey}`));
        if (indexSnap.exists()) {
          const indexData = indexSnap.val() as { subUid: string; parentUid: string };
          if (indexData?.subUid) {
            const memberSnap = await get(ref(db, `team_members/${indexData.subUid}`));
            if (memberSnap.exists()) {
              snap = { exists: () => true, val: () => memberSnap.val() } as any;
            }
          }
        }
      }
      // 4) خطة احتياطية أخيرة: ابحث في جميع مسارات team للمستخدمين
      if (!snap.exists()) {
        const allUsers = await get(ref(db, "users"));
        if (allUsers.exists()) {
          for (const [, ownerData] of Object.entries(allUsers.val() as Record<string, any>)) {
            const teamNode = ownerData?.team?.[firebaseUser.uid];
            if (teamNode?.profile) {
              snap = { exists: () => true, val: () => teamNode.profile } as any;
              break;
            }
          }
        }
      }
      if (!snap.exists()) throw new Error("missing-profile");
      const loaded = snap.val() as UserProfile;
      if (loaded.status === "blocked") {
        setAccessError({ type: "blocked" });
        return;
      }
      if (loaded.status !== "active") {
        setAccessError({ type: "inactive" });
        return;
      }
      // فحص انتهاء الاشتراك من وقت خادم Firebase (منع التلاعب)
      const { expired, daysLeft } = await checkSubscriptionServer(loaded.subscriptionEnd ?? "2000-01-01");
      if (expired) {
        setAccessError({ type: "expired", daysLeft: 0 });
        return;
      }
      setProfile(loaded);
      setTenantUid(firebaseUser.uid);
      void update(ref(db, `users/${firebaseUser.uid}/settings/activity`), { lastLoginAt: Date.now() });
      void get(ref(db, `users/${firebaseUser.uid}/settings/theme`)).then((s) => {
        if (s.exists() && (s.val() === "dark" || s.val() === "light")) setTheme(s.val());
      }).catch(() => undefined);
      // تحذير مبكر إذا كان الاشتراك ينتهي خلال 7 أيام
      if (daysLeft <= 7 && daysLeft > 0) {
        setTimeout(() => {
          // يُعرض كإشعار لاحقاً بعد تهيئة الـ context
        }, 2500);
      }
    } catch {
      setAccessError({ type: "missing" });
    } finally {
      setAuthLoading(false);
    }
  }), []);

  const user = useMemo<TeamUser | null>(() => {
    const p = tenantProfile ?? profile;
    const uid = tenantUid ?? authUser?.uid;
    if (!p || !uid) return null;
    return { id: uid, name: p.name, role: p.role, active: p.status === "active", last: "الآن" };
  }, [authUser, profile, tenantProfile, tenantUid]);

  const notify = useCallback((msg: string, kind: NotifyKind = "success") => {
    const id = Date.now() + Math.random();
    setToasts((ts) => [...ts.slice(-2), { id, msg, kind }]);
    setTimeout(() => setToasts((ts) => ts.filter((t) => t.id !== id)), 3200);
  }, []);

  const go = useCallback((s: SectionId, pushHistory = true) => {
    setSection(s);
    setNavKey((k) => k + 1);
    if (pushHistory && typeof window !== "undefined") {
      try {
        window.history.pushState({ section: s }, "", `#${s}`);
      } catch {
        /* ignore */
      }
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.history.replaceState({ section: "dashboard" }, "", "#dashboard");
    } catch {
      /* ignore */
    }

    const handlePopState = (e: PopStateEvent) => {
      setMobileNav(false);
      const state = e.state as { section?: SectionId } | null;
      if (state && state.section) {
        setSection(state.section);
        setNavKey((k) => k + 1);
      } else {
        setSection("dashboard");
        setNavKey((k) => k + 1);
      }
    };
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  const treasuryMap: Partial<Record<SectionId, TreasuryTab>> = {
    cash: "cash", banks: "banks", debts: "debts", opening: "opening", exin: "exin",
  };

  return (
      <AppProvider value={{ notify, user, tenantUid }}>
      <div className="relative min-h-screen">
        <div className="ambient" aria-hidden="true" />

        {authLoading ? (
          <div className="relative z-10 flex min-h-screen flex-col items-center justify-center gap-7 px-6">
            {/* هالة التوهج خلف الشعار */}
            <div className="relative flex items-center justify-center">
              <span
                className="absolute h-36 w-36 rounded-full blur-3xl md:h-44 md:w-44"
                style={{ background: "radial-gradient(circle, rgba(91,134,246,0.55), rgba(143,123,247,0.25) 55%, transparent 75%)", animation: "splashGlow 2.6s ease-in-out infinite" }}
              />
              <div style={{ animation: "splashFloat 3s ease-in-out infinite" }}>
                <BrandLogo className="relative h-24 w-24 drop-shadow-[0_20px_42px_rgba(56,120,246,0.5)] md:h-32 md:w-32" />
              </div>
            </div>
            {/* شريط التحميل أسفل الشعار */}
            <div className="w-full max-w-[220px]">
              <div className="relative h-1.5 overflow-hidden rounded-full bg-[var(--surface-2)]">
                <span className="splash-bar absolute top-0 h-full w-2/5 rounded-full bg-gradient-to-l from-[#8f7bf7] to-[#2e8cf6]" />
              </div>
            </div>
          </div>
        ) : !authUser ? (
          <Login />
        ) : accessError ? (
          <AccessErrorScreen type={accessError.type} onLogout={() => void signOut(auth)} />
        ) : isAdminAuth(authUser) && !tenantUid ? (
          <div className="relative z-10 min-h-screen px-4 py-7 md:px-8"><div className="mx-auto mb-6 flex max-w-7xl items-center justify-between"><p className="flex items-center gap-2 font-display text-lg font-black"><ShieldCheck className="text-[var(--gold)]" /> لوحة المشرف العام</p><button onClick={() => void signOut(auth)} className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-black"><LogOut size={14} /> خروج</button></div><div className="mx-auto max-w-7xl"><AdminPanel onOpenTenant={(uid, p) => { setTenantUid(uid); setTenantProfile(p); setSection("dashboard"); }} /></div></div>
        ) : user ? (
          <div className="relative z-10 flex">
            <Sidebar
              section={section}
              go={go}
              collapsed={collapsed}
              onCollapse={() => setCollapsed((c) => !c)}
              mobileOpen={mobileNav}
              onMobileClose={() => setMobileNav(false)}
              user={user}
              onLogout={() => void signOut(auth)}
              notify={notify}
            />
            <BottomNav
              section={section}
              go={go}
              user={user}
              onOpenMenu={() => setMobileNav(true)}
            />

            <div className="flex min-w-0 flex-1 flex-col">
              <LoadBar k={navKey} />
              <Topbar
                onMenu={() => setMobileNav(true)}
                theme={theme}
                onTheme={() => {
                  setTheme((t) => {
                    const next = t === "dark" ? "light" : "dark";
                    if (authUser?.uid && !isAdminAuth(authUser)) {
                      void update(ref(db, `users/${authUser.uid}/settings`), { theme: next }).catch(() => undefined);
                    }
                    return next;
                  });
                }}
                user={user}
                onLogout={() => void signOut(auth)}
                go={go}
              />

              <main className="flex-1 px-4 py-6 pb-20 md:px-7 md:py-8 lg:pb-8">
                {isAdminAuth(authUser) && tenantUid && (
                  <button onClick={() => { setTenantUid(undefined); setTenantProfile(null); }} className="no-print btn-gold mb-5 flex items-center gap-2 rounded-xl px-4 py-2 text-xs"><ShieldCheck size={14} /> العودة إلى لوحة المشرف العام</button>
                )}
                <AnimatePresence mode="wait">
                  <motion.div
                    key={section}
                    initial={{ opacity: 0, y: 14 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.28, ease: [0.2, 0.8, 0.3, 1] }}
                  >
                    {section === "dashboard" && <Dashboard go={go} />}
                    {section === "analytics" && <AnalyticsPanel go={go} />}
                    {section === "journal" && <Journal />}
                    {section === "invoices" && <Invoices />}
                    {(section === "customers" || section === "suppliers") && (
                      <Partners key={section} kind={section === "customers" ? "customer" : "supplier"} />
                    )}
                    {section === "cutting" && <Cutting />}
                    {treasuryMap[section] && <Treasury tab={treasuryMap[section]!} />}
                    {section === "reports" && <Reports />}
                    {section === "trash" && <TrashBin />}
                    {section === "settings" && <Settings currentUser={user} />}
                  </motion.div>
                </AnimatePresence>

                <footer className="no-print mt-10 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--border)] pt-5 text-[11px] font-bold text-[var(--faint)]">
                  <p>الرفاه · النظام المالي للحوالات — تل أبيض، الرقة، سوريا</p>
                  <p>العملة الأساسية: الليرة السورية · تخزين لحظي في Firebase</p>
                </footer>
              </main>
            </div>
          </div>
        ) : null}

        {/* التوستات */}
        <div className="pointer-events-none fixed bottom-5 left-1/2 z-[70] flex w-full max-w-sm -translate-x-1/2 flex-col items-center gap-2 px-4">
          <AnimatePresence>
            {toasts.map((t) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 24, scale: 0.92 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 12, scale: 0.95 }}
                transition={{ type: "spring", stiffness: 420, damping: 30 }}
                className="glass pointer-events-auto flex w-full items-center gap-2.5 rounded-2xl border-[var(--border-gold)] px-4 py-3"
              >
                {t.kind === "success" && <CheckCircle2 size={17} className="shrink-0 text-[var(--green)]" />}
                {t.kind === "info" && <Info size={17} className="shrink-0 text-[var(--sky)]" />}
                {t.kind === "warn" && <TriangleAlert size={17} className="shrink-0 text-[var(--red)]" />}
                <p className="text-xs font-black leading-5">{t.msg}</p>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </AppProvider>
  );
}
