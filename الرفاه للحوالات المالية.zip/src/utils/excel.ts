import * as XLSX from "xlsx";

const EXCEL_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

/** حساب عرض الأعمدة تلقائياً */
function colWidths(rows: (string | number)[][]): XLSX.ColInfo[] {
  const count = (rows[0] ?? []).length;
  return Array.from({ length: count }, (_, i) => ({
    wch: Math.min(45, Math.max(10, ...rows.map((r) => String(r[i] ?? "").length + 2))),
  }));
}

/** تنسيق صف الترويسة (خلفية ذهبية وخط عريض) */
function styleHeader(ws: XLSX.WorkSheet, cols: number) {
  for (let c = 0; c < cols; c++) {
    const addr = XLSX.utils.encode_cell({ r: 0, c });
    if (!ws[addr]) continue;
    ws[addr].s = {
      font: { bold: true, color: { rgb: "171207" }, sz: 11 },
      fill: { fgColor: { rgb: "C5A069" }, patternType: "solid" },
      alignment: { horizontal: "center", vertical: "center", wrapText: true },
      border: {
        bottom: { style: "thin", color: { rgb: "8B6A30" } },
      },
    };
  }
}

/**
 * يبني ملف Excel حقيقي من أي مصفوفة صفوف ويُطلق تنزيله فوراً عبر Blob
 * بحيث يفتحه المتصفح/النظام مباشرةً في تطبيق Excel أو Numbers أو Calc.
 */
export function downloadExcel(
  rows: (string | number)[][],
  filename: string,
  sheetName = "التقرير"
) {
  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws["!cols"] = colWidths(rows);
  ws["!freeze"] = { xSplit: 0, ySplit: 1 } as never;
  styleHeader(ws, (rows[0] ?? []).length);

  const wb = XLSX.utils.book_new();
  wb.Workbook = { Views: [{ RTL: true }] };
  XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));

  _triggerDownload(wb, filename);
}

/**
 * يبني مصنف Excel بعدة أوراق عمل ويُطلق تنزيله فوراً.
 */
export function downloadExcelSheets(
  sheets: { name: string; rows: (string | number)[][] }[],
  filename: string
) {
  const wb = XLSX.utils.book_new();
  wb.Workbook = { Views: [{ RTL: true }] };

  for (const sheet of sheets) {
    const ws = XLSX.utils.aoa_to_sheet(sheet.rows);
    ws["!cols"] = colWidths(sheet.rows);
    ws["!freeze"] = { xSplit: 0, ySplit: 1 } as never;
    styleHeader(ws, (sheet.rows[0] ?? []).length);
    XLSX.utils.book_append_sheet(wb, ws, sheet.name.slice(0, 31));
  }

  _triggerDownload(wb, filename);
}

/** تُنزّل المصنف كـ Blob بـ MIME الصحيح حتى يُفتح مباشرةً في تطبيق Excel */
function _triggerDownload(wb: XLSX.WorkBook, filename: string) {
  const name = filename.endsWith(".xlsx") ? filename : `${filename}.xlsx`;

  // 1) File System Access API (Chrome / Edge ≥ 86) — يفتح مربع حوار الحفظ الأصيل
  if (typeof window !== "undefined" && "showSaveFilePicker" in window) {
    void (async () => {
      try {
        const handle = await (
          window as Window & { showSaveFilePicker: (opts: object) => Promise<FileSystemFileHandle> }
        ).showSaveFilePicker({
          suggestedName: name,
          types: [
            {
              description: "Excel Workbook (.xlsx)",
              accept: { [EXCEL_MIME]: [".xlsx"] },
            },
          ],
        });
        const raw = XLSX.write(wb, { bookType: "xlsx", type: "buffer" }) as Uint8Array;
        const buf = new Uint8Array(raw); // ضمان ArrayBuffer خالص
        const writable = await handle.createWritable();
        await writable.write(buf.buffer);
        await writable.close();
        return;
      } catch {
        // المستخدم ألغى المربع أو المتصفح لا يدعمه → نعود للتنزيل العادي
      }
      _blobDownload(wb, name);
    })();
    return;
  }

  // 2) Blob + رابط مؤقت — كل المتصفحات
  _blobDownload(wb, name);
}

function _blobDownload(wb: XLSX.WorkBook, name: string) {
  const buf = XLSX.write(wb, { bookType: "xlsx", type: "array" }) as ArrayBuffer;
  const blob = new Blob([buf], { type: EXCEL_MIME });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.type = EXCEL_MIME;
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 6000);
}
