import { useRef, useState } from "react";
import { NUM, SAR } from "../utils/format";

interface FlowPoint { label: string; in: number; out: number }

const W = 620;
const H = 232;
const PT = 14, PB = 30, PX = 14;

const compact = (n: number) =>
  n >= 1000000 ? `${NUM(Math.round(n / 100000) / 10)} مليون` : n >= 1000 ? `${NUM(Math.round(n / 1000))} ألف` : NUM(n);

/* منحنى ناعم عبر نقاط */
function smoothPath(pts: [number, number][]) {
  if (pts.length < 2) return "";
  let d = `M ${pts[0][0]},${pts[0][1]}`;
  for (let i = 1; i < pts.length; i++) {
    const cx = (pts[i - 1][0] + pts[i][0]) / 2;
    d += ` C ${cx},${pts[i - 1][1]} ${cx},${pts[i][1]} ${pts[i][0]},${pts[i][1]}`;
  }
  return d;
}

/**
 * مخطط تدفق ثنائي (داخل/خارج) بمساحات ناعمة، شبكة، وتلميح تفاعلي عند التحويم.
 */
export function FlowChart({ data, aLabel = "الداخل", bLabel = "الخارج" }: { data: FlowPoint[]; aLabel?: string; bLabel?: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const box = useRef<HTMLDivElement>(null);
  const n = data.length;
  const max = Math.max(1, ...data.map((d) => Math.max(d.in, d.out))) * 1.18;
  const x = (i: number) => PX + (i * (W - 2 * PX)) / (n - 1);
  const y = (v: number) => H - PB - (v / max) * (H - PB - PT);

  const aPts = data.map((d, i) => [x(i), y(d.in)] as [number, number]);
  const bPts = data.map((d, i) => [x(i), y(d.out)] as [number, number]);
  const aLine = smoothPath(aPts);
  const bLine = smoothPath(bPts);
  const aArea = `${aLine} L ${x(n - 1)},${H - PB} L ${x(0)},${H - PB} Z`;

  const onMove = (e: React.MouseEvent) => {
    const r = box.current?.getBoundingClientRect();
    if (!r) return;
    const px = ((e.clientX - r.left) / r.width) * W;
    const i = Math.round((px - PX) / ((W - 2 * PX) / (n - 1)));
    setHover(Math.min(Math.max(i, 0), n - 1));
  };

  return (
    <div ref={box} className="relative" onMouseMove={onMove} onMouseLeave={() => setHover(null)}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={`مخطط ${aLabel} و${bLabel}`}>
        <defs>
          <linearGradient id="gIn" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#c5a069" stopOpacity="0.38" />
            <stop offset="1" stopColor="#c5a069" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="gOut" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#5b8bb5" stopOpacity="0.2" />
            <stop offset="1" stopColor="#5b8bb5" stopOpacity="0" />
          </linearGradient>
        </defs>
        {/* الشبكة */}
        {[0.25, 0.5, 0.75, 1].map((f) => (
          <g key={f}>
            <line x1={PX} x2={W - PX} y1={y(max * f)} y2={y(max * f)} stroke="var(--border)" strokeDasharray="3 6" />
            <text x={W - PX} y={y(max * f) - 5} textAnchor="end" fontSize="9.5" fill="var(--faint)" className="num">
              {compact(max * f)}
            </text>
          </g>
        ))}
        <path d={aArea} fill="url(#gIn)" />
        <path d={bLine} fill="none" stroke="#5b8bb5" strokeWidth="2.2" strokeDasharray="5 4" opacity="0.85" />
        <path d={aLine} fill="none" stroke="#c5a069" strokeWidth="2.6" />
        {/* تسميات المحور */}
        {data.map((d, i) => (
          <text key={i} x={x(i)} y={H - 9} textAnchor="middle" fontSize="10" fill="var(--muted)" fontFamily="Tajawal">
            {d.label}
          </text>
        ))}
        {/* خط التحويم */}
        {hover !== null && (
          <g>
            <line x1={x(hover)} x2={x(hover)} y1={PT} y2={H - PB} stroke="var(--gold)" strokeOpacity="0.4" />
            <circle cx={x(hover)} cy={y(data[hover].in)} r="5" fill="#c5a069" stroke="var(--bg)" strokeWidth="2" />
            <circle cx={x(hover)} cy={y(data[hover].out)} r="5" fill="#5b8bb5" stroke="var(--bg)" strokeWidth="2" />
          </g>
        )}
      </svg>
      {/* التلميح */}
      {hover !== null && (
        <div
          className="glass pointer-events-none absolute z-10 min-w-[150px] rounded-xl px-3.5 py-2.5 text-xs"
          style={{ left: `${(x(hover) / W) * 100}%`, top: 0, transform: "translate(-50%, -8%)" }}
        >
          <p className="mb-1.5 font-bold text-[var(--muted)]">{data[hover].label}</p>
          <p className="flex items-center gap-2 font-bold">
            <span className="h-2 w-2 rounded-full bg-[#c5a069]" /> {aLabel}:
            <span className="num">{SAR(data[hover].in)}</span>
          </p>
          <p className="mt-1 flex items-center gap-2 font-bold">
            <span className="h-2 w-2 rounded-full bg-[#5b8bb5]" /> {bLabel}:
            <span className="num">{SAR(data[hover].out)}</span>
          </p>
        </div>
      )}
    </div>
  );
}

/** أعمدة مقارنة شهرية (إيرادات/مصروفات) */
export function BarsChart({ data, aLabel = "إيرادات", bLabel = "مصروفات" }: { data: FlowPoint[]; aLabel?: string; bLabel?: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const box = useRef<HTMLDivElement>(null);
  const n = data.length;
  const max = Math.max(1, ...data.map((d) => Math.max(d.in, d.out))) * 1.15;
  const y = (v: number) => H - PB - (v / max) * (H - PB - PT);
  const groupW = (W - 2 * PX) / n;
  const bw = 11;

  return (
    <div ref={box} className="relative" onMouseLeave={() => setHover(null)}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="مخطط أعمدة شهري">
        {[0.33, 0.66, 1].map((f) => (
          <line key={f} x1={PX} x2={W - PX} y1={y(max * f)} y2={y(max * f)} stroke="var(--border)" strokeDasharray="3 6" />
        ))}
        {data.map((d, i) => {
          const cx = PX + groupW * i + groupW / 2;
          const dim = hover !== null && hover !== i;
          return (
            <g
              key={i}
              opacity={dim ? 0.35 : 1}
              style={{ transition: "opacity 0.25s" }}
              onMouseEnter={() => setHover(i)}
            >
              <rect x={PX + groupW * i} y={PT} width={groupW} height={H - PB - PT} fill="transparent" />
              <rect x={cx - bw - 1.5} y={y(d.in)} width={bw} height={H - PB - y(d.in)} rx="3.5" fill="#c5a069" />
              <rect x={cx + 1.5} y={y(d.out)} width={bw} height={H - PB - y(d.out)} rx="3.5" fill="var(--muted)" opacity="0.75" />
              <text x={cx} y={H - 9} textAnchor="middle" fontSize="9" fill="var(--muted)" fontFamily="Tajawal">
                {d.label.slice(0, 6)}
              </text>
            </g>
          );
        })}
      </svg>
      {hover !== null && (
        <div
          className="glass pointer-events-none absolute top-0 z-10 min-w-[150px] rounded-xl px-3.5 py-2.5 text-xs"
          style={{
            left: `${((PX + groupW * hover + groupW / 2) / W) * 100}%`,
            transform: "translate(-50%, -8%)",
          }}
        >
          <p className="mb-1.5 font-bold text-[var(--muted)]">{data[hover].label}</p>
          <p className="flex items-center gap-2 font-bold">
            <span className="h-2 w-2 rounded-sm bg-[#c5a069]" /> {aLabel}: <span className="num">{SAR(data[hover].in)}</span>
          </p>
          <p className="mt-1 flex items-center gap-2 font-bold">
            <span className="h-2 w-2 rounded-sm bg-[var(--muted)]" /> {bLabel}: <span className="num">{SAR(data[hover].out)}</span>
          </p>
          <p className="mt-1.5 border-t border-[var(--border)] pt-1.5 text-[11px] font-bold text-[var(--gold-bright)]">
            الصافي: <span className="num">{SAR(data[hover].in - data[hover].out)}</span>
          </p>
        </div>
      )}
      <div className="mt-2 flex items-center justify-center gap-5 text-[11px] font-bold text-[var(--muted)]">
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-[#c5a069]" /> {aLabel}</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-[var(--muted)]" /> {bLabel}</span>
      </div>
    </div>
  );
}

/** مخطط دائري (Donut) مع وسيلة إيضاح وتفاعل */
export function Donut({ data, center, centerLabel }: { data: { label: string; value: number; color: string }[]; center: string; centerLabel: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const total = data.reduce((s, d) => s + d.value, 0);
  const safeTotal = total || 1;
  const R = 74, C = 2 * Math.PI * R;
  let acc = 0;

  return (
    <div className="flex flex-col items-center gap-5 sm:flex-row sm:justify-center">
      <div className="relative">
        <svg viewBox="0 0 200 200" className="h-44 w-44 -rotate-90">
          <circle cx="100" cy="100" r={R} fill="none" stroke="var(--surface-2)" strokeWidth="24" />
          {data.map((d, i) => {
            const frac = d.value / safeTotal;
            const dash = `${frac * C - 3} ${C - frac * C + 3}`;
            const off = -acc * C;
            acc += frac;
            return (
              <circle
                key={i}
                cx="100" cy="100" r={R}
                fill="none"
                stroke={d.color}
                strokeWidth={hover === i ? 31 : 24}
                strokeDasharray={dash}
                strokeDashoffset={off}
                strokeLinecap="round"
                opacity={hover === null || hover === i ? 1 : 0.3}
                style={{ transition: "all 0.3s cubic-bezier(.2,.8,.3,1)", cursor: "pointer" }}
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(null)}
              />
            );
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="font-display text-xl font-extrabold num">{hover !== null ? `${Math.round((data[hover].value / safeTotal) * 100)}٪` : center}</span>
          <span className="text-[10px] font-bold text-[var(--muted)]">{hover !== null ? data[hover].label : centerLabel}</span>
        </div>
      </div>
      <ul className="flex w-full max-w-[190px] flex-col gap-2.5">
        {data.map((d, i) => (
          <li
            key={i}
            className={`flex cursor-pointer items-center justify-between gap-2 rounded-lg px-2 py-1 text-xs transition-colors ${hover === i ? "bg-[var(--gold-dim)]" : ""}`}
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
          >
            <span className="flex items-center gap-2 font-bold">
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: d.color }} />
              {d.label}
            </span>
            <span className="num font-bold text-[var(--muted)]">{compact(d.value)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
