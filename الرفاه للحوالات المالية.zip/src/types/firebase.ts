export type AccountStatus = "active" | "expired" | "blocked";

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  role: "admin" | "accountant" | "staff";
  status: AccountStatus;
  subscriptionEnd: string;
  createdAt: number;
  lastLoginAt?: number;
}

export interface AdminUserSummary extends UserProfile {
  uid: string;
  customersCount: number;
  entriesCount: number;
}
