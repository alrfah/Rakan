import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, CalendarClock, Coins, FileDown, FileSpreadsheet, MessageCircle, Pencil, Plus, Search, Share2, Trash2, Truck, UserRound, Users } from "lucide-react";
import { downloadExcelSheets } from "../utils/excel";
import { AR_LATN, DATE, NUM } from "../utils/format";
import { ConfirmDialog, EmptyState, Glass, L, Modal, PdfPreviewModal, SectionHead, inputCls, useApp } from "./ui";
import { useTenantState } from "../lib/tenant";

type OperationKind = "for" | "on";
interface CustomerOperation { id: string; at: string; currency: string; amount: number; kind: OperationKind; note: string }
interface LedgerCustomer { id: string; name: string; whatsapp: string; createdAt: string; updatedAt: string; operations: CustomerOperation[] }
type Pending =
  | { type: "customer-add"; data: { name: string; whatsapp: string } }
  | { type: "customer-edit"; id: string; data: { name: string; whatsapp: string } }
  | { type: "customer-delete"; customer: LedgerCustomer }
  | { type: "operation-add"; customerId: string; data: Omit<CustomerOperation, "id"> }
  | { type: "operation-edit"; customerId: string; operationId: string; data: Omit<CustomerOperation, "id"> }
  | { type: "operation-delete"; customerId: string; operation: CustomerOperation };

const EMPTY: LedgerCustomer[] = [];
const BASE_CURRENCIES = ["ليرة تركية", "دولار أمريكي", "يورو", "ليرة سورية"];
const fmt = (n: number) => new Intl.NumberFormat(AR_LATN, { maximumFractionDigits: 2 }).format(Math.abs(n));
const time = (iso: string) => new Date(iso).toLocaleTimeString(AR_LATN, { hour: "2-digit", minute: "2-digit" });
const latinize = (value: string) => value.replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));

type StoredCustomers = LedgerCustomer[] | Record<string, Partial<LedgerCustomer> & { phone?: string; transactions?: unknown[] }>;

/** يدعم مصفوفات Firebase والكائنات ذات المفاتيح، ويحوّل سجلات العملاء القديمة بأمان. */
function normalizeCustomers(value: StoredCustomers | null | undefined): LedgerCustomer[] {
  const source = Array.isArray(value)
    ? value.map((customer) => [customer?.id, customer] as const)
    : Object.entries(value ?? {});

  return source
    .filter(([, customer]) => customer && typeof customer === "object")
    .map(([key, customer], index) => {
      const now = new Date().toISOString();
      const record = customer as Partial<LedgerCustomer> & { phone?: string };
      return {
        id: String(record.id || key || `customer-${index}`),
        name: String(record.name || "عميل بدون اسم"),
        whatsapp: String(record.whatsapp || record.phone || ""),
        createdAt: record.createdAt || now,
        updatedAt: record.updatedAt || record.createdAt || now,
        operations: Array.isArray(record.operations) ? record.operations.filter(Boolean) : [],
      };
    });
}

function balancesOf(customer: LedgerCustomer) {
  const result = new Map<string, { for: number; on: number; net: number }>();
  for (const op of customer.operations ?? []) {
    const row = result.get(op.currency) ?? { for: 0, on: 0, net: 0 };
    op.kind === "for" ? row.for += op.amount : row.on += op.amount;
    row.net = row.for - row.on;
    result.set(op.currency, row);
  }
  return result;
}

function runningOperations(customer: LedgerCustomer) {
  const running = new Map<string, number>();
  return [...(customer.operations ?? [])].sort((a, b) => a.at.localeCompare(b.at)).map((op) => {
    const balance = (running.get(op.currency) ?? 0) + (op.kind === "for" ? op.amount : -op.amount);
    running.set(op.currency, balance);
    return { ...op, balance };
  });
}

function whatsappMessage(customer: LedgerCustomer) {
  const balances = balancesOf(customer);
  const lines = balances.size
    ? [...balances.entries()].map(([currency, b]) => b.net === 0 ? `*${currency}:* لا يوجد رصيد` : `*${currency}:* ${fmt(b.net)} *(${b.net > 0 ? "دائن لكم" : "دائن علينا"})*`)
    : ["لا يوجد رصيد."];
  return `*مكتب الرفاه*\n\n💵💵💵💵💵💵💵💵\n\n*الحساب:*\n*${customer.name}*\n*الرصيد:*\n${lines.join("\n\n")}\n\n💵💵💵💵💵💵💵💵\n\n💰💰💰💰💰💰💰💰\n\nيرجى مطابقة هذه الأرصدة.`;
}

function statementHtml(customer: LedgerCustomer) {
  const rows = runningOperations(customer);
  const balances = balancesOf(customer);
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>كشف حساب ${customer.name}</title><link href="https://fonts.googleapis.com/css2?family=Cairo:wght@500;700;900&display=swap" rel="stylesheet"><style>@page{size:A4;margin:13mm}*{box-sizing:border-box}body{font-family:Cairo,Tahoma;color:#171717;margin:0}.head{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #C5A069;padding-bottom:13px}.brand{display:flex;gap:12px;align-items:center}.mark{width:50px;height:50px;border-radius:13px;background:#111;color:#C5A069;display:grid;place-items:center;font-size:24px;font-weight:900}.brand b{font-size:21px}.meta{text-align:left;font-size:10px;color:#666}h1{text-align:center;font-size:20px;margin:18px 0 2px}h2{text-align:center;font-size:13px;color:#9a733d;margin:0}.date{text-align:center;font-size:10px;color:#777;margin:5px 0 16px}table{width:100%;border-collapse:collapse;font-size:10.5px}th{background:#C5A069;color:#111;padding:8px;border:1px solid #b38e59}td{padding:7px;border:1px solid #e5e0d7;text-align:center}tr:nth-child(even){background:#f7f5f1}.for{color:#19704c;font-weight:900}.on{color:#b23d36;font-weight:900}.balances{margin-top:15px;border:1px solid #C5A069;border-radius:10px;padding:12px}.balances p{display:flex;justify-content:space-between;font-size:11px}.foot{text-align:center;margin-top:20px;border-top:1px solid #eee;padding-top:8px;font-size:9px;color:#999}</style></head><body><div class="head"><div class="brand"><div class="mark">ر</div><div><b>شركة الرفاه</b><br><small>ALRAFAH COMPANY</small></div></div><div class="meta">كشف حساب رسمي<br>عدد العمليات: ${NUM(rows.length)}</div></div><h1>كشف حساب العميل: ${customer.name}</h1><h2>شركة الرفاه</h2><p class="date">تاريخ التقرير: ${new Date().toLocaleString("ar")}</p><table><thead><tr><th>#</th><th>التاريخ والوقت</th><th>العملة</th><th>المبلغ</th><th>لنا</th><th>علينا</th><th>الملاحظة</th><th>الرصيد</th></tr></thead><tbody>${rows.map((op, i) => `<tr><td>${NUM(i + 1)}</td><td>${DATE(op.at)}<br>${time(op.at)}</td><td>${op.currency}</td><td>${fmt(op.amount)}</td><td class="for">${op.kind === "for" ? fmt(op.amount) : "—"}</td><td class="on">${op.kind === "on" ? fmt(op.amount) : "—"}</td><td>${op.note || "—"}</td><td class="${op.balance >= 0 ? "for" : "on"}">${fmt(op.balance)} ${op.balance >= 0 ? "لنا" : "علينا"}</td></tr>`).join("")}</tbody></table><div class="balances"><b>الأرصدة النهائية</b>${balances.size ? [...balances.entries()].map(([c, b]) => `<p><b>${c}</b><span>${b.net === 0 ? "لا يوجد رصيد" : `${fmt(b.net)} — دائن ${b.net > 0 ? "لنا" : "علينا"}`}</span></p>`).join("") : "<p>لا يوجد رصيد</p>"}</div><p class="foot">إجمالي عدد العمليات: ${NUM(rows.length)} · نظام ديوان المحاسبي</p><script>window.onload=()=>setTimeout(()=>window.print(),400)</script></body></html>`;
}

function CustomerModule() {
  const { notify, tenantUid } = useApp();
  const [storedCustomers, setStoredCustomers] = useTenantState<StoredCustomers>(tenantUid, "customers", EMPTY);
  const customers = useMemo(() => normalizeCustomers(storedCustomers), [storedCustomers]);
  const setCustomers = (updater: (current: LedgerCustomer[]) => LedgerCustomer[]) => {
    setStoredCustomers((current) => updater(normalizeCustomers(current)));
  };
  const [currencies, setCurrencies] = useTenantState<string[]>(tenantUid, "settings/currencies", BASE_CURRENCIES);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [customerModal, setCustomerModal] = useState(false);
  const [operationModal, setOperationModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<LedgerCustomer | null>(null);
  const [editingOperation, setEditingOperation] = useState<CustomerOperation | null>(null);
  const [pending, setPending] = useState<Pending | null>(null);
  const [customerForm, setCustomerForm] = useState({ name: "", whatsapp: "" });
  const [opForm, setOpForm] = useState({ currency: BASE_CURRENCIES[0], custom: "", amount: "", kind: "for" as OperationKind, note: "", at: new Date().toISOString().slice(0, 16) });
  const selected = customers.find((c) => c.id === selectedId) ?? null;
  const shown = customers.filter((c) => !q || c.name.includes(q) || c.whatsapp.includes(q));

  const openCustomer = (customer?: LedgerCustomer) => {
    setEditingCustomer(customer ?? null);
    setCustomerForm(customer ? { name: customer.name, whatsapp: customer.whatsapp } : { name: "", whatsapp: "" });
    setCustomerModal(true);
  };
  const prepareCustomer = () => {
    if (!customerForm.name.trim() || !customerForm.whatsapp.trim()) return notify("اسم العميل وبيانات واتساب مطلوبان", "warn");
    const data = { name: customerForm.name.trim(), whatsapp: customerForm.whatsapp.trim() };
    setPending(editingCustomer ? { type: "customer-edit", id: editingCustomer.id, data } : { type: "customer-add", data });
  };
  const openOperation = (op?: CustomerOperation) => {
    setEditingOperation(op ?? null);
    setOpForm(op ? { currency: op.currency, custom: "", amount: String(op.amount), kind: op.kind, note: op.note, at: op.at.slice(0, 16) } : { currency: currencies[0] ?? BASE_CURRENCIES[0], custom: "", amount: "", kind: "for", note: "", at: new Date().toISOString().slice(0, 16) });
    setOperationModal(true);
  };
  const prepareOperation = () => {
    if (!selected) return;
    const currency = opForm.currency === "__custom" ? opForm.custom.trim() : opForm.currency;
    if (!currency || !(Number(opForm.amount) > 0)) return notify("اختر العملة وأدخل مبلغاً صحيحاً", "warn");
    const data = { currency, amount: Number(opForm.amount), kind: opForm.kind, note: opForm.note.trim(), at: new Date(opForm.at).toISOString() };
    setPending(editingOperation ? { type: "operation-edit", customerId: selected.id, operationId: editingOperation.id, data } : { type: "operation-add", customerId: selected.id, data });
  };
  const confirm = () => {
    if (!pending) return;
    const now = new Date().toISOString();
    if (pending.type === "customer-add") { setCustomers((list) => [{ id: `customer-${Date.now()}`, ...pending.data, createdAt: now, updatedAt: now, operations: [] }, ...list]); setCustomerModal(false); notify("تمت إضافة العميل"); }
    else if (pending.type === "customer-edit") { setCustomers((list) => list.map((c) => c.id === pending.id ? { ...c, ...pending.data, updatedAt: now } : c)); setCustomerModal(false); notify("تم تعديل العميل"); }
    else if (pending.type === "customer-delete") { setCustomers((list) => list.filter((c) => c.id !== pending.customer.id)); setSelectedId(null); notify("تم حذف العميل وجميع عملياته", "info"); }
    else if (pending.type === "operation-add") { setCustomers((list) => list.map((c) => c.id === pending.customerId ? { ...c, updatedAt: now, operations: [...(c.operations ?? []), { id: `op-${Date.now()}`, ...pending.data }] } : c)); if (!currencies.includes(pending.data.currency)) setCurrencies((list) => [...list, pending.data.currency]); setOperationModal(false); notify("تمت إضافة العملية وتحديث الرصيد"); }
    else if (pending.type === "operation-edit") { setCustomers((list) => list.map((c) => c.id === pending.customerId ? { ...c, updatedAt: now, operations: (c.operations ?? []).map((op) => op.id === pending.operationId ? { id: op.id, ...pending.data } : op) } : c)); setOperationModal(false); notify("تم تعديل العملية والرصيد"); }
    else { setCustomers((list) => list.map((c) => c.id === pending.customerId ? { ...c, updatedAt: now, operations: (c.operations ?? []).filter((op) => op.id !== pending.operation.id) } : c)); notify("تم حذف العملية وإعادة حساب الرصيد", "info"); }
    setPending(null); setEditingCustomer(null); setEditingOperation(null);
  };
  const sendWhatsapp = async (customer: LedgerCustomer) => {
    const text = whatsappMessage(customer), target = customer.whatsapp.trim();
    if (/chat\.whatsapp\.com/i.test(target)) { try { await navigator.clipboard.writeText(text); notify("تم نسخ الكشف؛ ألصقه داخل المجموعة"); } catch { /* ignore */ } window.open(target, "_blank", "noopener,noreferrer"); return; }
    const phone = target.replace(/\D/g, "").replace(/^00/, "");
    if (!phone) return notify("رقم واتساب غير صالح", "warn");
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, "_blank", "noopener,noreferrer");
  };
  const [pdfPreview, setPdfPreview] = useState<{ html: string; name: string } | null>(null);
  const openPdfPreview = (customer: LedgerCustomer) => {
    setPdfPreview({ html: latinize(statementHtml(customer)), name: `كشف-حساب-${customer.name}` });
  };
  const openExcel = (customer: LedgerCustomer) => {
    try {
      const ops = runningOperations(customer);
      const balances = balancesOf(customer);
      downloadExcelSheets(
        [
          {
            name: "كشف الحساب",
            rows: [
              ["#", "التاريخ والوقت", "العملة", "المبلغ", "النوع", "الملاحظة", "الرصيد"],
              ...ops.map((op, i) => [
                i + 1,
                `${DATE(op.at)} ${time(op.at)}`,
                op.currency,
                op.amount,
                op.kind === "for" ? "لنا" : "علينا",
                op.note || "",
                op.balance,
              ]),
            ],
          },
          {
            name: "الأرصدة",
            rows: [
              ["العملة", "لنا", "علينا", "الصافي", "الحالة"],
              ...[...balances.entries()].map(([currency, b]) => [
                currency,
                b.for,
                b.on,
                b.net,
                b.net === 0 ? "متوازن" : b.net > 0 ? "دائن لكم" : "دائن علينا",
              ]),
            ],
          },
        ],
        `كشف-حساب-${customer.name}`
      );
      notify("تم تنزيل كشف الحساب بصيغة Excel (.xlsx) بنجاح");
    } catch {
      notify("تعذر إنشاء ملف Excel", "warn");
    }
  };
  const share = async (customer: LedgerCustomer) => { const text = whatsappMessage(customer); if (navigator.share) await navigator.share({ title: `كشف حساب ${customer.name}`, text }).catch(() => undefined); else { await navigator.clipboard.writeText(text); notify("تم نسخ الكشف للمشاركة"); } };

  const operationDialogs = () => <>
    <Modal open={operationModal} onClose={() => setOperationModal(false)} title={editingOperation ? "تعديل العملية" : "إضافة عملية"} onSubmit={prepareOperation}><div className="grid grid-cols-2 gap-4"><L label="العملة"><select className={inputCls} value={opForm.currency} onChange={(e) => setOpForm({ ...opForm, currency: e.target.value })}>{currencies.map((c) => <option key={c}>{c}</option>)}<option value="__custom">+ عملة جديدة</option></select></L><L label="المبلغ"><input type="number" min={0} className={inputCls} value={opForm.amount} onChange={(e) => setOpForm({ ...opForm, amount: e.target.value })} enterKeyHint="next" /></L>{opForm.currency === "__custom" && <L label="اسم العملة" className="col-span-2"><input className={inputCls} value={opForm.custom} onChange={(e) => setOpForm({ ...opForm, custom: e.target.value })} enterKeyHint="next" /></L>}<L label="نوع العملية"><select className={inputCls} value={opForm.kind} onChange={(e) => setOpForm({ ...opForm, kind: e.target.value as OperationKind })}><option value="for">لنا</option><option value="on">علينا</option></select></L><L label="التاريخ والوقت"><input type="datetime-local" className={inputCls} value={opForm.at} onChange={(e) => setOpForm({ ...opForm, at: e.target.value })} enterKeyHint="next" /></L><L label="ملاحظة" className="col-span-2"><textarea className={`${inputCls} min-h-20`} value={opForm.note} onChange={(e) => setOpForm({ ...opForm, note: e.target.value })} /></L></div><button onClick={prepareOperation} className="btn-gold mt-5 w-full rounded-xl py-3 text-xs">{editingOperation ? "حفظ التعديل" : "إضافة القيد"}</button></Modal>
    <ConfirmDialog open={!!pending && pending.type.startsWith("operation")} onClose={() => setPending(null)} onConfirm={confirm} variant={pending?.type === "operation-delete" ? "danger" : "gold"} title={pending?.type === "operation-delete" ? "حذف العملية" : "تأكيد العملية"} message="سيتم تحديث كشف الحساب وأرصدة العملات مباشرة." confirmLabel="تأكيد" />
  </>;

  if (selected) {
    const balances = balancesOf(selected), rows = runningOperations(selected);
    return <div className="space-y-5"><button onClick={() => setSelectedId(null)} className="btn-ghost flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-black"><ArrowRight size={14} /> العودة للعملاء</button><Glass gold className="p-5 md:p-6"><div className="flex flex-wrap items-center gap-4"><span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#171207] text-[var(--gold)]"><UserRound /></span><div><h1 className="font-display text-2xl font-black">{selected.name}</h1><p className="text-xs text-[var(--muted)]">{NUM(rows.length)} عملية · آخر تعديل {DATE(selected.updatedAt)}</p></div><div className="ms-auto flex gap-2"><button onClick={() => void sendWhatsapp(selected)} className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#25D366] text-white"><MessageCircle size={18} /></button><button onClick={() => openExcel(selected)} title="تصدير Excel" className="btn-ghost flex h-10 w-10 items-center justify-center rounded-xl text-[var(--green)]"><FileSpreadsheet size={17} /></button><button onClick={() => openPdfPreview(selected)} title="معاينة وتصدير PDF" className="btn-ghost flex h-10 w-10 items-center justify-center rounded-xl text-[var(--red)]"><FileDown size={17} /></button><button onClick={() => void share(selected)} className="btn-ghost flex h-10 w-10 items-center justify-center rounded-xl"><Share2 size={17} /></button></div></div><div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{balances.size ? [...balances.entries()].map(([currency, b]) => <div key={currency} className="rounded-xl border border-[var(--border-gold)] bg-[var(--surface)] p-3.5"><p className="text-[10px] text-[var(--muted)]">{currency}</p><p className={`num text-lg font-black ${b.net >= 0 ? "text-[var(--green)]" : "text-[var(--red)]"}`}>{b.net === 0 ? "لا يوجد رصيد" : fmt(b.net)}</p><p className="text-[10px] text-[var(--faint)]">{b.net === 0 ? "الحساب متوازن" : `دائن ${b.net > 0 ? "لنا" : "علينا"}`}</p></div>) : <p className="text-sm text-[var(--muted)]">لا توجد أرصدة بعد.</p>}</div></Glass><Glass className="overflow-hidden"><div className="flex items-center justify-between border-b border-[var(--border)] p-4"><h2 className="font-display text-lg font-black">كشف الحساب</h2><button onClick={() => openOperation()} className="btn-gold flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs"><Plus size={15} /> إضافة عملية</button></div><div className="max-h-[58vh] overflow-auto"><table className="lux-table"><thead><tr><th>التاريخ</th><th>العملة</th><th>المبلغ</th><th>لنا</th><th>علينا</th><th>الملاحظة</th><th>الرصيد بعد العملية</th><th>إجراءات</th></tr></thead><tbody>{rows.map((op) => <tr key={op.id}><td>{DATE(op.at)}<small className="block">{time(op.at)}</small></td><td>{op.currency}</td><td className="num font-black">{fmt(op.amount)}</td><td className="num text-[var(--green)]">{op.kind === "for" ? fmt(op.amount) : "—"}</td><td className="num text-[var(--red)]">{op.kind === "on" ? fmt(op.amount) : "—"}</td><td>{op.note || "—"}</td><td className={`num font-black ${op.balance >= 0 ? "text-[var(--green)]" : "text-[var(--red)]"}`}>{fmt(op.balance)} {op.balance >= 0 ? "لنا" : "علينا"}</td><td><div className="flex gap-1"><button onClick={() => openOperation(op)} className="text-[var(--gold)]"><Pencil size={13} /></button><button onClick={() => setPending({ type: "operation-delete", customerId: selected.id, operation: op })} className="text-[var(--red)]"><Trash2 size={13} /></button></div></td></tr>)}{rows.length === 0 && <tr><td colSpan={8}><EmptyState icon={<Coins />} text="لا توجد عمليات لهذا العميل" /></td></tr>}</tbody></table></div></Glass>{operationDialogs()}{pdfPreview && <PdfPreviewModal open onClose={() => setPdfPreview(null)} html={pdfPreview.html} filename={pdfPreview.name} title={`كشف حساب — ${selected.name}`} />}</div>;
  }

  return <div><SectionHead title="العملاء" sub="إدارة العملاء وكشوف الحساب متعددة العملات" actions={<button onClick={() => openCustomer()} className="btn-gold flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs"><Plus size={15} /> إضافة عميل</button>} /><div className="relative mb-5 max-w-sm"><Search className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[var(--faint)]" size={15} /><input className="field w-full rounded-xl py-2.5 pr-10 text-sm" value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث سريع باسم العميل…" /></div><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3"><AnimatePresence>{shown.map((customer, i) => { const balances = balancesOf(customer), first = [...balances.entries()][0]; return <motion.article key={customer.id} layout initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * .04 }} onClick={() => setSelectedId(customer.id)} className="card-hover glass group cursor-pointer rounded-[20px] p-5"><div className="flex gap-3"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--gold-dim)] text-[var(--gold)]"><UserRound size={19} /></span><div className="flex-1"><h2 className="font-display font-black">{customer.name}</h2><p className="text-[10px] text-[var(--muted)]">{NUM(customer.operations?.length ?? 0)} عملية</p></div><button onClick={(e) => { e.stopPropagation(); void sendWhatsapp(customer); }} className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#25D366]/15 text-[#25D366]"><MessageCircle size={15} /></button></div><div className="mt-4 rounded-xl border border-[var(--border)] p-3"><p className="text-[10px] text-[var(--muted)]">الرصيد الحالي</p><p className={`num text-lg font-black ${!first || first[1].net >= 0 ? "text-[var(--green)]" : "text-[var(--red)]"}`}>{first ? `${fmt(first[1].net)} ${first[0]}` : "لا يوجد رصيد"}</p>{balances.size > 1 && <p className="text-[9px] text-[var(--faint)]">و{NUM(balances.size - 1)} عملات أخرى</p>}</div><div className="mt-3 flex items-center text-[10px] text-[var(--faint)]"><CalendarClock size={11} /> آخر تعديل: {DATE(customer.updatedAt)}<div className="ms-auto flex gap-2"><button onClick={(e) => { e.stopPropagation(); openCustomer(customer); }} className="text-[var(--gold)]"><Pencil size={12} /></button><button onClick={(e) => { e.stopPropagation(); setPending({ type: "customer-delete", customer }); }} className="text-[var(--red)]"><Trash2 size={12} /></button></div></div></motion.article>; })}</AnimatePresence></div>{shown.length === 0 && <Glass><EmptyState icon={<Users />} text={q ? "لا يوجد عميل مطابق" : "لا يوجد عملاء بعد"} /></Glass>}<Modal open={customerModal} onClose={() => setCustomerModal(false)} title={editingCustomer ? "تعديل العميل" : "إضافة عميل جديد"}><div className="space-y-4"><L label="اسم العميل *"><input className={inputCls} value={customerForm.name} onChange={(e) => setCustomerForm({ ...customerForm, name: e.target.value })} /></L><L label="رقم واتساب أو رابط المجموعة *"><input dir="ltr" className={inputCls} value={customerForm.whatsapp} onChange={(e) => setCustomerForm({ ...customerForm, whatsapp: e.target.value })} /></L></div><button onClick={prepareCustomer} className="btn-gold mt-5 w-full rounded-xl py-3 text-xs">حفظ العميل</button></Modal><ConfirmDialog open={!!pending && pending.type.startsWith("customer")} onClose={() => setPending(null)} onConfirm={confirm} variant={pending?.type === "customer-delete" ? "danger" : "gold"} title={pending?.type === "customer-delete" ? "حذف العميل" : "تأكيد حفظ العميل"} message={pending?.type === "customer-delete" ? "سيتم حذف العميل وجميع عملياته وأرصدته نهائياً." : "سيتم حفظ بيانات العميل في Firebase فوراً."} confirmLabel="تأكيد" /></div>;
}

function SuppliersModule() {
  const { tenantUid } = useApp();
  const [storedSuppliers] = useTenantState<StoredCustomers>(tenantUid, "suppliers", EMPTY);
  const suppliers = useMemo(() => normalizeCustomers(storedSuppliers), [storedSuppliers]);
  return <div><SectionHead title="الوكلاء والجهات" sub="سجل الجهات والوكلاء المتعامل معهم في إرسال واستلام الحوالات" /><Glass>{suppliers.length ? <div className="grid gap-3 p-4 sm:grid-cols-2">{suppliers.map((s) => <div key={s.id} className="rounded-xl border border-[var(--border)] p-4"><p className="font-black">{s.name}</p><p className="text-xs text-[var(--muted)]">{s.whatsapp}</p></div>)}</div> : <EmptyState icon={<Truck />} text="لا يوجد وكلاء أو جهات بعد" />}</Glass></div>;
}

export default function Partners({ kind }: { kind: "customer" | "supplier" }) { return kind === "customer" ? <CustomerModule /> : <SuppliersModule />; }