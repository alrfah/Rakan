import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  closestCenter, DndContext, PointerSensor, useSensor, useSensors, type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove, SortableContext, useSortable, verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  BarChart3, Bell, CalendarClock, ChartNoAxesCombined, ChevronsLeft, ChevronsRight,
  Cloud, FileText, GripVertical, HandCoins, Landmark, LayoutDashboard, LayoutGrid, LogOut, Menu, Moon,
  PiggyBank, ReceiptText, Scissors, Search, Settings, ShieldCheck, Sun, Trash2, TrendingUp, Truck, Users, Wallet, X,
} from "lucide-react";
import { DEBTS, INVOICES, NOTIFICATIONS, PARTNERS, ROLE_LABEL, type NotificationItem, type TeamUser } from "../data/mock";
import { SAR } from "../utils/format";
import { Chip } from "./ui";
import { useApp } from "./ui";
import { useTenantState } from "../lib/tenant";

/* ترتيب محفوظ في localStorage حسب uid المستخدم (لكل مستخدم ترتيبه الخاص) */
const ORDER_KEY = (uid: string) => `diwan-nav-order:${uid}`;
const DEFAULT_ORDER: SectionId[] = [
  "dashboard", "analytics", "invoices", "customers", "suppliers", "cutting",
  "debts", "cash", "banks", "opening", "exin", "reports", "trash", "settings",
];
function loadOrder(uid: string | undefined): SectionId[] {
  if (typeof window === "undefined" || !uid) return DEFAULT_ORDER;
  try {
    const raw = localStorage.getItem(ORDER_KEY(uid));
    if (!raw) return DEFAULT_ORDER;
    const parsed = JSON.parse(raw) as SectionId[];
    const validIds = new Set(DEFAULT_ORDER);
    const filtered = parsed.filter((id) => validIds.has(id));
    const missing = DEFAULT_ORDER.filter((id) => !filtered.includes(id));
    return [...filtered, ...missing];
  } catch {
    return DEFAULT_ORDER;
  }
}
function saveOrder(uid: string, order: SectionId[]) {
  try {
    localStorage.setItem(ORDER_KEY(uid), JSON.stringify(order));
  } catch { /* تجاهل أخطاء localStorage */ }
}

export type SectionId =
  | "dashboard" | "analytics" | "journal" | "invoices" | "customers" | "suppliers" | "cutting"
  | "debts" | "cash" | "banks" | "opening" | "exin" | "reports" | "settings" | "trash";

export const canAccess = (role: TeamUser["role"], s: SectionId) => {
  if (role === "admin") return true;
  if (role === "accountant") return (["dashboard", "analytics", "invoices", "customers", "cash", "banks", "debts", "opening", "exin", "reports", "cutting", "settings", "trash"] as SectionId[]).includes(s);
  // الموظف العادي: يمكنه الوصول للإعدادات فقط (إعداداته الشخصية)
  if (s === "settings") return true;
  return (["dashboard", "analytics", "invoices", "customers", "cash", "cutting"] as SectionId[]).includes(s);
};

// قائمة مسطحة بدون مجموعات - قابلة لإعادة الترتيب
const NAV_ITEMS: { id: SectionId; label: string; icon: typeof Wallet; badge?: string }[] = [
  { id: "dashboard", label: "الرئيسية", icon: LayoutGrid },
  { id: "analytics", label: "لوحة التحكم", icon: LayoutDashboard },
  { id: "invoices", label: "الحوالات المالية", icon: ReceiptText },
  { id: "customers", label: "العملاء", icon: Users },
  { id: "suppliers", label: "الوكلاء والجهات", icon: Truck },
  { id: "cutting", label: "القص والاعتماد", icon: Scissors },
  { id: "debts", label: "الدائنون والديون", icon: HandCoins },
  { id: "cash", label: "الصندوق", icon: Wallet },
  { id: "banks", label: "البنوك", icon: Landmark },
  { id: "opening", label: "الأرصدة الافتتاحية", icon: CalendarClock },
  { id: "exin", label: "المصاريف والإيرادات", icon: PiggyBank },
  { id: "reports", label: "التقارير", icon: BarChart3 },
  { id: "trash", label: "سلة المهملات", icon: Trash2 },
  { id: "settings", label: "الإعدادات والحسابات", icon: Settings },
];

/* عنصر قائمة قابل للسحب */
function SortableNavItem({ it, section, go, onMobileClose, allowed, collapsed }: {
  it: { id: SectionId; label: string; icon: typeof Wallet; badge?: string };
  section: SectionId;
  go: (s: SectionId) => void;
  onMobileClose: () => void;
  allowed: boolean;
  collapsed: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: it.id });
  const active = section === it.id;
  const style: React.CSSProperties = {
    transform: CSS.Translate.toString(transform),
    transition,
    opacity: isDragging ? 0.75 : 1,
    zIndex: isDragging ? 99 : "auto",
  };
  return (
    <li ref={setNodeRef} style={style} className="touch-none select-none">
      <div
        className={`group relative flex items-stretch rounded-xl border transition-all duration-300 ${
          active
            ? "border-[var(--gold)] bg-gradient-to-l from-[var(--gold-bright)] to-[var(--gold)] text-[#171207] shadow-[0_6px_18px_var(--gold-dim)]"
            : "border-transparent hover:border-[var(--gold)] hover:bg-white/20 dark:hover:bg-white/[0.12] text-[var(--muted)] hover:text-[var(--text)]"
        } ${isDragging ? "bg-[var(--bg-2)] border-[var(--gold)] shadow-2xl" : ""}`}
      >
        {/* مقبض السحب - يظهر بوضوح على الجوال والكمبيوتر */}
        <button
          type="button"
          {...attributes}
          {...listeners}
          aria-label="اسحب لإعادة ترتيب"
          title="اضغط مطولاً واسحب لإعادة الترتيب"
          className={`flex w-7 shrink-0 cursor-grab touch-none items-center justify-center rounded-r-xl text-[var(--faint)] transition-colors hover:text-[var(--gold)] active:cursor-grabbing ${
            collapsed ? "lg:hidden" : ""
          }`}
        >
          <GripVertical size={14} />
        </button>
        <button
          onClick={() => {
            if (!allowed) return;
            go(it.id);
            onMobileClose();
          }}
          title={it.label}
          className={`group relative flex w-full items-center gap-3 rounded-l-xl rounded-r-none px-3 py-2.5 text-sm font-bold transition-all duration-200 ${
            active ? "text-[#171207]" : "hover:text-[var(--text)]"
          } ${!allowed ? "opacity-40" : ""}`}
        >
          <it.icon size={18} className="relative z-10 shrink-0" />
          <span className={`relative z-10 flex-1 text-start ${collapsed ? "lg:hidden" : ""}`}>{it.label}</span>
          {it.badge && (
            <span className={`relative z-10 rounded-full px-1.5 py-px text-[9px] font-black ${collapsed ? "lg:hidden" : ""} ${
              active ? "bg-[#171207]/20 text-[#171207]" : "bg-[var(--red-soft)] text-[var(--red)]"
            }`}>
              {it.badge}
            </span>
          )}
          {!allowed && <ShieldCheck size={13} className={`relative z-10 ${collapsed ? "lg:hidden" : ""}`} />}
        </button>
      </div>
    </li>
  );
}

/* ============ قائمة قابلة للسحب والإفلات ============ */
function SortableNavList({
  section, go, onMobileClose, user, notify, collapsed, uid,
}: {
  section: SectionId;
  go: (s: SectionId) => void;
  onMobileClose: () => void;
  user: TeamUser;
  notify: (m: string, k?: "success" | "info" | "warn") => void;
  collapsed: boolean;
  uid: string;
}) {
  const [order, setOrder] = useState<SectionId[]>(() => loadOrder(uid));
  // إعادة تحميل الترتيب عند تغير المستخدم
  useEffect(() => {
    setOrder(loadOrder(uid));
  }, [uid]);
  // حفظ الترتيب عند تغيره
  useEffect(() => {
    saveOrder(uid, order);
  }, [uid, order]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }));
  const items = order
    .map((id) => NAV_ITEMS.find((n) => n.id === id))
    .filter(Boolean) as typeof NAV_ITEMS;

  const handleDragStart = () => {
    document.documentElement.classList.add("is-dragging");
  };

  const handleDragEnd = (event: DragEndEvent) => {
    document.documentElement.classList.remove("is-dragging");
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = order.indexOf(active.id as SectionId);
    const newIndex = order.indexOf(over.id as SectionId);
    if (oldIndex === -1 || newIndex === -1) return;
    const next = arrayMove(order, oldIndex, newIndex);
    setOrder(next);
    notify("تم حفظ ترتيب القائمة بنجاح ✓", "success");
  };

  const handleDragCancel = () => {
    document.documentElement.classList.remove("is-dragging");
  };

  const activeItem = items.find((i) => i.id === section);
  const activeLabel = activeItem ? `القسم الحالي: ${activeItem.label}` : "اسحب العناصر لإعادة ترتيب القائمة";

  return (
    <nav
      className="flex-1 overflow-y-auto px-3 pb-4"
      aria-label="القائمة الجانبية - اسحب لإعادة الترتيب"
    >
      {!collapsed && (
        <p className="mb-2 px-3 text-[10px] font-black tracking-[0.2em] text-[var(--faint)]">
          {activeLabel}
        </p>
      )}
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragStart={handleDragStart} onDragEnd={handleDragEnd} onDragCancel={handleDragCancel}>
        <SortableContext items={order} strategy={verticalListSortingStrategy}>
          <ul className="space-y-1">
            {items.map((it) => (
              <SortableNavItem
                key={it.id}
                it={it}
                section={section}
                go={go}
                onMobileClose={onMobileClose}
                allowed={canAccess(user.role, it.id)}
                collapsed={collapsed}
              />
            ))}
          </ul>
        </SortableContext>
      </DndContext>
    </nav>
  );
}

/* ============ الشريط الجانبي ============ */
export function Sidebar({
  section, go, collapsed, onCollapse, mobileOpen, onMobileClose, user, onLogout, notify,
}: {
  section: SectionId;
  go: (s: SectionId) => void;
  collapsed: boolean;
  onCollapse: () => void;
  mobileOpen: boolean;
  onMobileClose: () => void;
  user: TeamUser;
  onLogout: () => void;
  notify: (m: string, k?: "success" | "info" | "warn") => void;
}) {
  return (
    <>
      {/* خلفية معتمة للهاتف */}
      {mobileOpen && (
        <div className="no-print fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden" onClick={onMobileClose} />
      )}
      <aside
        className={`no-print fixed inset-y-0 right-0 z-50 flex flex-col border-l border-[var(--border)] bg-[var(--bg-2)]/95 backdrop-blur-xl transition-all duration-300 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${
          collapsed ? "lg:w-[86px]" : "lg:w-[268px]"
        } w-[288px] ${mobileOpen ? "translate-x-0" : "translate-x-full"}`}
      >
        {/* الشعار */}
        <div className={`flex items-center gap-3 px-5 pb-6 pt-6 ${collapsed ? "lg:justify-center lg:px-2" : ""}`}>
          <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[var(--gold-bright)] to-[var(--gold)] text-[#171207] shadow-[0_6px_20px_var(--gold-dim)]">
            <ChartNoAxesCombined size={23} strokeWidth={2.5} aria-hidden="true" />
            <span className="absolute -left-1 -top-1 h-3 w-3 rounded-full border-2 border-[var(--bg-2)] bg-[var(--green)] pulse-dot" />
          </div>
          {!collapsed && (
            <div className="lg:block">
              <p className="font-display text-xl font-black leading-none">الرفاه</p>
              <p className="mt-1 text-[10px] font-bold tracking-widest text-[var(--gold)]">للحوالات المالية</p>
            </div>
          )}
          <button onClick={onMobileClose} className="btn-ghost ms-auto flex h-8 w-8 items-center justify-center rounded-full lg:hidden" aria-label="إغلاق القائمة">
            <X size={15} />
          </button>
        </div>

        {/* عناصر التنقل - قابلة للسحب والإفلات لإعادة الترتيب */}
        <SortableNavList section={section} go={go} onMobileClose={onMobileClose} user={user} notify={notify} collapsed={collapsed} uid={user.id} />

        {/* حالة المزامنة + زر الطي */}
        <div className="border-t border-[var(--border)] p-3">
          {!collapsed && (
            <div className="mb-3 flex items-center gap-2.5 rounded-xl bg-[var(--surface)] px-3 py-2.5">
              <span className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--green-soft)] text-[var(--green)]">
                <Cloud size={15} />
                <span className="absolute -left-0.5 -top-0.5 h-2 w-2 rounded-full bg-[var(--green)] pulse-dot" />
              </span>
              <div>
                <p className="text-[11px] font-black">محفوظ على الجهاز</p>
                <p className="text-[10px] text-[var(--faint)]">التخزين المحلي فعّال</p>
              </div>
            </div>
          )}
          <div className="flex items-center gap-2">
            <button
              onClick={onCollapse}
              className="btn-ghost hidden h-9 flex-1 items-center justify-center rounded-xl text-xs font-bold lg:flex"
            >
              {collapsed ? <ChevronsLeft size={16} /> : <><ChevronsRight size={16} /> <span className="ms-1">طيّ القائمة</span></>}
            </button>
            <button onClick={onLogout} title="تسجيل الخروج" className="btn-ghost flex h-9 w-9 items-center justify-center rounded-xl text-[var(--red)]">
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}

/* ============ الشريط العلوي ============ */
export function Topbar({
  onMenu, theme, onTheme, user, onLogout, go,
}: {
  onMenu: () => void;
  theme: "dark" | "light";
  onTheme: () => void;
  user: TeamUser;
  onLogout: () => void;
  go: (s: SectionId) => void;
}) {
  const { tenantUid } = useApp();
  const [query, setQuery] = useState("");
  const [notifOpen, setNotifOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const [notifs, setNotifs] = useTenantState<NotificationItem[]>(tenantUid, "notifications", NOTIFICATIONS);
  const unread = notifs.filter((n) => !n.read).length;

  const results = useMemo(() => {
    const q = query.trim();
    if (q.length < 2) return null;
    return {
      debts: DEBTS.filter((d) => d.party.includes(q) || d.origin.includes(q)).slice(0, 3),
      partners: PARTNERS.filter((p) => p.name.includes(q) || p.contact.includes(q)).slice(0, 3),
      invoices: INVOICES.filter((i) => i.no.includes(q.toUpperCase()) || i.party.includes(q)).slice(0, 3),
    };
  }, [query]);

  const kindIcon = (k: NotificationItem["kind"]) =>
    k === "debt" ? <HandCoins size={14} /> : k === "invoice" ? <FileText size={14} /> : k === "bank" ? <Landmark size={14} /> : <ShieldCheck size={14} />;

  const initials = user.name.split(" ").map((w) => w[0]).slice(0, 2).join("");

  return (
    <header className="no-print sticky top-0 z-30 border-b border-[var(--border)] bg-[var(--bg)]/80 backdrop-blur-xl">
      <div className="flex items-center gap-3 px-4 py-3 md:px-7">
        <button onClick={onMenu} className="btn-ghost flex h-9 w-9 items-center justify-center rounded-xl lg:hidden" aria-label="القائمة">
          <Menu size={17} />
        </button>

        {/* البحث الفوري */}
        <div className="relative flex-1 max-w-md">
          <Search size={15} className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-[var(--faint)]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث عن حوالة، عميل، حساب…"
            className="field w-full rounded-xl py-2 pe-4 ps-4 pr-9 text-sm"
          />
          {results && (
            <div className="glass absolute top-full z-40 mt-2 w-full min-w-[300px] overflow-hidden rounded-2xl p-2">
              {results.debts.length === 0 && results.partners.length === 0 && results.invoices.length === 0 && (
                <p className="px-3 py-4 text-center text-xs text-[var(--muted)]">لا نتائج مطابقة لـ «{query}»</p>
              )}
              {results.invoices.length > 0 && (
                <div>
                  <p className="px-2 py-1.5 text-[10px] font-black tracking-widest text-[var(--faint)]">الحوالات</p>
                  {results.invoices.map((i) => (
                    <button key={i.id} onClick={() => { go("invoices"); setQuery(""); }} className="flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-xs hover:bg-[var(--gold-dim)]">
                      <span className="flex items-center gap-2 font-bold"><FileText size={13} className="text-[var(--gold)]" />{i.no}</span>
                      <span className="text-[var(--muted)]">{i.party}</span>
                      <span className="num font-bold">{SAR(i.total)}</span>
                    </button>
                  ))}
                </div>
              )}
              {results.partners.length > 0 && (
                <div>
                  <p className="px-2 py-1.5 text-[10px] font-black tracking-widest text-[var(--faint)]">العملاء والوكلاء</p>
                  {results.partners.map((p) => (
                    <button key={p.id} onClick={() => { go(p.kind === "customer" ? "customers" : "suppliers"); setQuery(""); }} className="flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-xs hover:bg-[var(--gold-dim)]">
                      <span className="flex items-center gap-2 font-bold">
                        {p.kind === "customer" ? <Users size={13} className="text-[var(--sky)]" /> : <Truck size={13} className="text-[var(--gold)]" />}
                        {p.name}
                      </span>
                      <span className="num font-bold">{SAR(p.balance)}</span>
                    </button>
                  ))}
                </div>
              )}
              {results.debts.length > 0 && (
                <div>
                  <p className="px-2 py-1.5 text-[10px] font-black tracking-widest text-[var(--faint)]">الدائنون والديون</p>
                  {results.debts.map((d) => (
                    <button key={d.id} onClick={() => { go("debts"); setQuery(""); }} className="flex w-full items-center justify-between gap-2 rounded-lg px-2.5 py-2 text-xs hover:bg-[var(--gold-dim)]">
                      <span className="flex items-center gap-2 font-bold"><HandCoins size={13} className="text-[var(--red)]" />{d.party}</span>
                      <span className="num font-bold">{SAR(d.amount - d.paid)}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="ms-auto flex items-center gap-2">
          {/* الثيم */}
          <button onClick={onTheme} className="btn-ghost flex h-9 w-9 items-center justify-center rounded-xl" aria-label="تبديل المظهر">
            <motion.span key={theme} initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} transition={{ duration: 0.35 }}>
              {theme === "dark" ? <Sun size={16} className="text-[var(--gold)]" /> : <Moon size={16} className="text-[var(--sky)]" />}
            </motion.span>
          </button>

          {/* الإشعارات */}
          <div className="relative">
            <button onClick={() => { setNotifOpen(!notifOpen); setUserOpen(false); }} className="btn-ghost relative flex h-9 w-9 items-center justify-center rounded-xl" aria-label="الإشعارات">
              <Bell size={16} />
              {unread > 0 && (
                <span className="absolute -left-1 -top-1 flex h-4.5 min-w-[18px] items-center justify-center rounded-full bg-[var(--red)] px-1 text-[9px] font-black text-white">
                  {unread}
                </span>
              )}
            </button>
            {notifOpen && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setNotifOpen(false)} />
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.18 }}
                  className="glass absolute end-0 top-full z-40 mt-2 w-[340px] overflow-hidden rounded-2xl"
                >
                  <div className="flex items-center justify-between border-b border-[var(--border)] px-4 py-3">
                    <p className="font-display text-sm font-extrabold">الإشعارات الذكية</p>
                    <button
                      onClick={() => setNotifs((ns) => ns.map((n) => ({ ...n, read: true })))}
                      className="text-[10px] font-black text-[var(--gold)] hover:underline"
                    >
                      تحديد الكل كمقروء
                    </button>
                  </div>
                  <ul className="max-h-[340px] overflow-y-auto">
                    {notifs.map((n) => (
                      <li key={n.id} className={`flex gap-3 border-b border-[var(--border)] px-4 py-3 last:border-0 ${n.read ? "opacity-55" : ""}`}>
                        <span className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
                          n.kind === "debt" ? "bg-[var(--red-soft)] text-[var(--red)]" : n.kind === "bank" ? "bg-[var(--green-soft)] text-[var(--green)]" : "bg-[var(--gold-dim)] text-[var(--gold)]"
                        }`}>
                          {kindIcon(n.kind)}
                        </span>
                        <div className="min-w-0">
                          <p className="flex items-center gap-2 text-xs font-black">
                            {n.title}
                            {!n.read && <span className="h-1.5 w-1.5 rounded-full bg-[var(--gold)]" />}
                          </p>
                          <p className="mt-0.5 text-[11px] leading-5 text-[var(--muted)]">{n.body}</p>
                          <p className="mt-1 text-[10px] text-[var(--faint)]">{n.time}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              </>
            )}
          </div>

          {/* المستخدم */}
          <div className="relative">
            <button
              onClick={() => { setUserOpen(!userOpen); setNotifOpen(false); }}
              className="flex items-center gap-2.5 rounded-xl border border-transparent px-2 py-1.5 transition-colors hover:border-[var(--border)] hover:bg-[var(--surface)]"
            >
              <span className="flex h-8.5 w-8.5 h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-[var(--gold-bright)] to-[var(--gold)] font-display text-xs font-black text-[#171207]">
                {initials}
              </span>
              <span className="hidden text-start md:block">
                <span className="block text-xs font-black leading-none">{user.name}</span>
                <span className="mt-1 block text-[10px] font-bold text-[var(--gold)]">{ROLE_LABEL[user.role]}</span>
              </span>
            </button>
            {userOpen && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setUserOpen(false)} />
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="glass absolute end-0 top-full z-40 mt-2 w-52 overflow-hidden rounded-2xl p-2">
                  <p className="border-b border-[var(--border)] px-3 pb-2.5 pt-1.5">
                    <span className="block text-xs font-black">{user.name}</span>
                    <span className="text-[10px] text-[var(--muted)]">{ROLE_LABEL[user.role]}</span>
                  </p>
                  <button onClick={() => { setUserOpen(false); go("settings"); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold hover:bg-[var(--gold-dim)]">
                    <Settings size={14} className="text-[var(--gold)]" /> الإعدادات
                  </button>
                  <button onClick={onLogout} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold text-[var(--red)] hover:bg-[var(--red-soft)]">
                    <LogOut size={14} /> تسجيل الخروج
                  </button>
                </motion.div>
              </>
            )}
          </div>
        </div>
      </div>
      {false && <Chip label="" cls="" />}
    </header>
  );
}

/* شريط تحميل ذهبي يظهر عند تغيير القسم */
export function LoadBar({ k }: { k: number }) {
  return (
    <div key={k} className="no-print pointer-events-none fixed inset-x-0 top-0 z-[60] h-[3px]">
      <div className="loadbar h-full w-full bg-gradient-to-l from-transparent via-[var(--gold)] to-[var(--gold-bright)]" />
    </div>
  );
}

/* بطاقة ترحيب صغيرة للاستخدام */
export function WelcomeNote() {
  return (
    <div className="flex items-center gap-2">
      <TrendingUp size={14} className="text-[var(--green)]" />
      <span className="text-xs font-bold text-[var(--muted)]">أداء ممتاز هذا الشهر</span>
      <Chip label="+18٪" cls="chip-green" />
    </div>
  );
}

/* ============ شريط تنقل سفلي احترافي نمط تطبيق أندرويد ============ */
export function BottomNav({
  section,
  go,
  user,
  onOpenMenu,
}: {
  section: SectionId;
  go: (s: SectionId) => void;
  user: TeamUser;
  onOpenMenu: () => void;
}) {
  const items = [
    { id: "dashboard" as const, label: "الرئيسية", icon: LayoutDashboard },
    { id: "invoices" as const, label: "الحوالات", icon: ReceiptText },
    { id: "cutting" as const, label: "القص", icon: Scissors },
    { id: "customers" as const, label: "العملاء", icon: Users },
    { id: "settings" as const, label: "الحسابات", icon: Settings },
  ];

  return (
    <nav
      className="no-print fixed inset-x-0 bottom-0 z-40 flex h-16 items-center justify-around border-t border-[var(--border)] bg-[var(--bg)]/95 px-2 backdrop-blur-xl lg:hidden"
      style={{ boxShadow: "0 -4px 20px rgba(0,0,0,0.3)" }}
    >
      {items.map((it) => {
        const active = section === it.id;
        const allowed = canAccess(user.role, it.id);
        return (
          <button
            key={it.id}
            onClick={() => allowed && go(it.id)}
            disabled={!allowed}
            className={`relative flex flex-col items-center justify-center gap-1 px-3 py-1 transition-all duration-200 ${
              active ? "text-[var(--gold-bright)]" : "text-[var(--muted)] hover:text-[var(--text)]"
            } ${!allowed ? "opacity-35" : ""}`}
          >
            {active && (
              <motion.span
                layoutId="bottomnav-pill"
                className="absolute top-0 h-1 w-8 rounded-full bg-gradient-to-l from-[var(--gold-bright)] to-[var(--gold)] shadow-[0_2px_10px_var(--gold-dim)]"
                transition={{ type: "spring", stiffness: 450, damping: 32 }}
              />
            )}
            <it.icon size={20} className={active ? "scale-110 transition-transform" : ""} />
            <span className="text-[10px] font-extrabold">{it.label}</span>
          </button>
        );
      })}
      <button
        onClick={onOpenMenu}
        className="flex flex-col items-center justify-center gap-1 px-3 py-1 text-[var(--muted)] hover:text-[var(--text)]"
      >
        <Menu size={20} />
        <span className="text-[10px] font-extrabold">المزيد</span>
      </button>
    </nav>
  );
}
