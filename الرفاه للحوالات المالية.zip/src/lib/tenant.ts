import { useCallback, useEffect, useRef, useState, type SetStateAction } from "react";
import { onValue, ref, remove, set, update } from "firebase/database";
import { db } from "./firebase";

const safeSegment = (value: string) => {
  if (!value || /[.#$\[\]/]/.test(value)) throw new Error("Invalid Firebase path segment");
  return value;
};

export const tenantPath = (uid: string, section: string) => {
  const sectionPath = section.split("/").map(safeSegment).join("/");
  return `users/${safeSegment(uid)}/${sectionPath}`;
};

export function subscribeTenantSection<T>(uid: string, section: string, callback: (data: T | null) => void) {
  return onValue(ref(db, tenantPath(uid, section)), (snapshot) => callback(snapshot.exists() ? (snapshot.val() as T) : null));
}

export function useTenantSnapshot<T>(uid: string | undefined, section: string, emptyValue: T) {
  const [value, setValue] = useState<T>(emptyValue);
  useEffect(() => {
    setValue(emptyValue);
    if (!uid) return;
    return subscribeTenantSection<T>(uid, section, (remote) => setValue(remote ?? emptyValue));
  }, [uid, section]);
  return value;
}

export async function setTenantSection<T>(uid: string, section: string, value: T) {
  await set(ref(db, tenantPath(uid, section)), value);
}

export async function updateTenantItem<T extends object>(uid: string, section: string, id: string, value: T) {
  await update(ref(db, `${tenantPath(uid, section)}/${safeSegment(id)}`), value);
}

export async function deleteTenantItem(uid: string, section: string, id: string) {
  await remove(ref(db, `${tenantPath(uid, section)}/${safeSegment(id)}`));
}

/** حالة قسم لحظية. لا تكتب القيمة الابتدائية قبل اكتمال أول قراءة من Firebase. */
export function useTenantState<T>(uid: string | undefined, section: string, emptyValue: T) {
  const [value, setValue] = useState<T>(emptyValue);
  const [ready, setReady] = useState(false);
  const valueRef = useRef(value);
  valueRef.current = value;

  useEffect(() => {
    setReady(false);
    setValue(emptyValue);
    valueRef.current = emptyValue;
    if (!uid) return;
    return subscribeTenantSection<T>(uid, section, (remote) => {
      const next = remote ?? emptyValue;
      valueRef.current = next;
      setValue(next);
      setReady(true);
    });
  }, [uid, section]); // emptyValue يجب أن يكون ثابتاً في المستدعي.

  // كل تعديل يكتب إلى Firebase مباشرة، وليس عبر مؤثر مؤجل قد يفقد التعديلات السريعة.
  const setFirebaseValue = useCallback((action: SetStateAction<T>) => {
    if (!uid || !ready) return;
    const next = typeof action === "function"
      ? (action as (previous: T) => T)(valueRef.current)
      : action;
    valueRef.current = next;
    setValue(next);
    void setTenantSection(uid, section, next).catch((error) => {
      console.error(`Firebase write failed at ${tenantPath(uid, section)}`, error);
    });
  }, [uid, section, ready]);

  return [value, setFirebaseValue, ready] as const;
}
