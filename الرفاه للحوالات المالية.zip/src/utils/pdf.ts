import { jsPDF } from "jspdf";
import html2canvas from "html2canvas-pro";

const escapeHtml = (value: string) =>
  value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

/** انتظار جاهزية الخطوط مع مهلة زمنية حتى لا يعلّق التنفيذ أبداً */
const waitFonts = () =>
  Promise.race([
    (document as Document & { fonts?: { ready?: Promise<unknown> } }).fonts?.ready ?? Promise.resolve(),
    new Promise((resolve) => setTimeout(resolve, 900)),
  ]);

/** تنزيل Blob باسم ملف عبر رابط مؤقت */
function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename.endsWith(".pdf") ? filename : `${filename}.pdf`;
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/**
 * يحوّل مقطع HTML (مستند كامل أو جزء) إلى ملف PDF حقيقي ويُنزّله.
 * يُصيّر المحتوى خارج الشاشة عبر html2canvas-pro (يدعم العربية والألوان الحديثة)
 * ثم يقسّمه إلى صفحات A4 داخل jsPDF. عند تعذّر التصيير المباشر يفتح نافذة
 * احتياطية للحفظ كـ PDF حتى لا تضيع البيانات على المستخدم.
 */
export async function downloadPdfFromHtml(html: string, filename: string) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const styles = Array.from(doc.querySelectorAll("style"))
    .map((node) => node.outerHTML)
    .join("");
  const fragment = styles + doc.body.innerHTML;

  const host = document.createElement("div");
  host.setAttribute("dir", "rtl");
  host.style.position = "fixed";
  host.style.top = "0";
  host.style.left = "-12000px";
  host.style.width = "794px";
  host.style.background = "#ffffff";
  host.style.zIndex = "-1";
  host.style.pointerEvents = "none";
  host.innerHTML = fragment;
  document.body.appendChild(host);

  try {
    await waitFonts();

    const canvas = await html2canvas(host, {
      scale: 2,
      backgroundColor: "#ffffff",
      useCORS: true,
      logging: false,
      imageTimeout: 0,
    });

    if (!canvas.width || !canvas.height) throw new Error("empty-canvas");

    const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const pageW = 210;
    const pageH = 297;
    const imgW = pageW;
    const imgH = (canvas.height * imgW) / canvas.width;
    const img = canvas.toDataURL("image/jpeg", 0.92);

    let remaining = imgH;
    let offset = 0;
    pdf.addImage(img, "JPEG", 0, offset, imgW, imgH);
    remaining -= pageH;
    while (remaining > 0) {
      pdf.addPage();
      offset -= pageH;
      pdf.addImage(img, "JPEG", 0, offset, imgW, imgH);
      remaining -= pageH;
    }

    const name = filename.endsWith(".pdf") ? filename : `${filename}.pdf`;
    try {
      triggerDownload(pdf.output("blob"), name);
    } catch {
      pdf.save(name);
    }
  } catch (error) {
    console.error("PDF generation failed:", error);
    // آلية احتياطية: فتح التقرير في نافذة للطباعة/الحفظ كـ PDF
    const win = window.open("", "_blank");
    if (win) {
      win.document.write(html);
      win.document.close();
      throw new Error("fallback-opened");
    }
    throw error;
  } finally {
    host.remove();
  }
}

/** يبني تقرير A4 منصف بهوية الرفاه من مصفوفة صفوف (أول صف = الترويسة). */
export function buildSimpleReportHtml(
  title: string,
  subtitle: string,
  rows: (string | number)[][]
) {
  const [head, ...body] = rows;
  const cols = head?.length ?? 1;
  const headCells = (head ?? []).map((c) => `<th>${escapeHtml(String(c))}</th>`).join("");
  const bodyRows =
    body.length > 0
      ? body
          .map(
            (r, i) =>
              `<tr class="${i % 2 ? "alt" : ""}">${r
                .map((c) => `<td>${escapeHtml(String(c))}</td>`)
                .join("")}</tr>`
          )
          .join("")
      : `<tr><td colspan="${cols}" class="empty">لا توجد بيانات لعرضها</td></tr>`;
  const now = new Date().toLocaleString("ar", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return `
<style>
  * { box-sizing: border-box; }
  body { margin: 0; font-family: "Cairo", "Tajawal", Tahoma, sans-serif; color: #171717; }
  .page { padding: 34px 30px; }
  .head { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #C5A069; padding-bottom: 14px; }
  .brand { display: flex; gap: 12px; align-items: center; }
  .mark { width: 52px; height: 52px; border-radius: 14px; background: #101114; color: #C5A069; display: grid; place-items: center; font-size: 26px; font-weight: 900; }
  .brand b { font-size: 21px; }
  .brand small { display: block; font-size: 9px; letter-spacing: 3px; color: #9a733d; font-weight: 700; }
  .meta { text-align: left; font-size: 10px; color: #666; line-height: 1.7; }
  h1 { text-align: center; font-size: 21px; margin: 20px 0 4px; font-weight: 900; }
  h2 { text-align: center; font-size: 12px; color: #9a733d; margin: 0 0 18px; font-weight: 700; }
  table { width: 100%; border-collapse: collapse; font-size: 10.5px; }
  th { background: #C5A069; color: #111; padding: 8px 7px; border: 1px solid #b38e59; font-weight: 800; }
  td { padding: 7px; border: 1px solid #e5e0d7; text-align: center; }
  tr.alt { background: #f7f5f1; }
  td.empty { color: #888; padding: 22px; }
  .foot { text-align: center; margin-top: 22px; border-top: 1px solid #eee; padding-top: 9px; font-size: 9px; color: #999; }
</style>
<div class="page">
  <div class="head">
    <div class="brand">
      <div class="mark">ر</div>
      <div><b>شركة الرفاه</b><small>ALRAFAH COMPANY</small></div>
    </div>
    <div class="meta">${escapeHtml(subtitle)}<br />${now}</div>
  </div>
  <h1>${escapeHtml(title)}</h1>
  <h2>تقرير مالي رسمي</h2>
  <table>
    <thead><tr>${headCells}</tr></thead>
    <tbody>${bodyRows}</tbody>
  </table>
  <p class="foot">أُنشئ هذا التقرير آلياً بواسطة نظام الرفاه المحاسبي — تل أبيض، الرقة، سوريا</p>
</div>`;
}
