export interface CompanySettings {
  companyName: string;
  managerName: string;
  country: string;
  governorate: string;
  city: string;
  address: string;
  taxNumber: string;
  phone: string;
  currencyCode: string;
  currencySymbol: string;
  updatedAt: number;
}

export const DEFAULT_COMPANY_SETTINGS: CompanySettings = {
  companyName: "شركة الرفاه للحوالات المالية",
  managerName: "خليل محمد",
  country: "سوريا",
  governorate: "الرقة",
  city: "تل أبيض",
  address: "سوريا - محافظة الرقة - مدينة تل أبيض",
  taxNumber: "",
  phone: "",
  currencyCode: "SYP",
  currencySymbol: "ل.س",
  updatedAt: 0,
};