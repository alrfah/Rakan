/* أدوات تنسيق عربية: عملات، تواريخ، أرقام، وتصدير ملفات */

// واجهة عربية مع أرقام لاتينية 0-9 في جميع أنحاء النظام.
export const AR_LATN = "ar-SA-u-nu-latn";
const nf = new Intl.NumberFormat(AR_LATN, { maximumFractionDigits: 0 });
const nf2 = new Intl.NumberFormat(AR_LATN, { maximumFractionDigits: 2 });

/** العملة التشغيلية الافتراضية للنظام: الليرة السورية */
export const SAR = (n: number) => `${nf.format(n)} ل.س`;

/** رقم مجرد بأرقام عربية */
export const NUM = (n: number) => nf.format(n);

/** رقم بمنزلة عشرية */
export const NUM2 = (n: number) => nf2.format(n);

/** تاريخ مختصر بأسماء الأشهر العربية */
export const DATE = (iso: string) =>
  new Date(iso).toLocaleDateString(AR_LATN, { day: "numeric", month: "short", year: "numeric" });

export const DATE_SHORT = (iso: string) =>
  new Date(iso).toLocaleDateString(AR_LATN, { day: "numeric", month: "short" });

/** أيام متبقية حتى تاريخ (سالب إذا تأخر) */
export const daysLeft = (iso: string) => {
  const d = new Date(iso).getTime() - Date.now();
  return Math.ceil(d / 86400000);
};

export const dueChip = (iso: string) => {
  const d = daysLeft(iso);
  if (d < 0) return { text: `متأخر ${NUM(Math.abs(d))} يوم`, cls: "chip-red" };
  if (d <= 7) return { text: `بعد ${NUM(d)} أيام`, cls: "chip-gold" };
  return { text: DATE(iso), cls: "chip-gray" };
};

/** تنزيل CSV بترميز يدعم العربية في Excel */
export function downloadCSV(filename: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

/** تنزيل JSON (نسخ احتياطي) */
export function downloadJSON(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

/** تاريخ اليوم ISO */
export const todayISO = () => new Date().toISOString().slice(0, 10);

/** اسم الشهر العربي لسلسلة زمنية */
export const MONTHS_AR = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];
