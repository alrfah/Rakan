import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { FirebaseError } from "firebase/app";
import { signInWithEmailAndPassword } from "firebase/auth";
import { get, ref, set } from "firebase/database";
import {
  ChartNoAxesCombined, CloudUpload, DatabaseBackup, Download, Eye, EyeOff, Fingerprint, Landmark, Lock,
  RefreshCw, ShieldCheck, Upload, Users,
} from "lucide-react";
import { Glass, L, SectionHead, inputCls, useApp, Chip, handleNextOrGo } from "./ui";
import { type TeamUser } from "../data/mock";
import { ROLE_LABEL } from "../data/mock";
import { NUM } from "../utils/format";
import { auth, db } from "../lib/firebase";
import { useTenantState } from "../lib/tenant";
import { DEFAULT_COMPANY_SETTINGS, type CompanySettings } from "../types/settings";
import { onValue, ref as dbRef } from "firebase/database";
import type { UserProfile } from "../types/firebase";

/** الأيام المتبقية حتى انتهاء الاشتراك */
function subscriptionDaysLeft(subscriptionEnd?: string): number {
  if (!subscriptionEnd) return 0;
  return Math.max(0, Math.ceil((new Date(subscriptionEnd).getTime() - Date.now()) / 86400000));
}

/** شريحة الوقت المتبقي */
function SubChip({ subscriptionEnd }: { subscriptionEnd?: string }) {
  if (!subscriptionEnd) return null;
  const days = subscriptionDaysLeft(subscriptionEnd);
  if (days > 30) return <span className="chip chip-green">{NUM(days)} يوم</span>;
  if (days > 7) return <span className="chip chip-gold">{NUM(days)} يوم</span>;
  if (days > 0) return <span className="chip chip-red animate-[pulseDot_1.5s_ease-in-out_infinite]">⚠️ {NUM(days)} يوم</span>;
  return <span className="chip chip-red">منتهي</span>;
}

/* ================= تسجيل الدخول ================= */
export function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    if (!email.trim() || !password) {
      setError("أدخل البريد الإلكتروني وكلمة المرور");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (e) {
      const code = e instanceof FirebaseError ? e.code : "";
      setError(
        code === "auth/configuration-not-found"
          ? "فعّل Email/Password من Firebase Console > Authentication > Sign-in method."
          : code === "auth/invalid-credential"
            ? "البريد الإلكتروني أو كلمة المرور غير صحيحة."
            : code === "auth/too-many-requests"
              ? "محاولات كثيرة. حاول مرة أخرى لاحقاً."
              : "تعذر تسجيل الدخول. تحقق من الاتصال وإعدادات Firebase."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative z-10 flex min-h-screen items-center justify-center p-4">
      <div className="grid w-full max-w-4xl overflow-hidden rounded-[26px] border border-[var(--border-gold)] shadow-[0_40px_90px_rgba(0,0,0,0.5)] md:grid-cols-2">
        <div className="glass-gold relative hidden flex-col justify-between overflow-hidden p-10 md:flex">
          <div className="pointer-events-none absolute -left-20 -top-20 h-72 w-72 rounded-full bg-[var(--gold)] opacity-20 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 -right-16 h-64 w-64 rounded-full bg-[#5b8bb5] opacity-10 blur-3xl" />
          <div className="relative flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[var(--gold-bright)] to-[var(--gold)] text-[#171207]">
              <ChartNoAxesCombined size={25} strokeWidth={2.5} aria-hidden="true" />
            </span>
            <div>
              <p className="font-display text-2xl font-black leading-none">الرفاه</p>
              <p className="mt-1 text-[10px] font-black tracking-[0.25em] text-[var(--gold)]">للحوالات المالية</p>
            </div>
          </div>
          <div className="relative space-y-4">
            {[
              "قيد مزدوج ذكي يرفض أي قيد غير متوازن",
              "12 تقريراً مالياً بضغطة واحدة مع تصدير PDF وExcel",
              "تنبيهات ذكية للديون المتأخرة واستحقاقات الحوالات",
            ].map((t, i) => (
              <motion.p key={i} initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.15 }} className="flex items-start gap-3 text-sm font-bold text-[var(--text)]">
                <ShieldCheck size={17} className="mt-0.5 shrink-0 text-[var(--gold-bright)]" /> {t}
              </motion.p>
            ))}
          </div>
          <p className="relative text-[10px] font-bold text-[var(--faint)]">شركة الرفاه للحوالات المالية · سوريا، الرقة، تل أبيض</p>
        </div>

        <div className="glass flex flex-col justify-center p-8 md:p-10">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[var(--gold-dim)] text-[var(--gold-bright)] ring-1 ring-[var(--border-gold)]">
              <Fingerprint size={22} />
            </span>
            <h1 className="font-display text-2xl font-black">تسجيل الدخول الآمن</h1>
            <p className="mt-1 text-xs font-bold text-[var(--muted)]">استخدم حسابك المسجل في Firebase Authentication</p>

            <L label="البريد الإلكتروني" className="mt-6 block">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => handleNextOrGo(e, () => void submit())}
                placeholder="name@company.com"
                className={inputCls}
                dir="ltr"
                autoComplete="email"
                enterKeyHint="next"
              />
            </L>
            <L label="كلمة المرور" className="mt-4 block">
              <div className="relative">
                <input
                  type={show ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyDown={(e) => handleNextOrGo(e, () => void submit())}
                  placeholder="••••••••"
                  className={`${inputCls} pe-10`}
                  dir="ltr"
                  autoComplete="current-password"
                  enterKeyHint="go"
                />
                <button type="button" onClick={() => setShow(!show)} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--faint)] hover:text-[var(--gold)]" aria-label="إظهار كلمة المرور">
                  {show ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </L>

            {error && <p className="mt-3 rounded-xl border border-[var(--red)] bg-[var(--red-soft)] px-3.5 py-2.5 text-xs font-bold leading-5 text-[var(--red)]">{error}</p>}

            <button onClick={() => void submit()} disabled={loading} className="btn-gold mt-6 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm">
              {loading ? (
                <><RefreshCw size={16} className="animate-[spinSlow_0.9s_linear_infinite]" /> جارٍ التحقق من الصلاحيات…</>
              ) : (
                <><Lock size={15} /> دخول إلى الرفاه</>
              )}
            </button>
            <p className="mt-4 text-center text-[10px] font-bold text-[var(--faint)]">لا يمكن إنشاء حساب من هذه الشاشة · الحسابات يديرها المدير فقط</p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

/* ================= إعدادات المستخدم (شخصية فقط) ================= */
export function Settings({ currentUser: _u }: { currentUser: TeamUser }) {
  const { notify, tenantUid } = useApp();
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const [me, setMe] = useState<UserProfile | null>(null);
  useEffect(() => {
    if (!tenantUid) { setLoading(false); return; }
    const unsub = onValue(
      dbRef(db, `users/${tenantUid}/profile`),
      (snap) => { setMe(snap.val() ?? null); setLoading(false); },
      () => setLoading(false)
    );
    return () => unsub();
  }, [tenantUid]);

  const [company, setCompany, companyReady] = useTenantState<CompanySettings>(tenantUid, "settings/company", DEFAULT_COMPANY_SETTINGS);
  const [companyForm, setCompanyForm] = useState<CompanySettings>(DEFAULT_COMPANY_SETTINGS);

  useEffect(() => {
    if (companyReady) setCompanyForm({ ...DEFAULT_COMPANY_SETTINGS, ...company });
  }, [company, companyReady]);

  const sync = async () => {
    if (!tenantUid) return;
    setSyncing(true);
    try {
      await get(ref(db, `users/${tenantUid}`));
      notify("الاتصال مع Firebase يعمل والبيانات متزامنة لحظياً ✓");
    } catch {
      notify("تعذر الاتصال بقاعدة Firebase أو لا توجد صلاحية وصول", "warn");
    } finally {
      setSyncing(false);
    }
  };

  const restore = (f: File | undefined) => {
    if (!f) return;
    const reader = new FileReader();
    reader.onload = async () => {
      if (!tenantUid) return;
      try {
        const parsed = JSON.parse(String(reader.result));
        if (!parsed?.data || typeof parsed.data !== "object") throw new Error("invalid");
        await set(ref(db, `users/${tenantUid}`), parsed.data);
        notify(`تمت استعادة النسخة الاحتياطية «${f.name}» إلى Firebase`);
      } catch {
        notify("ملف النسخة الاحتياطية غير صالح", "warn");
      }
    };
    reader.readAsText(f);
  };

  const saveCompany = () => {
    if (!companyForm.companyName.trim() || !companyForm.city.trim()) { notify("اسم المنشأة والمدينة مطلوبان", "warn"); return; }
    setCompany({ ...companyForm, updatedAt: Date.now() });
    notify("تم حفظ بيانات المنشأة والرقم الضريبي في Firebase");
  };

  const downloadBackup = async () => {
    if (!tenantUid) return;
    try {
      const snapshot = await get(ref(db, `users/${tenantUid}`));
      const blob = new Blob([JSON.stringify({ app: "الرفاه", uid: tenantUid, exportedAt: new Date().toISOString(), data: snapshot.val() ?? {} }, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `الرفاه-نسخة-Firebase-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(a.href);
      notify("تم تنزيل نسخة كاملة من بيانات Firebase");
    } catch {
      notify("تعذر قراءة بيانات النسخة الاحتياطية من Firebase", "warn");
    }
  };

  return (
    <div className="space-y-6">
      <SectionHead title="الإعدادات والحسابات" sub="بطاقتي وبيانات المنشأة والنسخ الاحتياطي" />

      <div className="grid gap-4 lg:grid-cols-3">
        <Glass className="overflow-hidden rounded-[20px] lg:col-span-2">
          <div className="flex items-center justify-between border-b border-[var(--border)] px-5 py-4">
            <h3 className="flex items-center gap-2 font-display text-base font-extrabold"><Users size={16} className="text-[var(--gold)]" /> بطاقتي</h3>
            {me && me.subscriptionEnd && me.subscriptionEnd !== "2099-12-31" && <SubChip subscriptionEnd={me.subscriptionEnd} />}
          </div>
          {loading ? (
            <div className="py-10 text-center text-xs text-[var(--muted)]">جارٍ تحميل البيانات…</div>
          ) : me ? (
            <div className="p-5">
              <div className="flex flex-wrap items-center gap-4">
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[var(--gold-bright)] to-[var(--gold)] font-display text-base font-black text-[#171207]">
                  {me.name.split(" ").map((w: string) => w[0]).slice(0, 2).join("")}
                </span>
                <div className="flex-1">
                  <p className="font-display text-base font-black">{me.name}</p>
                  <p className="text-xs text-[var(--muted)]" dir="ltr">{me.email}</p>
                  <p className="text-[10px] text-[var(--muted)] mt-0.5">{me.phone || "—"}</p>
                </div>
                <Chip label={ROLE_LABEL[me.role]} cls={me.role === "admin" ? "chip-gold" : me.role === "accountant" ? "chip-sky" : "chip-gray"} />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-3">
                <div className="rounded-xl border border-[var(--border)] p-3">
                  <p className="text-[10px] font-bold text-[var(--muted)]">انتهاء الاشتراك</p>
                  <p className="num mt-1 text-xs font-black">{me.subscriptionEnd && me.subscriptionEnd !== "2099-12-31" ? me.subscriptionEnd.slice(0, 10) : "—"}</p>
                </div>
                <div className="rounded-xl border border-[var(--border)] p-3">
                  <p className="text-[10px] font-bold text-[var(--muted)]">آخر دخول</p>
                  <p className="num mt-1 text-xs font-black">{me.lastLoginAt ? new Date(me.lastLoginAt).toLocaleDateString("ar") : "—"}</p>
                </div>
                <div className="rounded-xl border border-[var(--border)] p-3">
                  <p className="text-[10px] font-bold text-[var(--muted)]">الحالة</p>
                  <div className="mt-1"><Chip label={me.status === "active" ? "نشط" : me.status === "blocked" ? "محظور" : "منتهي"} cls={me.status === "active" ? "chip-green" : "chip-red"} /></div>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-10 text-center text-xs text-[var(--muted)]">لا توجد بيانات شخصية</div>
          )}
        </Glass>

        <div className="space-y-4">
          <div className="glass-gold rounded-[20px] p-5">
            <h3 className="flex items-center gap-2 font-display text-base font-extrabold"><CloudUpload size={16} className="text-[var(--gold)]" /> حفظ البيانات</h3>
            <p className="mt-1 text-[11px] font-bold leading-5 text-[var(--muted)]">Firebase Realtime Database · تخزين سحابي لحظي ومعزول</p>
            <div className="mt-3 flex items-center gap-2 rounded-xl border border-[var(--border-gold)] bg-[var(--surface)] px-3 py-2.5">
              <span className={`h-2 w-2 rounded-full ${syncing ? "bg-[var(--gold)] pulse-dot" : "bg-[var(--green)]"}`} />
              <span className="text-[11px] font-black">{syncing ? "جارٍ فحص الاتصال…" : "متصل بـ Firebase — الحفظ تلقائي"}</span>
            </div>
            <button onClick={() => void sync()} disabled={syncing} className="btn-gold mt-3 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-black">
              <RefreshCw size={14} className={syncing ? "animate-[spinSlow_0.9s_linear_infinite]" : ""} /> فحص اتصال Firebase
            </button>
          </div>

          <div className="glass rounded-[20px] p-5">
            <h3 className="flex items-center gap-2 font-display text-base font-extrabold"><DatabaseBackup size={16} className="text-[var(--gold)]" /> النسخ الاحتياطي</h3>
            <p className="mt-1 text-[11px] font-bold leading-5 text-[var(--muted)]">نسخة تلقائية يومياً في الساعة 2 صباحاً — آخر نسخة: اليوم</p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                onClick={() => void downloadBackup()}
                className="btn-gold flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[11px] font-black"
              >
                <Download size={14} /> تنزيل نسخة
              </button>
              <button onClick={() => fileRef.current?.click()} className="btn-ghost flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[11px] font-bold">
                <Upload size={14} /> استعادة
              </button>
              <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={(e) => restore(e.target.files?.[0])} />
            </div>
          </div>
        </div>
      </div>

      <Glass gold className="rounded-[20px] p-5 md:p-6">
        <div className="mb-5">
          <h3 className="flex items-center gap-2 font-display text-lg font-extrabold"><Landmark size={18} className="text-[var(--gold)]" /> بيانات المنشأة</h3>
          <p className="mt-1 text-xs text-[var(--muted)]">تُحفظ هذه البيانات لحظياً تحت settings/company في مساحة المستخدم</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <L label="اسم المنشأة" className="sm:col-span-2"><input className={inputCls} value={companyForm.companyName} onChange={(e) => setCompanyForm({ ...companyForm, companyName: e.target.value })} /></L>
          <L label="اسم المدير"><input className={inputCls} value={companyForm.managerName} onChange={(e) => setCompanyForm({ ...companyForm, managerName: e.target.value })} /></L>
          <L label="رقم الضريبة"><input dir="ltr" className={inputCls} value={companyForm.taxNumber} onChange={(e) => setCompanyForm({ ...companyForm, taxNumber: e.target.value })} placeholder="قابل للتعديل" /></L>
          <L label="الدولة"><input className={inputCls} value={companyForm.country} onChange={(e) => setCompanyForm({ ...companyForm, country: e.target.value })} /></L>
          <L label="المحافظة"><input className={inputCls} value={companyForm.governorate} onChange={(e) => setCompanyForm({ ...companyForm, governorate: e.target.value })} /></L>
          <L label="المدينة / المنطقة"><input className={inputCls} value={companyForm.city} onChange={(e) => setCompanyForm({ ...companyForm, city: e.target.value })} /></L>
          <L label="رقم الهاتف"><input dir="ltr" className={inputCls} value={companyForm.phone} onChange={(e) => setCompanyForm({ ...companyForm, phone: e.target.value })} /></L>
          <L label="العنوان الكامل" className="sm:col-span-2 lg:col-span-3"><input className={inputCls} value={companyForm.address} onChange={(e) => setCompanyForm({ ...companyForm, address: e.target.value })} /></L>
          <L label="رمز العملة"><input className={inputCls} value={companyForm.currencySymbol} onChange={(e) => setCompanyForm({ ...companyForm, currencySymbol: e.target.value })} /></L>
        </div>
        <button onClick={saveCompany} disabled={!companyReady} className="btn-gold mt-5 rounded-xl px-7 py-3 text-xs font-black disabled:opacity-50">حفظ بيانات المنشأة في Firebase</button>
      </Glass>
    </div>
  );
}
