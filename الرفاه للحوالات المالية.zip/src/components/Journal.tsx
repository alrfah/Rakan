import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BookOpenCheck, CheckCircle2, ChevronDown, Eye, Plus, Scale, Search, Trash2 } from "lucide-react";
import { ENTRIES, JOURNAL_ACCOUNTS, accountName, type JournalEntry, type JournalLine } from "../data/mock";
import { DATE, NUM, SAR, todayISO } from "../utils/format";
import { Chip, ExportBar, Glass, L, Modal, SectionHead, inputCls, useApp } from "./ui";
import { useTenantState } from "../lib/tenant";

const accName = (id: string) => accountName(id);
const total = (e: JournalEntry) => e.lines.reduce((s, l) => s + l.debit, 0);

interface Row { accountId: string; debit: string; credit: string }
const blankRow = (): Row => ({ accountId: "", debit: "", credit: "" });

export default function Journal() {
  const { notify, user, tenantUid } = useApp();
  const [entries, setEntries] = useTenantState<JournalEntry[]>(tenantUid, "entries", ENTRIES);
  const [filter, setFilter] = useState<"all" | "posted" | "draft">("all");
  const [q, setQ] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);
  const [modal, setModal] = useState(false);
  const [viewing, setViewing] = useState<JournalEntry | null>(null);
  const [desc, setDesc] = useState("");
  const [ref, setRef] = useState("");
  const [rows, setRows] = useState<Row[]>([blankRow(), blankRow()]);

  const shown = useMemo(
    () =>
      entries.filter(
        (e) =>
          (filter === "all" || e.status === filter) &&
          (!q || e.desc.includes(q) || String(e.no).includes(q) || e.ref.toLowerCase().includes(q.toLowerCase()))
      ),
    [entries, filter, q]
  );

  const tDebit = rows.reduce((s, r) => s + (Number(r.debit) || 0), 0);
  const tCredit = rows.reduce((s, r) => s + (Number(r.credit) || 0), 0);
  const balanced = tDebit > 0 && tDebit === tCredit;

  const setRow = (i: number, patch: Partial<Row>) => setRows((rs) => rs.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const save = () => {
    if (!desc.trim()) { notify("وصف القيد مطلوب", "warn"); return; }
    const valid = rows.filter((r) => r.accountId && (Number(r.debit) > 0 || Number(r.credit) > 0));
    if (valid.length < 2) { notify("أضف سطرين على الأقل بحساب ومبلغ", "warn"); return; }
    if (!balanced) { notify("القيد غير متوازن! المدين يجب أن يساوي الدائن", "warn"); return; }
    const lines: JournalLine[] = valid.map((r) => ({ accountId: r.accountId, debit: Number(r.debit) || 0, credit: Number(r.credit) || 0 }));
    setEntries((es) => [
      { id: `j${Date.now()}`, no: (es.length ? Math.max(...es.map((e) => e.no)) : 0) + 1, date: todayISO(), ref: ref || "يدوي", desc, lines, status: "posted", by: user?.name ?? "—" },
      ...es,
    ]);
    notify("تم ترحيل القيد المزدوج بنجاح ✓");
    setModal(false);
    setDesc(""); setRef(""); setRows([blankRow(), blankRow()]);
  };

  const removeEntry = (e: JournalEntry) => {
    setEntries((es) => es.filter((x) => x.id !== e.id));
    notify(`تم حذف القيد رقم ${e.no}`, "info");
  };

  const csv = [
    ["رقم القيد", "التاريخ", "المرجع", "البيان", "الإجمالي", "الحالة"],
    ...entries.map((e) => [e.no, e.date, e.ref, e.desc, total(e), e.status === "posted" ? "مرحّل" : "مسودة"]),
  ];

  return (
    <div>
      <SectionHead
        title="القيود اليومية"
        sub="نظام القيد المزدوج — لا يُرحَّل قيد إلا إذا توازن المدين مع الدائن"
        actions={
          <>
            <ExportBar name="القيود-اليومية" rows={csv} />
            <button onClick={() => setModal(true)} className="btn-gold flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-black">
              <Plus size={15} /> قيد جديد
            </button>
          </>
        }
      />

      <Glass className="overflow-hidden rounded-[20px]">
        <div className="flex flex-wrap items-center gap-3 border-b border-[var(--border)] px-5 py-4">
          <div className="relative w-full max-w-xs">
            <Search size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--faint)]" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث بالبيان أو الرقم…" className="field w-full rounded-xl py-2 pr-9 ps-3 text-xs" />
          </div>
          <div className="no-print flex rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1">
            {([["all", "الكل"], ["posted", "مرحّلة"], ["draft", "مسودات"]] as const).map(([k, l]) => (
              <button key={k} onClick={() => setFilter(k)} className={`rounded-lg px-4 py-1.5 text-[11px] font-black transition-all ${filter === k ? "bg-gradient-to-l from-[var(--gold-bright)] to-[var(--gold)] text-[#171207]" : "text-[var(--muted)] hover:text-[var(--text)]"}`}>
                {l}
              </button>
            ))}
          </div>
          <p className="ms-auto flex items-center gap-2 text-[11px] font-bold text-[var(--muted)]">
            <BookOpenCheck size={14} className="text-[var(--gold)]" /> {NUM(shown.length)} قيداً معروضاً
          </p>
        </div>

        <div className="max-h-[64vh] overflow-y-auto">
          <table className="lux-table">
            <thead>
              <tr><th className="w-8" /><th>الرقم</th><th>التاريخ</th><th>المرجع</th><th>البيان</th><th>الإجمالي</th><th>الحالة</th><th>بواسطة</th><th /></tr>
            </thead>
            <tbody>
              {shown.map((e) => (
                <>
                  <tr key={e.id} className="cursor-pointer" onClick={() => setOpenId(openId === e.id ? null : e.id)}>
                    <td><motion.span animate={{ rotate: openId === e.id ? 180 : 0 }} className="flex text-[var(--faint)]"><ChevronDown size={14} /></motion.span></td>
                    <td className="num font-black text-[var(--gold-bright)]">#{NUM(e.no)}</td>
                    <td className="num text-[var(--muted)]">{DATE(e.date)}</td>
                    <td className="num text-[var(--muted)]">{e.ref}</td>
                    <td className="max-w-[260px] truncate font-bold">{e.desc}</td>
                    <td className="num font-black">{SAR(total(e))}</td>
                    <td><Chip label={e.status === "posted" ? "مرحّل" : "مسودة"} cls={e.status === "posted" ? "chip-green" : "chip-gold"} /></td>
                    <td className="text-[var(--muted)]">{e.by}</td>
                    <td className="no-print">
                      <span className="flex items-center gap-1">
                        <button onClick={(ev) => { ev.stopPropagation(); setViewing(e); }} title="عرض" className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--sky)] hover:bg-[var(--sky-soft)]"><Eye size={13} /></button>
                        <button onClick={(ev) => { ev.stopPropagation(); removeEntry(e); }} title="حذف" className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--red)] hover:bg-[var(--red-soft)]"><Trash2 size={13} /></button>
                      </span>
                    </td>
                  </tr>
                  <AnimatePresence>
                    {openId === e.id && (
                      <tr>
                        <td colSpan={9} className="!p-0">
                          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden bg-[var(--surface)]">
                            <div className="px-8 py-4">
                              <p className="mb-2 text-[10px] font-black tracking-widest text-[var(--faint)]">تفاصيل القيد المزدوج</p>
                              <div className="grid gap-2 sm:grid-cols-3">
                                {e.lines.map((l, i) => (
                                  <div key={i} className="rounded-xl border border-[var(--border)] bg-[var(--bg-2)] px-3.5 py-2.5">
                                    <p className="truncate text-xs font-black">{accName(l.accountId)}</p>
                                    <p className="num mt-1 text-[11px] font-bold">
                                      {l.debit > 0 ? <span className="text-[var(--green)]">مدين {SAR(l.debit)}</span> : <span className="text-[var(--red)]">دائن {SAR(l.credit)}</span>}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </motion.div>
                        </td>
                      </tr>
                    )}
                  </AnimatePresence>
                </>
              ))}
              {shown.length === 0 && (
                <tr><td colSpan={9} className="py-10 text-center text-sm text-[var(--muted)]">لا قيود مطابقة للتصفية الحالية</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Glass>

      {/* مودال قيد جديد */}
      <Modal open={modal} onClose={() => setModal(false)} title="قيد يومي جديد (مزدوج)" wide>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <L label="البيان" className="sm:col-span-2"><input className={inputCls} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="مثال: تحصيل دفعة من عميل" /></L>
          <L label="المرجع"><input className={inputCls} value={ref} onChange={(e) => setRef(e.target.value)} placeholder="INV-0000" /></L>
        </div>

        <div className="mt-5 overflow-x-auto rounded-xl border border-[var(--border)]">
          <table className="lux-table">
            <thead><tr><th>الحساب</th><th>مدين</th><th>دائن</th><th /></tr></thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i}>
                  <td>
                    <select className={`${inputCls} !py-2 text-xs`} value={r.accountId} onChange={(e) => setRow(i, { accountId: e.target.value })}>
                      <option value="">— اختر حساباً —</option>
                      {JOURNAL_ACCOUNTS.map((a) => <option key={a.id} value={a.id}>{a.code} · {a.name}</option>)}
                    </select>
                  </td>
                  <td><input type="number" min={0} className={`${inputCls} !py-2 text-xs num`} value={r.debit} onChange={(e) => setRow(i, { debit: e.target.value, credit: "" })} placeholder="0" /></td>
                  <td><input type="number" min={0} className={`${inputCls} !py-2 text-xs num`} value={r.credit} onChange={(e) => setRow(i, { credit: e.target.value, debit: "" })} placeholder="0" /></td>
                  <td>
                    <button onClick={() => rows.length > 2 && setRows(rows.filter((_, j) => j !== i))} className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--red)] hover:bg-[var(--red-soft)]" aria-label="حذف السطر">
                      <Trash2 size={13} />
                    </button>
                  </td>
                </tr>
              ))}
              <tr>
                <td className="font-black">الإجمالي</td>
                <td className="num font-black text-[var(--green)]">{SAR(tDebit)}</td>
                <td className="num font-black text-[var(--red)]">{SAR(tCredit)}</td>
                <td>
                  <span className={`chip ${balanced ? "chip-green" : tDebit + tCredit > 0 ? "chip-red" : "chip-gray"}`}>
                    {balanced ? <><CheckCircle2 size={12} /> متوازن</> : <><Scale size={12} /> الفرق {SAR(Math.abs(tDebit - tCredit))}</>}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <button onClick={() => setRows([...rows, blankRow()])} className="btn-ghost flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold">
            <Plus size={14} /> إضافة سطر
          </button>
          <div className="flex gap-2">
            <button onClick={() => setModal(false)} className="btn-ghost rounded-xl px-5 py-2.5 text-xs font-bold">إلغاء</button>
            <button onClick={save} disabled={!balanced} className={`flex items-center gap-2 rounded-xl px-6 py-2.5 text-xs font-black transition-all ${balanced ? "btn-gold" : "cursor-not-allowed bg-[var(--surface-2)] text-[var(--faint)]"}`}>
              <CheckCircle2 size={15} /> ترحيل القيد
            </button>
          </div>
        </div>
      </Modal>

      {/* مودال العرض */}
      <Modal open={!!viewing} onClose={() => setViewing(null)} title={`قيد رقم #${viewing?.no ?? ""}`}>
        {viewing && (
          <div>
            <div className="mb-4 grid grid-cols-2 gap-3 text-xs">
              <p><span className="text-[var(--muted)]">التاريخ: </span><span className="num font-bold">{DATE(viewing.date)}</span></p>
              <p><span className="text-[var(--muted)]">المرجع: </span><span className="num font-bold">{viewing.ref}</span></p>
              <p className="col-span-2"><span className="text-[var(--muted)]">البيان: </span><span className="font-bold">{viewing.desc}</span></p>
            </div>
            <div className="overflow-hidden rounded-xl border border-[var(--border)]">
              <table className="lux-table">
                <thead><tr><th>الحساب</th><th>مدين</th><th>دائن</th></tr></thead>
                <tbody>
                  {viewing.lines.map((l, i) => (
                    <tr key={i}>
                      <td className="font-bold">{accName(l.accountId)}</td>
                      <td className="num text-[var(--green)]">{l.debit > 0 ? SAR(l.debit) : "—"}</td>
                      <td className="num text-[var(--red)]">{l.credit > 0 ? SAR(l.credit) : "—"}</td>
                    </tr>
                  ))}
                  <tr>
                    <td className="font-black">الإجمالي</td>
                    <td className="num font-black">{SAR(total(viewing))}</td>
                    <td className="num font-black">{SAR(total(viewing))}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
