import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";
import { getAuth, browserLocalPersistence, setPersistence } from "firebase/auth";
import { get, getDatabase, ref, type DataSnapshot } from "firebase/database";
import { getFunctions } from "firebase/functions";

/** رقم واتساب الإدارة */
export const ADMIN_WHATSAPP = "05394600275";

/**
 * يجلب وقت خادم Firebase (Servertime) ليمنع التلاعب بساعة الجهاز.
 * يكتب قيمة serverTimestamp ثم يقرأها لمعرفة الفارق مع Date.now().
 */
export async function fetchServerTime(): Promise<number> {
  const db = getDatabase();
  const pingRef = ref(db, ".info/serverTimeOffset");
  try {
    const snap: DataSnapshot = await get(pingRef);
    const offset = snap.val() as number ?? 0;
    return Date.now() + offset;
  } catch {
    return Date.now();
  }
}

/** يحسب الأيام المتبقية حتى انتهاء الاشتراك من وقت الخادم */
export async function checkSubscriptionServer(subscriptionEnd: string): Promise<{
  expired: boolean;
  daysLeft: number;
  serverNow: number;
}> {
  const serverNow = await fetchServerTime();
  const endMs = new Date(subscriptionEnd).getTime();
  const daysLeft = Math.ceil((endMs - serverNow) / 86400000);
  return { expired: serverNow >= endMs, daysLeft: Math.max(0, daysLeft), serverNow };
}

export const ADMIN_UID = "n4KBfNzDe3hkkA4FyzfUw9uPycF3";

export function isAdminAuth(user?: { uid?: string; email?: string | null } | null): boolean {
  if (!user) return false;
  if (user.uid === ADMIN_UID) return true;
  const email = (user.email ?? "").toLowerCase();
  return email === "admin@alrfah.com" || email.includes("admin") || email === "admin@alrafahchat.firebaseapp.com";
}

export const firebaseConfig = {
  apiKey: "AIzaSyCZvfvmaoAJHbyxSjrVRCwyrirIv-DpV4w",
  authDomain: "alrfahchat.firebaseapp.com",
  databaseURL: "https://alrfahchat-default-rtdb.firebaseio.com",
  projectId: "alrfahchat",
  storageBucket: "alrfahchat.firebasestorage.app",
  messagingSenderId: "987282445359",
  appId: "1:987282445359:web:521c67eb9bfeb1dd6ba2da",
  measurementId: "G-0VHNB5ZKXY",
};

export const firebaseApp = initializeApp(firebaseConfig);
export const auth = getAuth(firebaseApp);
export const db = getDatabase(firebaseApp);
export const functions = getFunctions(firebaseApp);

// تحتفظ Firebase فقط بجلسة Authentication. بيانات المحاسبة لا تُخزن محلياً.
void setPersistence(auth, browserLocalPersistence);

if (typeof window !== "undefined") {
  void isSupported().then((supported) => supported && getAnalytics(firebaseApp)).catch(() => undefined);
}
